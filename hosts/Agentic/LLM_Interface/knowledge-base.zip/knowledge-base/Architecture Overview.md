# Architecture Overview

## Configuration Flow
1. `flake.nix` declares external inputs and exposes `nixosConfigurations` for `Default` and `agentic`.
2. Each host configuration imports hardware, packages, reusable modules, and host variables.
3. `modules/default.nix` provides the shared module set; host files can add or disable individual modules.
4. Variable files select desktop, browser, editor, terminal, file manager, video driver, and optional games.
5. Program and desktop modules configure the user environment and system services.
6. `overlays/` and `pkgs/` extend the package set; `dev-shells/` exposes language-specific development environments.

## Main Areas
- [[Files/hosts|Hosts]]: machine-specific composition, hardware, variables, packages, and local AI integration.
- [[Files/modules/core|Core modules]]: shared boot, system, users, networking, services, security, and packages.
- [[Files/modules/desktop|Desktop modules]]: GNOME, Plasma, i3, Hyprland, scripts, and panels.
- [[Files/modules/programs|Program modules]]: browsers, editors, terminals, file managers, CLI tools, and media.
- [[Files/dev-shells|Development shells]]: language and tooling environments based on Nix flakes.
- [[Files/overlays|Overlays]] and [[Files/pkgs|local packages]]: package customizations.

## AI and Obsidian Path
The Agentic host contains model definitions and a Python gateway under `hosts/Agentic/LLM_Interface`. The gateway currently points at an external user Documents path for its Obsidian memory directory; this generated repository vault is separate and lives at `knowledge-base/`.

## Source Pages
Use the `Files/` hierarchy or Obsidian search to locate the exact page for any source file. Pages include SHA-256 hashes so a later regeneration can identify source drift.
