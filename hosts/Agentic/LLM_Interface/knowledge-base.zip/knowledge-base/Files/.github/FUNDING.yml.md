# .github/FUNDING.yml 
---
type: repository-file
source_path: ".github/FUNDING.yml"
source_kind: text
extension: "yml"
bytes: 931
sha256: 99002260890793917ce2227fa09eca6619b716c31becbffe3d4b556664a6b8eb
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/yml
  - area/.github
---

## Summary
- **Role:** Repository text file or configuration artifact.
- **Repository path:** `.github/FUNDING.yml`
- **Source kind:** text
- **Size:** 931 bytes, 16 lines
- **SHA-256:** `99002260890793917ce2227fa09eca6619b716c31becbffe3d4b556664a6b8eb`

## Searchable Metadata
- **Keywords:** Replace, with, single, username, e.g., polar, issuehunt, patreon, project-name, cloud-foundry, tidelift, custom, github, liberapay, link2
- **Parent:** [[Files/.github|.github]]

### Detected Declarations / Headings
- `#`

## Source
```
yaml
# These are supported funding model platforms

github: # Replace with up to 4 GitHub Sponsors-enabled usernames e.g., [user1, user2]
patreon: # Replace with a single Patreon username
open_collective: # Replace with a single Open Collective username
ko_fi: slyharvey # Replace with a single Ko-fi username
tidelift: # Replace with a single Tidelift platform-name/package-name e.g., npm/babel
community_bridge: # Replace with a single Community Bridge project-name e.g., cloud-foundry
liberapay: # Replace with a single Liberapay username
issuehunt: # Replace with a single IssueHunt username
lfx_crowdfunding: # Replace with a single LFX Crowdfunding project-name e.g., cloud-foundry
polar: # Replace with a single Polar username
buy_me_a_coffee: # Replace with a single Buy Me a Coffee username
thanks_dev: # Replace with a single thanks.dev username
custom: # Replace with up to 4 custom sponsorship URLs e.g., ['link1', 'link2']
```
