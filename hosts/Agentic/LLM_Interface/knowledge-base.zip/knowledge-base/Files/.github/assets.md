# .github/assets  This page represents the repository directory `.github/assets` and links to its indexed files.  ## Files
- [[.github/assets/nixos-logo.png.md|.github/assets/nixos-logo.png]]
- [[.github/assets/preview1.png.md|.github/assets/preview1.png]]
- [[.github/assets/preview2.png.md|.github/assets/preview2.png]]
- [[.github/assets/preview3.png.md|.github/assets/preview3.png]]
- [[.github/assets/preview4.png.md|.github/assets/preview4.png]]
- [[.github/assets/preview5.png.md|.github/assets/preview5.png]]
