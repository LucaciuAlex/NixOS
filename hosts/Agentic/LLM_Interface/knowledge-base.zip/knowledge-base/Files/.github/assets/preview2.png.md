# .github/assets/preview2.png 
---
type: repository-file
source_path: ".github/assets/preview2.png"
source_kind: binary
extension: "png"
bytes: 4241349
sha256: fbca2c0c971ea214fe968b684cc4b1ab0b607056e354fe089a0371a370e0c903
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/.github
---

## Summary
- **Role:** Binary or media asset referenced by the configuration.
- **Repository path:** `.github/assets/preview2.png`
- **Source kind:** binary
- **Size:** 4241349 bytes
- **SHA-256:** `fbca2c0c971ea214fe968b684cc4b1ab0b607056e354fe089a0371a370e0c903`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/.github/assets|.github/assets]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
