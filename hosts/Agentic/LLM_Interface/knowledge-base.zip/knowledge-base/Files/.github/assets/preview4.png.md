# .github/assets/preview4.png 
---
type: repository-file
source_path: ".github/assets/preview4.png"
source_kind: binary
extension: "png"
bytes: 2776145
sha256: 01d7d0274c8f57a5ac1c2da29615e950a8f4b3b04d0b3cfc06b2b28c44ef68f3
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/.github
---

## Summary
- **Role:** Binary or media asset referenced by the configuration.
- **Repository path:** `.github/assets/preview4.png`
- **Source kind:** binary
- **Size:** 2776145 bytes
- **SHA-256:** `01d7d0274c8f57a5ac1c2da29615e950a8f4b3b04d0b3cfc06b2b28c44ef68f3`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/.github/assets|.github/assets]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
