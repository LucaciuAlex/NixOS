# .github/assets/preview5.png 
---
type: repository-file
source_path: ".github/assets/preview5.png"
source_kind: binary
extension: "png"
bytes: 1735856
sha256: ea7fe5fe38389ec9ab91af02a5ad00d056b0fb9b2de3171522dc8793c4146d23
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/.github
---

## Summary
- **Role:** Binary or media asset referenced by the configuration.
- **Repository path:** `.github/assets/preview5.png`
- **Source kind:** binary
- **Size:** 1735856 bytes
- **SHA-256:** `ea7fe5fe38389ec9ab91af02a5ad00d056b0fb9b2de3171522dc8793c4146d23`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/.github/assets|.github/assets]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
