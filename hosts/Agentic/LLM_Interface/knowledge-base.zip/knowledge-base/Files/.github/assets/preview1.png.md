# .github/assets/preview1.png 
---
type: repository-file
source_path: ".github/assets/preview1.png"
source_kind: binary
extension: "png"
bytes: 2952587
sha256: f73c05f734cb0aa64e4a706a6a24bd97d036440f40c14ecea4d00db4db1aff33
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/.github
---

## Summary
- **Role:** Binary or media asset referenced by the configuration.
- **Repository path:** `.github/assets/preview1.png`
- **Source kind:** binary
- **Size:** 2952587 bytes
- **SHA-256:** `f73c05f734cb0aa64e4a706a6a24bd97d036440f40c14ecea4d00db4db1aff33`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/.github/assets|.github/assets]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
