# .github/assets/preview3.png 
---
type: repository-file
source_path: ".github/assets/preview3.png"
source_kind: binary
extension: "png"
bytes: 3554257
sha256: b8fc38b2950dea696c14ed2ab035dc4529712b53ee1d114915b63c4d0eccadd4
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/.github
---

## Summary
- **Role:** Binary or media asset referenced by the configuration.
- **Repository path:** `.github/assets/preview3.png`
- **Source kind:** binary
- **Size:** 3554257 bytes
- **SHA-256:** `b8fc38b2950dea696c14ed2ab035dc4529712b53ee1d114915b63c4d0eccadd4`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/.github/assets|.github/assets]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
