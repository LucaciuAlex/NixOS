# .github/assets/nixos-logo.png 
---
type: repository-file
source_path: ".github/assets/nixos-logo.png"
source_kind: binary
extension: "png"
bytes: 240429
sha256: a134edd72c27dd17e4d33831532c4de69080a3851f8dbd934189f63924670b43
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/.github
---

## Summary
- **Role:** Binary or media asset referenced by the configuration.
- **Repository path:** `.github/assets/nixos-logo.png`
- **Source kind:** binary
- **Size:** 240429 bytes
- **SHA-256:** `a134edd72c27dd17e4d33831532c4de69080a3851f8dbd934189f63924670b43`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/.github/assets|.github/assets]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
