# flake.nix 
---
type: repository-file
source_path: "flake.nix"
source_kind: text
extension: "nix"
bytes: 3094
sha256: b445f363e73e5f984b88464ca69b5fe933830a248b2d12953ac52ca2ecf5f61a
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/root
---

## Summary
- **Role:** Flake entry point defining inputs, outputs, systems, and packages.
- **Repository path:** `flake.nix`
- **Source kind:** text
- **Size:** 3094 bytes, 116 lines
- **SHA-256:** `b445f363e73e5f984b88464ca69b5fe933830a248b2d12953ac52ca2ecf5f61a`

## Searchable Metadata
- **Keywords:** github, url, nixpkgs, inputs.nixpkgs.follows, system, flake, inputs, host, false, inherit, home-manager, outputs, self, forAllSystems, mkHost
- **Parent:** [[Repository Index]]

### Detected Declarations / Headings
- `description =`
- `inputs =`
- `home-manager =`
- `url =`
- `nix-index-database =`
- `url =`
- `nix-doom-emacs-unstraightened =`
- `url =`
- `noctalia =`
- `url =`
- `caelestia-shell =`
- `url =`

### Detected References
- `url = "github:nixos/nixpkgs/nixos-unstable";`
- `url = "github:nixos/nixpkgs/nixos-25.11";`
- `url = "github:gmodena/nix-flatpak?ref=latest";`
- `url = "github:hyprwm/Hyprland";`
- `url = "github:nix-community/home-manager";`
- `url = "github:nix-community/nix-index-database";`
- `url = "github:marienz/nix-doom-emacs-unstraightened";`
- `url = "github:noctalia-dev/noctalia-shell";`
- `url = "github:caelestia-dots/shell";`
- `url = "github:Sly-Harvey/doom";`
- `url = "github:Sly-Harvey/nixvim";`
- `url = "github:Sly-Harvey/nvim";`

## Source
```
nix
{
  description = "A simple flake for an atomic system";

  inputs = {
    nixpkgs.url = "github:nixos/nixpkgs/nixos-unstable";
    nixpkgs-stable.url = "github:nixos/nixpkgs/nixos-25.11";
    nix-flatpak.url = "github:gmodena/nix-flatpak?ref=latest";
    hyprland.url = "github:hyprwm/Hyprland";
    home-manager = {
      url = "github:nix-community/home-manager";
      inputs.nixpkgs.follows = "nixpkgs";
    };
    nix-index-database = {
      url = "github:nix-community/nix-index-database";
      inputs.nixpkgs.follows = "nixpkgs";
    };
    nix-doom-emacs-unstraightened = {
      url = "github:marienz/nix-doom-emacs-unstraightened";
      inputs.nixpkgs.follows = ""; # Doesn't use nixpkgs
    };
    noctalia = {
      url = "github:noctalia-dev/noctalia-shell";
      inputs.nixpkgs.follows = "nixpkgs";
    };
    caelestia-shell = {
      url = "github:caelestia-dots/shell";
      inputs.nixpkgs.follows = "nixpkgs";
    };
    doom-config = {
      url = "github:Sly-Harvey/doom";
      flake = false;
    };
    nixvim = {
      url = "github:Sly-Harvey/nixvim";
      inputs.nixpkgs.follows = "nixpkgs";
    };
    neovim = {
      url = "github:Sly-Harvey/nvim";
      flake = false;
    };
    plasma-manager = {
      url = "github:nix-community/plasma-manager";
      inputs.nixpkgs.follows = "nixpkgs";
      inputs.home-manager.follows = "home-manager";
    };
    spicetify-nix = {
      url = "github:Gerg-L/spicetify-nix";
      inputs.nixpkgs.follows = "nixpkgs";
    };
    firefox-addons = {
      url = "gitlab:rycee/nur-expressions?dir=pkgs/firefox-addons";
      inputs.nixpkgs.follows = "nixpkgs";
    };
    betterfox = {
      url = "github:yokoffing/Betterfox";
      flake = false;
    };
    thunderbird-catppuccin = {
      url = "github:catppuccin/thunderbird";
      flake = false;
    };
    zen-browser = {
      url = "github:0xc000022070/zen-browser-flake";
      inputs = {
        nixpkgs.follows = "nixpkgs";
        home-manager.follows = "home-manager";
      };
    };
    nvchad4nix = {
      url = "github:nix-community/nix4nvchad";
      inputs.nixpkgs.follows = "nixpkgs";
    };
  };

  outputs =
    {
      self,
      nixpkgs,
      ...
    }@inputs:
    let
      inherit (self) outputs;
      systems = [
        "x86_64-linux"
        "aarch64-linux"
      ];
      forAllSystems = nixpkgs.lib.genAttrs systems;
      mkHost =
        host:
        nixpkgs.lib.nixosSystem {
          # inherit system;
          system = forAllSystems (system: system);
          modules = [
            ./hosts/${host}/configuration.nix
          ];
          specialArgs = {
            overlays = import ./overlays { inherit inputs host; };
            inherit
              self
              inputs
              outputs
              host
              ;
          };
        };
    in
    {
      templates = import ./dev-shells;
      formatter = forAllSystems (system: nixpkgs.legacyPackages.${system}.nixfmt-tree);
      nixosConfigurations = {
        Default = mkHost "Default";
        agentic = mkHost "Agentic";
      };
    };
}
```
