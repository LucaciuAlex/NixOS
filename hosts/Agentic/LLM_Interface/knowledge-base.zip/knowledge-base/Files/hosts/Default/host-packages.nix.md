# hosts/Default/host-packages.nix 
---
type: repository-file
source_path: "hosts/Default/host-packages.nix"
source_kind: text
extension: "nix"
bytes: 946
sha256: 5afcd5b8dc3ab29a5c17b510edbf445e0fe3a0cf5f732a130ee997615ed8011d
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/hosts
---

## Summary
- **Role:** Host-specific NixOS configuration or host support file.
- **Repository path:** `hosts/Default/host-packages.nix`
- **Source kind:** text
- **Size:** 946 bytes, 36 lines
- **SHA-256:** `5afcd5b8dc3ab29a5c17b510edbf445e0fe3a0cf5f732a130ee997615ed8011d`

## Searchable Metadata
- **Keywords:** Nintendo, game, For, Sony, Sega, PlayStation, with, cores, pkgs, Boy, Arcade, mupen64plus, mgba, Advance, Naomi
- **Parent:** [[Files/hosts/Default|hosts/Default]]

### Detected Declarations / Headings
- `#`
- `#`
- `#`
- `#`

## Source
```
nix
{ pkgs, ... }:
{
  environment.systemPackages = with pkgs; [
    obsidian
    ludusavi # For game saves
    godot # For game development
    proton-vpn # VPN
    github-desktop
    # pokego # Overlayed
    qbittorrent
    vlc
    doublecmd
    nixfmt-rfc-style

    # All-in-one front-end for emulators 
    (retroarch.withCores (cores: with cores; [
      # citra # Nintendo - 3DS
      dolphin # Nintendo - GameCube / Wii
      # fbneo # Arcade
      flycast # Sega - Dreamcast / Naomi
      genesis-plus-gx # Sega - MS/GG/MD/CD
      mame # Arcade
      melonds # Nintendo - DS
      mgba # Nintendo - Game Boy Advance
      mupen64plus # Nintendo - N64
      pcsx2 # Sony - PlayStation 2
      ppsspp # Sony - PlayStation Portable (PSP)
      picodrive # Sega - MD/32X
      prosystem # Atari - 7800 / 2600
      sameboy # Nintendo - Game Boy / Color
      snes9x # Nintendo - SNES / SFC
      swanstation # Sony - PlayStation
    ]))
  ];
}
```
