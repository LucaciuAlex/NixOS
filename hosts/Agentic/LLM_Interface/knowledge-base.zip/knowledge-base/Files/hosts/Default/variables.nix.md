# hosts/Default/variables.nix 
---
type: repository-file
source_path: "hosts/Default/variables.nix"
source_kind: text
extension: "nix"
bytes: 1333
sha256: 6f52f7080591dfe5849082e29bee33d6d38562324918e1a0365584aec75cbcfe
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/hosts
---

## Summary
- **Role:** Host-specific NixOS configuration or host support file.
- **Repository path:** `hosts/Default/variables.nix`
- **Source kind:** text
- **Size:** 1333 bytes, 38 lines
- **SHA-256:** `6f52f7080591dfe5849082e29bee33d6d38562324918e1a0365584aec75cbcfe`

## Searchable Metadata
- **Keywords:** true, Whether, yazi, minimal, waybar, hyprland, galaxy.webp, zsh, firefox, vscode, nvidia, kitty, jake_the_dog, with, Desktop
- **Parent:** [[Files/hosts/Default|hosts/Default]]

### Detected Declarations / Headings
- `username =`
- `#`
- `desktop =`
- `#`
- `bar =`
- `waybarTheme =`
- `sddmTheme =`
- `defaultWallpaper =`
- `hyprlockWallpaper =`
- `#`
- `terminal =`
- `editor =`

## Source
```
nix
{
  username = "luchylex"; # auto-set with install.sh, live-install.sh, and rebuild scripts.

  # Desktop Environment
  desktop = "gnome"; # hyprland, i3, gnome, plasma

  # Theme & Appearance
  bar = "waybar"; # waybar, wayle, hyprpanel, noctalia-shell, caelestia-shell
  waybarTheme = "minimal"; # stylish, minimal
  sddmTheme = "jake_the_dog"; # astronaut, black_hole, purple_leaves, jake_the_dog, hyprland_kath
  defaultWallpaper = "galaxy.webp"; # Change with SUPER + SHIFT + W (Hyprland)
  hyprlockWallpaper = "galaxy.webp";

  # Default Applications
  terminal = "kitty"; # kitty, alacritty, wezterm
  editor = "vscode"; # nixvim, vscode, helix, doom-emacs, nvchad, neovim
  browser = "firefox"; # zen-beta, firefox, floorp
  fileManager = "yazi"; # yazi, lf, thunar
  shell = "zsh"; # zsh, bash
  games = true; # Enable/Disable gaming module

  # Hardware
  hostname = "Singularity";
  videoDriver = "nvidia"; # nvidia, amdgpu, intel
  nvidiaChannel = "legacy_580"; # stable, latest, beta, legacy_xxx
  bluetoothSupport = true; # Whether your motherboard supports bluetooth
  batterySupport = true; # Whether device has a battery (laptop)

  # Localization
  timezone = "Europe/Bucharest";
  locale = "en_GB.UTF-8";
  clock24h = true;
  kbdLayout = "us";
  kbdVariant = "";
  consoleKeymap = "us";
  capslockAsESC = false;
}
```
