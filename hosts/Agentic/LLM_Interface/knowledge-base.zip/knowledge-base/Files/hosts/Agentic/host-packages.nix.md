# hosts/Agentic/host-packages.nix 
---
type: repository-file
source_path: "hosts/Agentic/host-packages.nix"
source_kind: text
extension: "nix"
bytes: 1002
sha256: 23bcd45c504ccc6e64f4ff3214d1c39cb4a7da6d5a842c4c259d038217795e10
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/hosts
---

## Summary
- **Role:** Host-specific NixOS configuration or host support file.
- **Repository path:** `hosts/Agentic/host-packages.nix`
- **Source kind:** text
- **Size:** 1002 bytes, 39 lines
- **SHA-256:** `23bcd45c504ccc6e64f4ff3214d1c39cb4a7da6d5a842c4c259d038217795e10`

## Searchable Metadata
- **Keywords:** Nintendo, game, For, Sony, Sega, PlayStation, cores, pkgs, Boy, with, Arcade, mgba, SNES, mupen64plus, Advance
- **Parent:** [[Files/hosts/Agentic|hosts/Agentic]]

### Detected Declarations / Headings
- `#`
- `#`
- `#`
- `#`

## Source
```
nix
{ pkgs, ... }:
{
  environment.systemPackages = with pkgs; [
    obsidian
    ludusavi # For game saves
    godot # For game development
    proton-vpn # VPN
    github-desktop
    # pokego # Overlayed
    qbittorrent
    vlc
    doublecmd
    nixfmt-rfc-style
    nixfmt

    # All-in-one front-end for emulators
    (retroarch.withCores (
      cores: with cores; [
        # citra # Nintendo - 3DS
        dolphin # Nintendo - GameCube / Wii
        # fbneo # Arcade
        flycast # Sega - Dreamcast / Naomi
        genesis-plus-gx # Sega - MS/GG/MD/CD
        mame # Arcade
        melonds # Nintendo - DS
        mgba # Nintendo - Game Boy Advance
        mupen64plus # Nintendo - N64
        pcsx2 # Sony - PlayStation 2
        ppsspp # Sony - PlayStation Portable (PSP)
        picodrive # Sega - MD/32X
        prosystem # Atari - 7800 / 2600
        sameboy # Nintendo - Game Boy / Color
        snes9x # Nintendo - SNES / SFC
        swanstation # Sony - PlayStation
      ]
    ))
  ];
}
```
