# hosts/Agentic/LLM_Interface/flake.nix 
---
type: repository-file
source_path: "hosts/Agentic/LLM_Interface/flake.nix"
source_kind: text
extension: "nix"
bytes: 2556
sha256: 68c2ac3bfd09bf3a4759253558e997736c1b82d399d81d3aea8de7c02c5ce75d
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/hosts
---

## Summary
- **Role:** Host-specific NixOS configuration or host support file.
- **Repository path:** `hosts/Agentic/LLM_Interface/flake.nix`
- **Source kind:** text
- **Size:** 2556 bytes, 96 lines
- **SHA-256:** `68c2ac3bfd09bf3a4759253558e997736c1b82d399d81d3aea8de7c02c5ce75d`

## Searchable Metadata
- **Keywords:** version, Python, the, this, venvVersion, you, for, rebuild, python.version, system, pkgs, forEachSupportedSystem, delete, import, venvVersionWarn
- **Parent:** [[Files/hosts/Agentic/LLM_Interface|hosts/Agentic/LLM_Interface]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `version =`
- `devShells =`
- `concatMajorMinor =`
- `python =`
- `default =`
- `venvDir =`
- `postShellHook =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs { inherit system; };`
- `import platform; print(platform.python_version())')"`

## Source
```
nix
{
  description = "A Nix-flake-based Python development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs { inherit system; };
          }
        );

      /*
        Change this value ({major}.{min}) to
        update the Python virtual-environment
        version. When you do this, make sure
        to delete the `.venv` directory to
        have the hook rebuild it for the new
        version, since it won't overwrite an
        existing one. After this, reload the
        development shell to rebuild it.
        You'll see a warning asking you to
        do this when version mismatches are
        present. For safety, removal should
        be a manual step, even if trivial.
      */
      version = "3.13";
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        let
          concatMajorMinor =
            v:
            pkgs.lib.pipe v [
              pkgs.lib.versions.splitVersion
              (pkgs.lib.sublist 0 2)
              pkgs.lib.concatStrings
            ];

          python = pkgs."python${concatMajorMinor version}";
        in
        {
          default = pkgs.mkShellNoCC {
            venvDir = ".venv";

            postShellHook = ''
              venvVersionWarn() {
              	local venvVersion
              	venvVersion="$("$venvDir/bin/python" -c 'import platform; print(platform.python_version())')"

              	[[ "$venvVersion" == "${python.version}" ]] && return

              	cat <<EOF
              Warning: Python version mismatch: [$venvVersion (venv)] != [${python.version}]
                       Delete '$venvDir' and reload to rebuild for version ${python.version}
              EOF
              }

              venvVersionWarn
            '';

            packages = with python.pkgs; [
              venvShellHook
              pip
              requests

              # Add whatever else you'd like here.
              # pkgs.basedpyright

              # pkgs.black
              # or
              # python.pkgs.black

              # pkgs.ruff
              # or
              # python.pkgs.ruff
            ];
          };
        }
      );
    };
}
```
