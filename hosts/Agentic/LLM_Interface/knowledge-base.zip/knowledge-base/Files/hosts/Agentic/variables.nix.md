# hosts/Agentic/variables.nix 
---
type: repository-file
source_path: "hosts/Agentic/variables.nix"
source_kind: text
extension: "nix"
bytes: 1329
sha256: bd28f2d22b73bb6aa1279b87511982c57e82b2161bece0aae14c07a95d531408
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/hosts
---

## Summary
- **Role:** Host-specific NixOS configuration or host support file.
- **Repository path:** `hosts/Agentic/variables.nix`
- **Source kind:** text
- **Size:** 1329 bytes, 38 lines
- **SHA-256:** `bd28f2d22b73bb6aa1279b87511982c57e82b2161bece0aae14c07a95d531408`

## Searchable Metadata
- **Keywords:** true, Whether, yazi, minimal, waybar, hyprland, galaxy.webp, zsh, firefox, vscode, nvidia, kitty, black_hole, with, Desktop
- **Parent:** [[Files/hosts/Agentic|hosts/Agentic]]

### Detected Declarations / Headings
- `username =`
- `#`
- `desktop =`
- `#`
- `bar =`
- `waybarTheme =`
- `sddmTheme =`
- `defaultWallpaper =`
- `hyprlockWallpaper =`
- `#`
- `terminal =`
- `editor =`

## Source
```
nix
{
  username = "luchylex"; # auto-set with install.sh, live-install.sh, and rebuild scripts.

  # Desktop Environment
  desktop = "gnome"; # hyprland, i3, gnome, plasma

  # Theme & Appearance
  bar = "waybar"; # waybar, wayle, hyprpanel, noctalia-shell, caelestia-shell
  waybarTheme = "minimal"; # stylish, minimal
  sddmTheme = "black_hole"; # astronaut, black_hole, purple_leaves, jake_the_dog, hyprland_kath
  defaultWallpaper = "galaxy.webp"; # Change with SUPER + SHIFT + W (Hyprland)
  hyprlockWallpaper = "galaxy.webp";

  # Default Applications
  terminal = "kitty"; # kitty, alacritty, wezterm
  editor = "vscode"; # nixvim, vscode, helix, doom-emacs, nvchad, neovim
  browser = "firefox"; # zen-beta, firefox, floorp
  fileManager = "yazi"; # yazi, lf, thunar
  shell = "zsh"; # zsh, bash
  games = true; # Enable/Disable gaming module

  # Hardware
  hostname = "BareMetal";
  videoDriver = "nvidia"; # nvidia, amdgpu, intel
  nvidiaChannel = "legacy_580"; # stable, latest, beta, legacy_xxx
  bluetoothSupport = true; # Whether your motherboard supports bluetooth
  batterySupport = true; # Whether device has a battery (laptop)

  # Localization
  timezone = "Europe/Bucharest";
  locale = "en_GB.UTF-8";
  clock24h = true;
  kbdLayout = "us";
  kbdVariant = "";
  consoleKeymap = "us";
  capslockAsESC = false;
}
```
