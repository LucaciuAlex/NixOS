# hosts/Agentic/modules/programs  This page represents the repository directory `hosts/Agentic/modules/programs` and links to its indexed files.  ## Files
- [[hosts/Agentic/modules/programs/LLMConfig.nix.md|hosts/Agentic/modules/programs/LLMConfig.nix]]
- [[hosts/Agentic/modules/programs/models_manifest.json.md|hosts/Agentic/modules/programs/models_manifest.json]]
- [[hosts/Agentic/modules/programs/orchestrator.py.md|hosts/Agentic/modules/programs/orchestrator.py]]
- [[hosts/Agentic/modules/programs/orchestratorSystemPrompt.txt.md|hosts/Agentic/modules/programs/orchestratorSystemPrompt.txt]]
- [[hosts/Agentic/modules/programs/Qwen3.5CustomModelFile.md|hosts/Agentic/modules/programs/Qwen3.5CustomModelFile]]
