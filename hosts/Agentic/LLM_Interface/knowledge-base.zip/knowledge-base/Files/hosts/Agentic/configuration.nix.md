# hosts/Agentic/configuration.nix 
---
type: repository-file
source_path: "hosts/Agentic/configuration.nix"
source_kind: text
extension: "nix"
bytes: 2347
sha256: fc74ee469f8b1118036ed597e22649ebb1be040b0315087cc03d8a180cddcc4e
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/hosts
---

## Summary
- **Role:** Host-specific NixOS configuration or host support file.
- **Repository path:** `hosts/Agentic/configuration.nix`
- **Source kind:** text
- **Size:** 2347 bytes, 64 lines
- **SHA-256:** `fc74ee469f8b1118036ed597e22649ebb1be040b0315087cc03d8a180cddcc4e`

## Searchable Metadata
- **Keywords:** defined, variables.nix, Set, you, gpu, vars.terminal, vars.editor, editor, terminal, browser, manager, window, true, fan, vars.browser
- **Parent:** [[Files/hosts/Agentic|hosts/Agentic]]

### Detected Declarations / Headings
- `vars =`
- `imports =`
- `#`
- `#`
- `#`
- `#`
- `#`
- `#`
- `#`
- `#`
- `#`

### Detected References
- `import ./variables.nix;`
- `imports = [`
- `sources`

## Source
```
nix
{ lib, ... }:
let
  vars = import ./variables.nix;
in
{
  imports = [
    ./hardware-configuration.nix
    ./host-packages.nix

    # Core Modules (Don't change unless you know what you're doing)
    ../../modules/scripts
    ../../modules/core/boot.nix
    ../../modules/core/bash.nix
    ../../modules/core/zsh.nix
    ../../modules/core/starship.nix
    ../../modules/core/fonts.nix
    ../../modules/core/hardware.nix
    ../../modules/core/network.nix
    ../../modules/core/dns.nix
    ../../modules/core/nh.nix
    ../../modules/core/packages.nix
    ../../modules/core/printing.nix
    ../../modules/core/sddm.nix
    ../../modules/core/security.nix
    ../../modules/core/services.nix
    ../../modules/core/syncthing.nix
    ../../modules/core/system.nix
    ../../modules/core/users.nix
    # ../../modules/core/flatpak.nix
    # ../../modules/core/virtualisation.nix
    # ../../modules/core/dlna.nix

    # Optional
    ../../modules/hardware/drives # Automatically mount extra external/internal drives
    ../../modules/hardware/video/${vars.videoDriver}.nix # Enable gpu drivers defined in variables.nix
    ../../modules/desktop/${vars.desktop} # Set window manager defined in variables.nix
    ../../modules/programs/browser/${vars.browser} # Set browser defined in variables.nix
    ../../modules/programs/terminal/${vars.terminal} # Set terminal defined in variables.nix
    ../../modules/programs/editor/${vars.editor} # Set editor defined in variables.nix
    ../../modules/programs/file-manager/${vars.fileManager} # Set file-manager defined in variables.nix
    ../../modules/programs/cli/tmux
    ../../modules/programs/cli/direnv
    ../../modules/programs/cli/lazygit
    ../../modules/programs/cli/cava
    # ../../modules/programs/cli/fastfetch
    ../../modules/programs/cli/btop
    ../../modules/programs/media/discord
    ../../modules/programs/media/spicetify
    # ../../modules/programs/media/youtube-music
    # ../../modules/programs/media/thunderbird
    # ../../modules/programs/media/obs-studio
    ../../modules/programs/media/mpv
    ../../modules/programs/misc/tlp
    ../../modules/programs/misc/lact # GPU fan, clock and power configuration


    #orchestrated AI models specific resources
    modules/programs/LLMConfig.nix


  ]
  ++ lib.optional (vars.games == true) ../../modules/core/games.nix;
}
```
