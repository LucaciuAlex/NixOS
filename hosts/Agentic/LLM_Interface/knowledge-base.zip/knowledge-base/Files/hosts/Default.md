# hosts/Default  This page represents the repository directory `hosts/Default` and links to its indexed files.  ## Files
- [[hosts/Default/configuration.nix.md|hosts/Default/configuration.nix]]
- [[hosts/Default/hardware-configuration.nix.md|hosts/Default/hardware-configuration.nix]]
- [[hosts/Default/host-packages.nix.md|hosts/Default/host-packages.nix]]
- [[hosts/Default/variables.nix.md|hosts/Default/variables.nix]]
