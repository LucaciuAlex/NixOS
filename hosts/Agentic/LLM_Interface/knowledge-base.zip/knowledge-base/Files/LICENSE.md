# LICENSE 
---
type: repository-file
source_path: "LICENSE"
source_kind: binary
extension: "none"
bytes: 1076
sha256: 0985be076cf95b534cb98325d9c82cb7aef05b8a61ee688c85530a9a597f7f6b
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/none
  - area/root
---

## Summary
- **Role:** Binary or media asset referenced by the configuration.
- **Repository path:** `LICENSE`
- **Source kind:** binary
- **Size:** 1076 bytes
- **SHA-256:** `0985be076cf95b534cb98325d9c82cb7aef05b8a61ee688c85530a9a597f7f6b`

## Searchable Metadata
- **Keywords:** none
- **Parent:** [[Repository Index]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: ``
