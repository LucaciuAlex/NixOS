# modules/core/games.nix 
---
type: repository-file
source_path: "modules/core/games.nix"
source_kind: text
extension: "nix"
bytes: 2949
sha256: 3b5f81338da8b255b2f18facb51493037e5cd6da07f2d55b25870d352d35fb99
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Reusable core NixOS module for system-wide behavior.
- **Repository path:** `modules/core/games.nix`
- **Source kind:** text
- **Size:** 2949 bytes, 126 lines
- **SHA-256:** `3b5f81338da8b255b2f18facb51493037e5cd6da07f2d55b25870d352d35fb99`

## Searchable Metadata
- **Keywords:** true, enable, vsync, Shift_R, Shift_L, gamescope, no_display, lag, args, low, input, gl_vsync, CPU, GPU, https
- **Parent:** [[Files/modules/core|modules/core]]

### Detected Declarations / Headings
- `enable =`
- `enable32Bit =`
- `#`
- `#`
- `programs =`
- `steam =`
- `enable =`
- `extraCompatPackages =`
- `gamescopeSession =`
- `enable =`
- `args =`
- `#`

## Source
```
nix
{
  pkgs,
  lib,
  ...
}:
{
  nixpkgs.config.allowUnfreePredicate =
    pkg:
    builtins.elem (lib.getName pkg) [
      "steam"
      "steam-original"
      "steam-run"
    ];
  hardware.graphics = {
    enable = true;
    enable32Bit = true;
  };
  environment.systemPackages = with pkgs; [
    lutris
    heroic
    stable.bottles
    # ryujinx
    # prismlauncher

    steam-run
    wineWow64Packages.staging
    gamescope
  ];
  programs = {
    gamemode.enable = true;
    steam = {
      enable = true;
      remotePlay.openFirewall = true;
      dedicatedServer.openFirewall = true;
      extraCompatPackages = [ pkgs.proton-ge-bin ];
      gamescopeSession = {
        enable = true;
        args = [
          "--rt"
          "--expose-wayland"
          # "--immediate-flips" # Tearing and low input lag
          # "--adaptive-sync"  # G-Sync/FreeSync
        ];
      };
    };
    gamescope = {
      enable = true;
      capSysNice = true;
      package = pkgs.gamescope;
      args = [
        "--rt"
        "--expose-wayland"

        # experimental
        # "--immediate-flips"
      ];
    };
  };
  home-manager.sharedModules = [
    (_: {
      programs.mangohud = {
        enable = true;
        enableSessionWide = true;
        settingsPerApplication = {
          mpv = {
            no_display = true;
          };
        };
        settings = {
          no_display = true; # Hide hud by default (Show by holding right-shift then press F12)
          fps_limit = [
            60
            0
            144
            165
            240
          ];
          fps_limit_method = "late"; # late = low input lag but less smooth, early = more smooth
          vsync = 2; # https://github.com/flightlessmango/MangoHud#vsync
          gl_vsync = 1; # https://github.com/flightlessmango/MangoHud#vsync
          # testing for gl_vsync: 1.045

          # keybinds
          toggle_hud = "Shift_R+F12";
          # toggle_hud_position="Shift_R+F11";
          toggle_fps_limit = "Shift_R+F1";
          # toggle_logging="Shift_L+F2";
          # reload_cfg="Shift_L+F4";
          # upload_log="Shift_L+F3";

          # SYSTEM
          fps = true;
          show_fps_limit = true;
          frametime = true;
          frame_timing = true;
          present_mode = true;
          core_load = false;
          ram = true;
          # swap
          # core_load_change

          # CPU
          cpu_stats = true;
          cpu_temp = true;
          cpu_power = true;
          cpu_text = "CPU";
          cpu_mhz = true;

          # GPU
          throttling_status = true;
          gpu_stats = true;
          gpu_temp = true;
          gpu_core_clock = true;
          gpu_mem_clock = true;
          gpu_power = true;
          gpu_text = "GPU";
          vram = true;
          # gpu_load_change
          # gpu_load_value=60,90
          # gpu_load_color=39F900,FDFD09,B22222
        };
      };
    })
  ];
}
```
