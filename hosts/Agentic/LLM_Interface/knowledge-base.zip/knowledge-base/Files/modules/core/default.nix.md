# modules/core/default.nix 
---
type: repository-file
source_path: "modules/core/default.nix"
source_kind: text
extension: "nix"
bytes: 353
sha256: b5627543ce0fda7e935fd7a94f00055c34ae568633e37edd350f1b87d5024fee
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Reusable core NixOS module for system-wide behavior.
- **Repository path:** `modules/core/default.nix`
- **Source kind:** text
- **Size:** 353 bytes, 24 lines
- **SHA-256:** `b5627543ce0fda7e935fd7a94f00055c34ae568633e37edd350f1b87d5024fee`

## Searchable Metadata
- **Keywords:** imports
- **Parent:** [[Files/modules/core|modules/core]]

### Detected Declarations / Headings
- `imports =`
- `#`
- `#`
- `#`
- `#`

### Detected References
- `imports = [`

## Source
```
nix
{ ... }:
{
  imports = [
    ./boot.nix
    ./fonts.nix
    ./hardware.nix
    ./network.nix
    ./nh.nix
    ./packages.nix
    ./printing.nix
    ./sddm.nix
    ./security.nix
    ./dns.nix
    ./services.nix
    # ./games.nix
    # ./dlna.nix
    ./syncthing.nix
    ./system.nix
    ./users.nix
    # ./flatpak.nix
    # ./virtualisation.nix
  ];
}
```
