# modules/core/users.nix 
---
type: repository-file
source_path: "modules/core/users.nix"
source_kind: text
extension: "nix"
bytes: 1613
sha256: 9bdae00357b3f2026f1277b98319b6e8b7922701159e0bc457640130ffc18a43
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Reusable core NixOS module for system-wide behavior.
- **Repository path:** `modules/core/users.nix`
- **Source kind:** text
- **Size:** 1613 bytes, 73 lines
- **SHA-256:** `9bdae00357b3f2026f1277b98319b6e8b7922701159e0bc457640130ffc18a43`

## Searchable Metadata
- **Keywords:** true, username, editor, browser, terminal, shell, users., Home, home-manager, let, host, then, else, wheel, initialPassword
- **Parent:** [[Files/modules/core|modules/core]]

### Detected Declarations / Headings
- `imports =`
- `home-manager =`
- `useGlobalPkgs =`
- `useUserPackages =`
- `overwriteBackup =`
- `backupFileExtension =`
- `#`
- `home =`
- `username =`
- `homeDirectory =`
- `stateVersion =`
- `sessionVariables =`

### Detected References
- `import ../../hosts/${host}/variables.nix)`
- `imports = [ inputs.home-manager.nixosModules.home-manager ];`

## Source
```
nix
{
  pkgs,
  inputs,
  host,
  ...
}:
let
  inherit (import ../../hosts/${host}/variables.nix)
    username
    editor
    terminal
    browser
    shell
    ;
in
{
  imports = [ inputs.home-manager.nixosModules.home-manager ];
  programs.dconf.enable = true; # Enable dconf for home-manager
  home-manager = {
    useGlobalPkgs = true;
    useUserPackages = true;
    overwriteBackup = true;
    backupFileExtension = "backup";
    users.${username} = {
      # Let Home Manager install and manage itself.
      programs.home-manager.enable = true;
      xdg.enable = true;

      home = {
        username = "${username}";
        homeDirectory = "/home/${username}";
        stateVersion = "26.05"; # Do not change!
        sessionVariables = {
          EDITOR =
            if (editor == "nixvim" || editor == "neovim" || editor == "nvchad") then
              "nvim"
            else if editor == "vscode" then
              "code"
            else
              "nano";
          BROWSER = "${browser}";
          TERMINAL = "${terminal}";
        };
      };
    };
  };
  users = {
    mutableUsers = true;
    users.${username} = {
      isNormalUser = true;
      initialPassword = "123";
      extraGroups = [
        "wheel" # sudo access
        "input"
        "networkmanager"
        "video"
        "audio"
        "libvirtd"
        "kvm"
        "docker"
        "disk"
        "adbusers"
        "lp"
        "scanner"
        "vboxusers" # Virtual Box
      ];
      shell = pkgs.${shell};
      ignoreShellProgramCheck = true;
    };
  };
  nix.settings.allowed-users = [ "${username}" ];
}
```
