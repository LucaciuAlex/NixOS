# modules/core/security.nix 
---
type: repository-file
source_path: "modules/core/security.nix"
source_kind: text
extension: "nix"
bytes: 388
sha256: 860f742e4c721219c1ea996e6cad1a93cb466dc6da108bc97d3c6457d5c2b1ab
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Reusable core NixOS module for system-wide behavior.
- **Repository path:** `modules/core/security.nix`
- **Source kind:** text
- **Size:** 388 bytes, 18 lines
- **SHA-256:** `860f742e4c721219c1ea996e6cad1a93cb466dc6da108bc97d3c6457d5c2b1ab`

## Searchable Metadata
- **Keywords:** true, the, running, replacing, Prevent, pkgs.apparmor-profiles, protectKernelImage, acme.acceptTerms, reboot, kernel, without, rtkit.enable, polkit.enable, security, pkgs
- **Parent:** [[Files/modules/core|modules/core]]

### Detected Declarations / Headings
- `security =`
- `apparmor =`
- `enable =`
- `killUnconfinedConfinables =`
- `packages =`
- `#`
- `protectKernelImage =`

## Source
```
nix
{ pkgs, ... }:
{
  services.gnome.gnome-keyring.enable = true;
  security = {
    rtkit.enable = true;
    polkit.enable = true;
    apparmor = {
      enable = false;
      killUnconfinedConfinables = true;
      packages = [ pkgs.apparmor-profiles ];
    };

    # Prevent replacing the running kernel without a reboot
    protectKernelImage = true;
    acme.acceptTerms = true;
  };
}
```
