# modules/core/syncthing.nix 
---
type: repository-file
source_path: "modules/core/syncthing.nix"
source_kind: text
extension: "nix"
bytes: 283
sha256: 3283270a8c942c08afa4c17ca341f0365ef164f63e7a34fbf0ae47a17bb6bfc1
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Reusable core NixOS module for system-wide behavior.
- **Repository path:** `modules/core/syncthing.nix`
- **Source kind:** text
- **Size:** 283 bytes, 14 lines
- **SHA-256:** `3283270a8c942c08afa4c17ca341f0365ef164f63e7a34fbf0ae47a17bb6bfc1`

## Searchable Metadata
- **Keywords:** username, true, host, openDefaultPorts, user, configDir, dataDir, inherit, let, import, enable, services.syncthing
- **Parent:** [[Files/modules/core|modules/core]]

### Detected Declarations / Headings
- `enable =`
- `openDefaultPorts =`
- `user =`
- `dataDir =`
- `configDir =`

### Detected References
- `import ../../hosts/${host}/variables.nix) username;`

## Source
```
nix
{ host, ... }:
let
  inherit (import ../../hosts/${host}/variables.nix) username;
in
{
  services.syncthing = {
    enable = true;
    openDefaultPorts = true;
    user = "${username}";
    dataDir = "/home/${username}";
    configDir = "/home/${username}/.config/syncthing";
  };
}
```
