# modules/core/ssh.nix 
---
type: repository-file
source_path: "modules/core/ssh.nix"
source_kind: text
extension: "nix"
bytes: 378
sha256: 43ab6c15e78b4402089ba4950b2a41492401918f8d115db7aa02de7915b4f8ba
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Reusable core NixOS module for system-wide behavior.
- **Repository path:** `modules/core/ssh.nix`
- **Source kind:** text
- **Size:** 378 bytes, 14 lines
- **SHA-256:** `43ab6c15e78b4402089ba4950b2a41492401918f8d115db7aa02de7915b4f8ba`

## Searchable Metadata
- **Keywords:** true, prohibit-password, X11Forwarding, UseDns, user2, user1, false, without-password, forced-commands-only, PermitRootLogin, yes, Can, PasswordAuthentication, AllowUsers, settings
- **Parent:** [[Files/modules/core|modules/core]]

### Detected Declarations / Headings
- `enable =`
- `settings =`
- `PasswordAuthentication =`
- `AllowUsers =`
- `UseDns =`
- `X11Forwarding =`
- `PermitRootLogin =`

## Source
```
nix
{ ... }:
{
  services.openssh = {
    enable = true;
    settings = {
      PasswordAuthentication = true;
      AllowUsers = null; # Allows all users by default. Can be [ "user1" "user2" ]
      UseDns = true;
      X11Forwarding = false;
      PermitRootLogin = "prohibit-password"; # "yes", "without-password", "prohibit-password", "forced-commands-only", "no"
    };
  };
}
```
