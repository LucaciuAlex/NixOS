# modules/core/services.nix 
---
type: repository-file
source_path: "modules/core/services.nix"
source_kind: text
extension: "nix"
bytes: 2296
sha256: 4f31fb70aa0500438ffcb3d7b278f57c6c20d05af8cfa551915f6507c8f513e1
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Reusable core NixOS module for system-wide behavior.
- **Repository path:** `modules/core/services.nix`
- **Source kind:** text
- **Size:** 2296 bytes, 73 lines
- **SHA-256:** `4f31fb70aa0500438ffcb3d7b278f57c6c20d05af8cfa551915f6507c8f513e1`

## Searchable Metadata
- **Keywords:** true, For, enable, More, USB, Mounting, false, Services, prohibit-password, Scheduler, pulseaudio.enable, pipewire, tumbler.enable, preview, pulse.enable
- **Parent:** [[Files/modules/core|modules/core]]

### Detected Declarations / Headings
- `#`
- `services =`
- `#`
- `#`
- `#`
- `#`
- `#`
- `#`
- `openssh =`
- `enable =`
- `ports =`
- `settings =`

## Source
```
nix
{ ... }:
{
  # Services to start
  services = {
    libinput.enable = true; # Input Handling
    fstrim.enable = true; # SSD Optimizer
    devmon.enable = true; # For Mounting USB & More
    gvfs.enable = true; # For Mounting USB & More
    udisks2.enable = true; # For Mounting USB & More

    # Userspace CPU Scheduler for Improved Latency for Gaming (Hardware Specific)
    # services.scx = {
    #   enable = true;
    #   package = pkgs.scx.rustscheds;
    #   scheduler = "scx_lavd"; # https://github.com/sched-ext/scx/blob/main/scheds/rust/README.md
    # };

    openssh = {
      enable = true;
      ports = [ 22 ];
      settings = {
        PasswordAuthentication = true;
        KbdInteractiveAuthentication = true;
        AllowUsers = null; # Allows all users by default. Can be [ "user1" "user2" ]
        UseDns = true;
        X11Forwarding = false;
        PermitRootLogin = "prohibit-password"; # "yes", "without-password", "prohibit-password", "forced-commands-only", "no"
      };
    };
    blueman.enable = true; # Bluetooth Support
    tumbler.enable = true; # Image/video preview

    pulseaudio.enable = false;
    pipewire = {
      enable = true;
      alsa.enable = true;
      alsa.support32Bit = true;
      pulse.enable = true;
      jack.enable = true;
      # wireplumber = {
      #   enable = true;
      #   configPackages = [
      #     (pkgs.writeTextDir "share/wireplumber/wireplumber.conf.d/11-bluetooth-policy.conf" ''
      #       bluetooth.autoswitch-to-headset-profile = false
      #     '')
      #   ];
      # };
      extraConfig.pipewire."92-low-latency" = {
        "context.properties" = {
          "default.clock.rate" = 48000;
          "default.clock.quantum" = 256;
          "default.clock.min-quantum" = 256;
          "default.clock.max-quantum" = 256;
        };
      };
      extraConfig.pipewire-pulse."92-low-latency" = {
        context.modules = [
          {
            name = "libpipewire-module-protocol-pulse";
            args = {
              pulse.min.req = "256/48000";
              pulse.default.req = "256/48000";
              pulse.max.req = "256/48000";
              pulse.min.quantum = "256/48000";
              pulse.max.quantum = "256/48000";
            };
          }
        ];
      };
    };
  };
}
```
