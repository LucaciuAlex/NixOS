# modules/core/dlna.nix 
---
type: repository-file
source_path: "modules/core/dlna.nix"
source_kind: text
extension: "nix"
bytes: 675
sha256: 3af29f8112fcde1244a74d2687fc0b26e04d793b40f38066d1676aff55496f87
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Reusable core NixOS module for system-wide behavior.
- **Repository path:** `modules/core/dlna.nix`
- **Source kind:** text
- **Size:** 675 bytes, 29 lines
- **SHA-256:** `3af29f8112fcde1244a74d2687fc0b26e04d793b40f38066d1676aff55496f87`

## Searchable Metadata
- **Keywords:** hostname, true, Pictures, host, warn, users.users.minidlna, log_level, yes, inotify, extraGroups, can, the, access, users, files.
- **Parent:** [[Files/modules/core|modules/core]]

### Detected Declarations / Headings
- `enable =`
- `openFirewall =`
- `settings =`
- `friendly_name =`
- `media_dir =`
- `#`
- `#`
- `inotify =`
- `log_level =`
- `extraGroups =`

### Detected References
- `import ../../hosts/${host}/variables.nix) hostname;`

## Source
```
nix
{ host, ... }:
let
  inherit (import ../../hosts/${host}/variables.nix) hostname;
in
{

  services.minidlna = {
    enable = true;
    openFirewall = true;
    settings = {
      friendly_name = "${hostname}";
      media_dir = [
        # A = Audio, P = Pictures, V, = Videos, PV = Pictures and Videos.
        # "A,/mnt/work/Pimsleur/Russian"
        "/mnt/work/Pimsleur"
        "/mnt/work/Media/Films"
        "/mnt/work/Media/Series"
        "/mnt/work/Media/Videos"
        "/mnt/work/Media/Music"
      ];
      inotify = "yes";
      log_level = "warn";
    };
  };
  users.users.minidlna = {
    extraGroups = [ "users" ]; # so minidlna can access the files.
  };
}
```
