# modules/core/fonts.nix 
---
type: repository-file
source_path: "modules/core/fonts.nix"
source_kind: text
extension: "nix"
bytes: 717
sha256: f8d92b79aad730766c086a5d4a55cad789ee048fd20ced44a27e999191fbd278
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Reusable core NixOS module for system-wide behavior.
- **Repository path:** `modules/core/fonts.nix`
- **Source kind:** text
- **Size:** 717 bytes, 37 lines
- **SHA-256:** `f8d92b79aad730766c086a5d4a55cad789ee048fd20ced44a27e999191fbd278`

## Searchable Metadata
- **Keywords:** Noto, DejaVu, serif, Default, Sans, fonts, true, Mono, pkgs, emoji, Nerd, JetBrainsMono, Font, Maple, Color
- **Parent:** [[Files/modules/core|modules/core]]

### Detected Declarations / Headings
- `fonts =`
- `packages =`
- `#`
- `#`
- `fontconfig =`
- `enable =`
- `antialias =`
- `defaultFonts =`
- `monospace =`
- `sansSerif =`
- `serif =`
- `emoji =`

## Source
```
nix
{ pkgs, ... }:
{
  fonts = {
    fontDir.enable = true;
    packages = with pkgs; [
      # Nerd Fonts
      maple-mono.NF
      pkgs.nerd-fonts.jetbrains-mono

      # Normal Fonts
      noto-fonts
      noto-fonts-color-emoji
    ];
    fontconfig = {
      enable = true;
      antialias = true;
      defaultFonts = {
        monospace = [
          "JetBrainsMono Nerd Font"
          "Maple Mono NF"
          "Noto Mono"
          "DejaVu Sans Mono" # Default
        ];
        sansSerif = [
          "Noto Sans"
          "DejaVu Sans" # Default
        ];
        serif = [
          "Noto Serif"
          "DejaVu Serif" # Default
        ];
        emoji = [ "Noto Color Emoji" ];
      };
    };
  };
}
```
