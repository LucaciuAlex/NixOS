# modules/core/sddm.nix 
---
type: repository-file
source_path: "modules/core/sddm.nix"
source_kind: text
extension: "nix"
bytes: 1294
sha256: 47da9efa7df708513a2362270dd6edd26fad8635ac899045eb933a7b0511b353
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Reusable core NixOS module for system-wide behavior.
- **Repository path:** `modules/core/sddm.nix`
- **Source kind:** text
- **Size:** 1294 bytes, 52 lines
- **SHA-256:** `47da9efa7df708513a2362270dd6edd26fad8635ac899045eb933a7b0511b353`

## Searchable Metadata
- **Keywords:** sddmTheme, true, Sddm, center, else, then, lib.hasSuffix, sddmDependencies, Dependency, PartialBlur, FormPosition, right, left, false, sddm-astronaut
- **Parent:** [[Files/modules/core|modules/core]]

### Detected Declarations / Headings
- `sddm-astronaut =`
- `embeddedTheme =`
- `themeConfig =`
- `ScreenPadding =`
- `FormPosition =`
- `PartialBlur =`
- `FormPosition =`
- `PartialBlur =`
- `sddmDependencies =`
- `sddm =`
- `enable =`
- `enableHidpi =`

### Detected References
- `import ../../hosts/${host}/variables.nix) sddmTheme;`

## Source
```
nix
{
  pkgs,
  lib,
  host,
  ...
}:
let
  inherit (import ../../hosts/${host}/variables.nix) sddmTheme;
  sddm-astronaut = pkgs.sddm-astronaut.override {
    embeddedTheme = "${sddmTheme}";
    themeConfig =
      if lib.hasSuffix "black_hole" sddmTheme then
        {
          ScreenPadding = "";
          FormPosition = "center"; # left, center, right
        }
      else if lib.hasSuffix "astronaut" sddmTheme then
        {
          PartialBlur = "false";
          FormPosition = "center"; # left, center, right
        }
      else if lib.hasSuffix "purple_leaves" sddmTheme then
        {
          PartialBlur = "false";
        }
      else
        { };
  };
  sddmDependencies = [
        sddm-astronaut
        pkgs.kdePackages.qtsvg # Sddm Dependency
        pkgs.kdePackages.qtmultimedia # Sddm Dependency
        pkgs.kdePackages.qtvirtualkeyboard # Sddm Dependency
      ];
in
{
  services.displayManager = {
    sddm = {
      enable = true;
      wayland.enable = true;
      enableHidpi = true;
      autoNumlock = true;
      package = lib.mkForce pkgs.kdePackages.sddm;
      extraPackages = sddmDependencies;
      settings.Theme.CursorTheme = "Bibata-Modern-Classic";
      theme = "sddm-astronaut-theme";
    };
  };

  environment.systemPackages = sddmDependencies;
}
```
