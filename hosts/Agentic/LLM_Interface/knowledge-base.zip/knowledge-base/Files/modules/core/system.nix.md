# modules/core/system.nix 
---
type: repository-file
source_path: "modules/core/system.nix"
source_kind: text
extension: "nix"
bytes: 3571
sha256: 84626b1633f0fae5751950af5f825b68b7ab8c594948b8c25e02c41dadb2e0f7
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Reusable core NixOS module for system-wide behavior.
- **Repository path:** `modules/core/system.nix`
- **Source kind:** text
- **Size:** 3571 bytes, 127 lines
- **SHA-256:** `84626b1633f0fae5751950af5f825b68b7ab8c594948b8c25e02c41dadb2e0f7`

## Searchable Metadata
- **Keywords:** true, locale, https, overlays, set, enable, are, false, evdev, nix, but, environment.variables, Package, Settings, not
- **Parent:** [[Files/modules/core|modules/core]]

### Detected Declarations / Headings
- `imports =`
- `programs =`
- `enable =`
- `enableSSHSupport =`
- `enable =`
- `excludePackages =`
- `exportConfiguration =`
- `xkb =`
- `layout =`
- `variant =`
- `options =`
- `nix =`

### Detected References
- `import ../../hosts/${host}/variables.nix)`
- `imports = [ inputs.nix-index-database.nixosModules.nix-index ];`

## Source
```
nix
{
  lib,
  self,
  inputs,
  host,
  pkgs,
  overlays,
  ...
}:
let
  inherit (import ../../hosts/${host}/variables.nix)
    consoleKeymap
    kbdLayout
    kbdVariant
    locale
    timezone
    capslockAsESC
    ;
in
{
  imports = [ inputs.nix-index-database.nixosModules.nix-index ];
  programs = {
    nix-index-database.comma.enable = true;
    gnupg.agent = {
      enable = true;
      enableSSHSupport = true;
    };
  };
  services.xserver = {
    enable = true;
    excludePackages = with pkgs; [ xterm ];
    exportConfiguration = true; # Make sure /etc/X11/xkb is populated so localectl works correctly
    xkb = {
      layout = "${kbdLayout}";
      variant = "${kbdVariant}";
      options = "caps:swapescape";
    };
  };
  nix = {
    # Nix Package Manager Settings
    settings = {
      trusted-users = [
        "root"
        "@wheel"
      ]; # Required by Cachix to be used as non-root user
      accept-flake-config = true;
      builders-use-substitutes = true;
      download-buffer-size = 200000000;
      auto-optimise-store = true; # May make rebuilds longer but less size
      substituters = [
        "https://cache.nixos.org/"
        "https://nix-community.cachix.org/"
        "https://hyprland.cachix.org/"
        "https://noctalia.cachix.org"
        # "https://nix-gaming.cachix.org"
        # "https://chaotic-nyx.cachix.org"
        # "https://devenv.cachix.org"
      ];
      trusted-public-keys = [
        "cache.nixos.org-1:6NCHdD59X431o0gWypbMrAURkbJ16ZPMQFGspcDShjY="
        "nix-community.cachix.org-1:mB9FSh9qf2dCimDSUo8Zy7bkq5CX+/rkCWyvRCYg3Fs="
        "hyprland.cachix.org-1:a7pgxzMz7+chwVL3/pzj6jIBMioiJM7ypFP8PwtkuGc="
        "noctalia.cachix.org-1:pCOR47nnMEo5thcxNDtzWpOxNFQsBRglJzxWPp3dkU4="
        # "nix-gaming.cachix.org-1:nbjlureqMbRAxR1gJ/f3hxemL9svXaZF/Ees8vCUUs4="
        # "chaotic-nyx.cachix.org-1:HfnXSw4pj95iI/n17rIDy40agHj12WfF+Gqk6SonIT8="
        # "devenv.cachix.org-1:w1cLUi8dv3hnoSPGAuibQv+f9TZLr6cv/Hm9XgU50cw="
      ];
      experimental-features = [
        "nix-command"
        "flakes"
      ];
      use-xdg-base-directories = false;
      warn-dirty = false;
      keep-outputs = true;
      keep-derivations = true;
    };
    optimise.automatic = true;
    package = pkgs.nix;
  };
  time.timeZone = "${timezone}";
  i18n.defaultLocale = "${locale}";
  i18n.extraLocaleSettings = {
    LC_ADDRESS = "${locale}";
    LC_IDENTIFICATION = "${locale}";
    LC_MEASUREMENT = "${locale}";
    LC_MONETARY = "${locale}";
    LC_NAME = "${locale}";
    LC_NUMERIC = "${locale}";
    LC_PAPER = "${locale}";
    LC_TELEPHONE = "${locale}";
    LC_TIME = "${locale}";
  };
  environment.variables = {
    templates = "${self}/dev-shells";
    NIXOS_OZONE_WL = "1";

    # These are the defaults, and xdg.enable does set them, but due to load
    # order, they're not set before environment.variables are set, which could
    # cause race conditions.
    XDG_CACHE_HOME = "$HOME/.cache";
    XDG_CONFIG_HOME = "$HOME/.config";
    XDG_DATA_HOME = "$HOME/.local/share";
    XDG_BIN_HOME = "$HOME/.local/bin";
  };

  console.keyMap = "${consoleKeymap}";
  nixpkgs = {
    overlays = builtins.attrValues overlays;
    config = {
      allowUnfree = true;
      # allowUnfreePredicate = _: true;
    };
  };
  system.stateVersion = "26.05"; # Do not change!
}
// lib.optionalAttrs capslockAsESC {
  services.udev.extraHwdb = ''
    evdev:atkbd:*
      KEYBOARD_KEY_3a=esc
      KEYBOARD_KEY_01=capslock

    evdev:input:b*v*p*e*:
      KEYBOARD_KEY_3a=esc
      KEYBOARD_KEY_01=capslock
  '';
}
```
