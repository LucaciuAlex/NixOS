# modules/core/flatpak.nix 
---
type: repository-file
source_path: "modules/core/flatpak.nix"
source_kind: text
extension: "nix"
bytes: 1375
sha256: 3621839adc899b3ae46412f05c0d563531b472afc2579e62e5baecb6f0dd0747
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Reusable core NixOS module for system-wide behavior.
- **Repository path:** `modules/core/flatpak.nix`
- **Source kind:** text
- **Size:** 1375 bytes, 37 lines
- **SHA-256:** `3621839adc899b3ae46412f05c0d563531b472afc2579e62e5baecb6f0dd0747`

## Searchable Metadata
- **Keywords:** flatpak, Manage, flatpaks, you, and, penguinburner, the, Doom, FPS, e.g., Classic, true, swit, update.onActivation, nixos-rebuild
- **Parent:** [[Files/modules/core|modules/core]]

### Detected Declarations / Headings
- `imports =`
- `services =`
- `flatpak =`
- `enable =`
- `#`
- `#`
- `#`
- `#`
- `#`
- `#`
- `#`
- `#`

### Detected References
- `imports = [ inputs.nix-flatpak.nixosModules.nix-flatpak ];`

## Source
```
nix
{ lib, inputs, ... }:
{
  imports = [ inputs.nix-flatpak.nixosModules.nix-flatpak ];
  services = {
    flatpak = {
      enable = true;

      # remotes = lib.mkOptionDefault [
      #   {
      #     name = "penguinburner";
      #     location = "https://jpietek.github.io/PenguinBurner/penguin-burner.flatpakrepo";
      #   }
      # ];

      # List the Flatpak applications you want to install
      # Use the official Flatpak application ID (e.g., from flathub.org)
      # Examples:
      packages = [
        "com.github.tchx84.Flatseal" # Manage flatpak permissions - should always have this
        "io.github.flattool.Warehouse" # Manage flatpaks, clean data, remove flatpaks and deps
        #"it.mijorus.gearlever"           # Manage and support AppImages
        #"com.rtosta.zapzap"              # WhatsApp client
        #"io.github.freedoom.Phase1"      #  Classic Doom FPS 1
        #"io.github.freedoom.Phase2"      #  Classic Doom FPS 2
        #"io.github.dvlv.boxbuddyrs"      #  Manage distroboxes
        #"de.schmidhuberj.tubefeeder"     # watch YT videos

        # Add other Flatpak IDs here, e.g., "org.mozilla.firefox"
        # { appId = "io.github.jpietek.PenguinBurner"; origin = "penguinburner";  }
      ];

      # Optional: Automatically update Flatpaks when you run nixos-rebuild swit ch
      update.onActivation = true;
    };
  };
}
```
