# modules/core/printing.nix 
---
type: repository-file
source_path: "modules/core/printing.nix"
source_kind: text
extension: "nix"
bytes: 267
sha256: bb9b38dbb4b17820bff16fe54524ac00418411a967d691a9b4dd568f8c90badb
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Reusable core NixOS module for system-wide behavior.
- **Repository path:** `modules/core/printing.nix`
- **Source kind:** text
- **Size:** 267 bytes, 18 lines
- **SHA-256:** `bb9b38dbb4b17820bff16fe54524ac00418411a967d691a9b4dd568f8c90badb`

## Searchable Metadata
- **Keywords:** true, enable, avahi, nssmdns4, openFirewall, ipp-usb.enable, printing, services, pkgs.hplipWithPlugin, drivers
- **Parent:** [[Files/modules/core|modules/core]]

### Detected Declarations / Headings
- `services =`
- `printing =`
- `enable =`
- `drivers =`
- `#`
- `#`
- `#`
- `#`
- `#`
- `#`
- `#`

## Source
```
nix
{ ... }:
{
  services = {
    printing = {
      enable = true;
      drivers = [
        # pkgs.hplipWithPlugin
      ];
    };
    # avahi = {
    #   enable = true;
    #   nssmdns4 = true;
    #   openFirewall = true;
    # };
    # ipp-usb.enable = true;
  };
}
```
