# modules/core/nh.nix 
---
type: repository-file
source_path: "modules/core/nh.nix"
source_kind: text
extension: "nix"
bytes: 353
sha256: 83abf13a016f5b8fc5d85f77287e096412d66bf71ecab41b7f2cefecc7062a96
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Reusable core NixOS module for system-wide behavior.
- **Repository path:** `modules/core/nh.nix`
- **Source kind:** text
- **Size:** 353 bytes, 20 lines
- **SHA-256:** `83abf13a016f5b8fc5d85f77287e096412d66bf71ecab41b7f2cefecc7062a96`

## Searchable Metadata
- **Keywords:** username, enable, true, pkgs, host, flake, environment.systemPackages, nvd, nix-output-monitor, with, extraArgs, import, inherit, let, clean
- **Parent:** [[Files/modules/core|modules/core]]

### Detected Declarations / Headings
- `enable =`
- `clean =`
- `enable =`
- `extraArgs =`
- `flake =`
- `#`
- `#`
- `#`
- `#`

### Detected References
- `import ../../hosts/${host}/variables.nix) username;`

## Source
```
nix
{ host, pkgs, ... }:
let
  inherit (import ../../hosts/${host}/variables.nix) username;
in
{
  programs.nh = {
    enable = true;
    clean = {
      enable = true;
      extraArgs = "--keep-since 7d --keep 3";
    };
    flake = "/home/${username}/NixOS";
  };

  # environment.systemPackages = with pkgs; [
  #   nix-output-monitor
  #   nvd
  # ];
}
```
