# modules/core/hardware.nix 
---
type: repository-file
source_path: "modules/core/hardware.nix"
source_kind: text
extension: "nix"
bytes: 1095
sha256: 9ea5e4ce15fafc63258d04c5a2b3df90cea81acb0bf7c57fa070ea51ee9c0519
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Reusable core NixOS module for system-wide behavior.
- **Repository path:** `modules/core/hardware.nix`
- **Source kind:** text
- **Size:** 1095 bytes, 44 lines
- **SHA-256:** `9ea5e4ce15fafc63258d04c5a2b3df90cea81acb0bf7c57fa070ea51ee9c0519`

## Searchable Metadata
- **Keywords:** true, bluetoothSupport, hostname, enable, false, host, always, JustWorksRepairing, General, KernelExperimental, ControllerMode, Name, dual, Experimental, FastConnectable
- **Parent:** [[Files/modules/core|modules/core]]

### Detected Declarations / Headings
- `hardware =`
- `sane =`
- `enable =`
- `extraBackends =`
- `disabledDefaultBackends =`
- `enableRedistributableFirmware =`
- `bluetooth =`
- `enable =`
- `powerOnBoot =`
- `settings =`
- `General =`
- `Name =`

### Detected References
- `import ../../hosts/${host}/variables.nix) hostname bluetoothSupport;`

## Source
```
nix
{ pkgs, host, ... }:
let
  inherit (import ../../hosts/${host}/variables.nix) hostname bluetoothSupport;
in
{
  hardware = {
    sane = {
      enable = true;
      extraBackends = [ pkgs.sane-airscan ];
      disabledDefaultBackends = [ "escl" ];
    };
    logitech.wireless.enable = false;
    logitech.wireless.enableGraphical = false;
    graphics.enable = true;
    enableRedistributableFirmware = true;
    keyboard.qmk.enable = true;
    bluetooth = {
      enable = bluetoothSupport;
      powerOnBoot = bluetoothSupport;
      settings = {
        General = {
          Name = hostname;
          ControllerMode = "dual";
          FastConnectable = true;
          Experimental = true;
          KernelExperimental = true;
          JustWorksRepairing = "always";
          SecureConnections = "on";
        };
        GATT = {
          Cache = "always";
          Channels = 3;
        };
        Policy = {
          AutoEnable = true;
          ReconnectAttempts = 7;
          ReconnectIntervals = "1,2,4,8,16,32,64";
          ResumeDelay = 1;
        };
      };
    };
  };
}
```
