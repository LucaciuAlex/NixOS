# modules/hardware  This page represents the repository directory `modules/hardware` and links to its indexed files.  ## Files
- [[modules/hardware/drives/default.nix.md|modules/hardware/drives/default.nix]]
- [[modules/hardware/drives/games.nix.md|modules/hardware/drives/games.nix]]
- [[modules/hardware/drives/work.nix.md|modules/hardware/drives/work.nix]]
- [[modules/hardware/video/amdgpu.nix.md|modules/hardware/video/amdgpu.nix]]
- [[modules/hardware/video/intel.nix.md|modules/hardware/video/intel.nix]]
- [[modules/hardware/video/nvidia.nix.md|modules/hardware/video/nvidia.nix]]
- [[modules/hardware/video/nvk.nix.md|modules/hardware/video/nvk.nix]]
