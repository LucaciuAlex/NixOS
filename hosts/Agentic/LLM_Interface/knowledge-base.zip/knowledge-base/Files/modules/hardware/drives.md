# modules/hardware/drives  This page represents the repository directory `modules/hardware/drives` and links to its indexed files.  ## Files
- [[modules/hardware/drives/default.nix.md|modules/hardware/drives/default.nix]]
- [[modules/hardware/drives/games.nix.md|modules/hardware/drives/games.nix]]
- [[modules/hardware/drives/work.nix.md|modules/hardware/drives/work.nix]]
