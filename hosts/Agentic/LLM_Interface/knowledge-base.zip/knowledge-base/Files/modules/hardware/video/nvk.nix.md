# modules/hardware/video/nvk.nix 
---
type: repository-file
source_path: "modules/hardware/video/nvk.nix"
source_kind: text
extension: "nix"
bytes: 1524
sha256: 0b65343da50c425e1257470ab67029d52128ec06191ec17fdc351dcc8e58a8bd
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Hardware, driver, storage, or device configuration.
- **Repository path:** `modules/hardware/video/nvk.nix`
- **Source kind:** text
- **Size:** 1524 bytes, 58 lines
- **SHA-256:** `0b65343da50c425e1257470ab67029d52128ec06191ec17fdc351dcc8e58a8bd`

## Searchable Metadata
- **Keywords:** nouveau, not, This, sure, env, needed, modesetting, pkgs, mesa, info, with, zink, nvidia, true, lib.mkDefault
- **Parent:** [[Files/modules/hardware/video|modules/hardware/video]]

### Detected Declarations / Headings
- `#`
- `env =`
- `NVK_I_WANT_A_BROKEN_VULKAN_DRIVER =`
- `MESA_LOADER_DRIVER_OVERRIDE =`
- `GALLIUM_DRIVER =`
- `GBM_BACKEND =`
- `WLR_RENDERER =`
- `WLR_NO_HARDWARE_CURSORS =`
- `__GL_GSYNC_ALLOWED =`
- `boot =`
- `kernelParams =`
- `#`

### Detected References
- `source user-space driver and is not recommended to use as of 30/05/24 since it's unstable`

## Source
```
nix
# This module uses nouveau with NVK which is the nvidia open-source user-space driver and is not recommended to use as of 30/05/24 since it's unstable
{ pkgs, lib, ... }:
let
  env = {
    NVK_I_WANT_A_BROKEN_VULKAN_DRIVER = "1"; # Adds support for older gpus
    MESA_LOADER_DRIVER_OVERRIDE = "zink";
    GALLIUM_DRIVER = "zink";

    GBM_BACKEND = "nouveau";
    WLR_RENDERER = "vulkan";
    WLR_NO_HARDWARE_CURSORS = "1";
    __GL_GSYNC_ALLOWED = "1"; # GSync
  };
in
{
  boot = {
    kernelParams = [
      "nouveau.modeset=1"
      "nouveau.config=NvGspRm=1"
      # "nouveau.debug=info,VBIOS=info,gsp=debug" # TODO Remove
    ];
    kernelModules = [ "nouveau" ];
    blacklistedKernelModules = [
      "nvidia"
      "nvidia_uvm"
    ];
  };

  environment.sessionVariables = env;
  environment.variables = env;

  services.xserver.videoDrivers = [ "modesetting" ]; # "modesetting" is better than "nouveau"

  hardware = {
    # nvidia.package = lib.mkDefault config.boot.kernelPackages.nvidiaPackages.latest;
    graphics = {
      enable = true;
      enable32Bit = true;
      extraPackages = with pkgs; [
        mesa # Enables mesa

        nvidia-vaapi-driver # Not sure if this is needed
        libva-vdpau-driver # Not sure if this is needed
        libvdpau-va-gl # Not sure if this is needed
      ];
    };
  };
  # Fix black screen issues
  home-manager.sharedModules = [
    (
      { config, ... }:
      {
        wayland.windowManager.hyprland.settings.misc.vrr = lib.mkForce 0;
      }
    )
  ];
}
```
