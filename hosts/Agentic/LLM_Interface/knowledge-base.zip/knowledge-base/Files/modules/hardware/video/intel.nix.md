# modules/hardware/video/intel.nix 
---
type: repository-file
source_path: "modules/hardware/video/intel.nix"
source_kind: text
extension: "nix"
bytes: 1113
sha256: 77661d2b9313184bb24a619a2357db7ffb45e293c9a3c76f0de1b9809ba59e89
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Hardware, driver, storage, or device configuration.
- **Repository path:** `modules/hardware/video/intel.nix`
- **Source kind:** text
- **Size:** 1113 bytes, 40 lines
- **SHA-256:** `77661d2b9313184bb24a619a2357db7ffb45e293c9a3c76f0de1b9809ba59e89`

## Searchable Metadata
- **Keywords:** true, pkgs, power, with, Enable, intel-vaapi-driver, services.throttled.enable, saving, nvme.noacpi, Helps, consumption, NVME, services.thermald.enable, Display, Allow
- **Parent:** [[Files/modules/hardware/video|modules/hardware/video]]

### Detected Declarations / Headings
- `intel-vaapi-driver =`
- `LIBVA_DRIVER_NAME =`
- `#`
- `#`
- `enable =`
- `extraPackages =`
- `#`

## Source
```
nix
{ pkgs, lib, config, ... }:
{
  nixpkgs.config.packageOverrides = pkgs: {
    intel-vaapi-driver = pkgs.intel-vaapi-driver.override { enableHybridCodec = true; };
  };

  environment.sessionVariables = lib.optionalAttrs config.programs.hyprland.enable {
    LIBVA_DRIVER_NAME = "iHD";
  };

  boot.kernelParams = [
    "intel_pstate=active"
    "i915.enable_guc=2" # Enable GuC/HuC firmware loading
    "i915.enable_psr=1" # Panel Self Refresh for power savings
    "i915.enable_fbc=1" # Framebuffer compression
    "i915.fastboot=1" # Skip unnecessary mode sets at boot
    "mem_sleep_default=deep" # Allow deepest sleep states
    "i915.enable_dc=2" # Display power saving
    "nvme.noacpi=1" # Helps with NVME power consumption
  ];

  # Load the driver
  services.xserver.videoDrivers = [ "modesetting" ];

  # OpenGL
  hardware.graphics = {
    enable = true;
    extraPackages = with pkgs; [
      intel-media-driver
      intel-vaapi-driver
      libva-vdpau-driver
      libvdpau-va-gl
    ];
  };

  # Thermal and Noise Management
  services.thermald.enable = true;
  services.throttled.enable = true;
}
```
