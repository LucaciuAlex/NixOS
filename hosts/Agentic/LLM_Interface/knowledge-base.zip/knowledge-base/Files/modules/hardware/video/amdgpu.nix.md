# modules/hardware/video/amdgpu.nix 
---
type: repository-file
source_path: "modules/hardware/video/amdgpu.nix"
source_kind: text
extension: "nix"
bytes: 260
sha256: 6dfb95d72a943c660dc6ec9cf8171b58097085d60e3e480395767b1c723a7520
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Hardware, driver, storage, or device configuration.
- **Repository path:** `modules/hardware/video/amdgpu.nix`
- **Source kind:** text
- **Size:** 260 bytes, 13 lines
- **SHA-256:** `6dfb95d72a943c660dc6ec9cf8171b58097085d60e3e480395767b1c723a7520`

## Searchable Metadata
- **Keywords:** true, pkgs, with, amdgpu, environment.systemPackages, opencl.enable, hardware.amdgpu, rocmPackages.amdsmi, videoDrivers, Already, enable, services.xserver, manager, display, enabled
- **Parent:** [[Files/modules/hardware/video|modules/hardware/video]]

### Detected Declarations / Headings
- `#`
- `videoDrivers =`

## Source
```
nix
{ pkgs, ... }:

{
  services.xserver = {
    # enable = true;  # Already enabled in display manager
    videoDrivers = [ "amdgpu" ];
  };
  environment.systemPackages = with pkgs; [ rocmPackages.amdsmi ];
  hardware.amdgpu = {
    opencl.enable = true;
  };
}
```
