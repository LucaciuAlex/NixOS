# modules/hardware/drives/default.nix 
---
type: repository-file
source_path: "modules/hardware/drives/default.nix"
source_kind: text
extension: "nix"
bytes: 63
sha256: b9b3a2b71f89277c172aa43895a55718190b96c6b731b85f3905b01a01226bd6
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Hardware, driver, storage, or device configuration.
- **Repository path:** `modules/hardware/drives/default.nix`
- **Source kind:** text
- **Size:** 63 bytes, 8 lines
- **SHA-256:** `b9b3a2b71f89277c172aa43895a55718190b96c6b731b85f3905b01a01226bd6`

## Searchable Metadata
- **Keywords:** imports
- **Parent:** [[Files/modules/hardware/drives|modules/hardware/drives]]

### Detected Declarations / Headings
- `imports =`

### Detected References
- `imports = [`

## Source
```
nix
{ ... }:
{
  imports = [
    ./games.nix
    ./work.nix
  ];
}
```
