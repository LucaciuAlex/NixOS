# modules/hardware/video  This page represents the repository directory `modules/hardware/video` and links to its indexed files.  ## Files
- [[modules/hardware/video/amdgpu.nix.md|modules/hardware/video/amdgpu.nix]]
- [[modules/hardware/video/intel.nix.md|modules/hardware/video/intel.nix]]
- [[modules/hardware/video/nvidia.nix.md|modules/hardware/video/nvidia.nix]]
- [[modules/hardware/video/nvk.nix.md|modules/hardware/video/nvk.nix]]
