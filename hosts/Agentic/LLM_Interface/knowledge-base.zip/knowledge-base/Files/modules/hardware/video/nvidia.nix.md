# modules/hardware/video/nvidia.nix 
---
type: repository-file
source_path: "modules/hardware/video/nvidia.nix"
source_kind: text
extension: "nix"
bytes: 1753
sha256: 7a944be4e08ea051d1fffde7435fd40f7f0e8b7ae5b8e58065b0ede5be558646
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Hardware, driver, storage, or device configuration.
- **Repository path:** `modules/hardware/video/nvidia.nix`
- **Source kind:** text
- **Size:** 1753 bytes, 66 lines
- **SHA-256:** `7a944be4e08ea051d1fffde7435fd40f7f0e8b7ae5b8e58065b0ede5be558646`

## Searchable Metadata
- **Keywords:** nvidia, true, nvidiaChannel, pkg, config.boot.kernelPackages.nvidiaPackages., package, false, pkgs, host, Fixes, powerManagement.enable, Modesetting, modesetting.enable, nvidia.NVreg_RegistryDwords, required.
- **Parent:** [[Files/modules/hardware/video|modules/hardware/video]]

### Detected Declarations / Headings
- `GBM_BACKEND =`
- `WLR_NO_HARDWARE_CURSORS =`
- `LIBVA_DRIVER_NAME =`
- `__GLX_VENDOR_LIBRARY_NAME =`
- `#`
- `__GL_GSYNC_ALLOWED =`
- `__GL_VRR_ALLOWED =`
- `__GL_MaxFramesAllowed =`
- `#`
- `hardware =`
- `nvidia =`
- `open =`

### Detected References
- `import ../../../hosts/${host}/variables.nix) nvidiaChannel;`

## Source
```
nix
{
  host,
  lib,
  pkgs,
  config,
  ...
}:
let
  inherit (import ../../../hosts/${host}/variables.nix) nvidiaChannel;
in
{
  environment.sessionVariables = lib.optionalAttrs config.programs.hyprland.enable {
    GBM_BACKEND = "nvidia-drm";
    WLR_NO_HARDWARE_CURSORS = "1";
    LIBVA_DRIVER_NAME = "nvidia";
    __GLX_VENDOR_LIBRARY_NAME = "nvidia";
    # MOZ_DISABLE_RDD_SANDBOX = 1; # Potential security risk

    __GL_GSYNC_ALLOWED = "1"; # GSync
    __GL_VRR_ALLOWED = "1"; # VRR
    __GL_MaxFramesAllowed = "1"; # Reduces input lag
  };

  # Load nvidia driver for Xorg and Wayland
  services.xserver.videoDrivers = [ "nvidia" ]; # or "nvidiaLegacy470", etc.
  boot.kernelParams = lib.optionals (lib.elem "nvidia" config.services.xserver.videoDrivers) [
    "nvidia-drm.modeset=1"
    "nvidia_drm.fbdev=1"

    "nvidia.NVreg_RegistryDwords=RmEnableAggressiveVblank=1" # Experimental: reduce latency
  ];
  hardware = {
    nvidia = {
      open = false;
      # nvidiaPersistenced = true;
      nvidiaSettings = false;
      powerManagement.enable = true; # Fixes sleep/suspend

      modesetting.enable = true; # Modesetting is required.

      package = config.boot.kernelPackages.nvidiaPackages.${nvidiaChannel};
    };
    graphics = {
      enable = true;
      # package = config.boot.kernelPackages.nvidiaPackages.${nvidiaChannel};
      enable32Bit = true;
      extraPackages = with pkgs; [
        nvidia-vaapi-driver
        libva-vdpau-driver
        libvdpau-va-gl
      ];
    };
  };
  nixpkgs.config = {
    nvidia.acceptLicense = true;
    allowUnfreePredicate =
      pkg:
      builtins.elem (lib.getName pkg) [
        "cudatoolkit"
        "nvidia-persistenced"
        "nvidia-settings"
        "nvidia-x11"
      ];
  };
}
```
