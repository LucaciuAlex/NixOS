# modules/hardware/drives/work.nix 
---
type: repository-file
source_path: "modules/hardware/drives/work.nix"
source_kind: text
extension: "nix"
bytes: 451
sha256: 4ec4c1d2d5f72ebeae0b1e74116fc83d0faa99add591bdc9c1e6faf710ea3cc9
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Hardware, driver, storage, or device configuration.
- **Repository path:** `modules/hardware/drives/work.nix`
- **Source kind:** text
- **Size:** 451 bytes, 16 lines
- **SHA-256:** `4ec4c1d2d5f72ebeae0b1e74116fc83d0faa99add591bdc9c1e6faf710ea3cc9`

## Searchable Metadata
- **Keywords:** async, error, Show, file, x-gvfs-show, exist, not, plugged, explorer, Make, dir, doesn, X-mount.mkdir, x-systemd.mount-timeout, Timout
- **Parent:** [[Files/modules/hardware/drives|modules/hardware/drives]]

### Detected Declarations / Headings
- `device =`
- `fsType =`
- `options =`

## Source
```
nix
{ lib, ... }:
{
  fileSystems."/mnt/work" = lib.mkForce {
    device = "/dev/disk/by-uuid/f6f6d68c-68f8-4c50-8155-105a22b9ff35";
    fsType = "ext4";
    options = [
      "defaults" # Default flags
      "async" # Run all operations async
      "nofail" # Don't error if not plugged in
      "x-gvfs-show" # Show in file explorer
      "x-systemd.mount-timeout=5" # Timout for error
      "X-mount.mkdir" # Make dir if it doesn't exist
    ];
  };
}
```
