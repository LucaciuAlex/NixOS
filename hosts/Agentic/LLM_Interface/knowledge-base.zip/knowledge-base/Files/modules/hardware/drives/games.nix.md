# modules/hardware/drives/games.nix 
---
type: repository-file
source_path: "modules/hardware/drives/games.nix"
source_kind: text
extension: "nix"
bytes: 311
sha256: 8f470117cac8e8a9b7f2338bee3bf2ad7fc3499fe5010bccb9a4e1db0b824dfd
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Hardware, driver, storage, or device configuration.
- **Repository path:** `modules/hardware/drives/games.nix`
- **Source kind:** text
- **Size:** 311 bytes, 18 lines
- **SHA-256:** `8f470117cac8e8a9b7f2338bee3bf2ad7fc3499fe5010bccb9a4e1db0b824dfd`

## Searchable Metadata
- **Keywords:** noatime, gid, uid, umask, x-systemd.mount-timeout, x-gvfs-show, nofail, lib.mkForce, fileSystems., lib, device, options, ntfs-3g, fsType
- **Parent:** [[Files/modules/hardware/drives|modules/hardware/drives]]

### Detected Declarations / Headings
- `device =`
- `fsType =`
- `options =`

## Source
```
nix
{ lib, ... }:
{
  fileSystems."/mnt/games" = lib.mkForce {
    device = "/dev/disk/by-uuid/01DA12C1CBDE9100";
    fsType = "ntfs-3g";
    options = [
      "rw"
      "uid=1000"
      "gid=100"
      "noatime"
      "umask=000"
      "nofail"
      "x-gvfs-show"
      "x-systemd.mount-timeout=5"
    ];
  };
}
```
