# modules/programs/browser/extensions.nix 
---
type: repository-file
source_path: "modules/programs/browser/extensions.nix"
source_kind: text
extension: "nix"
bytes: 9265
sha256: 9b39de30d38088244ffd164b619afcced36d2209e7a5b9213ca4c2d158853fe2
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Program-specific NixOS or Home Manager configuration.
- **Repository path:** `modules/programs/browser/extensions.nix`
- **Source kind:** text
- **Size:** 9265 bytes, 227 lines
- **SHA-256:** `9b39de30d38088244ffd164b619afcced36d2209e7a5b9213ca4c2d158853fe2`

## Searchable Metadata
- **Keywords:** https, true, installation_mode, install_url, force_installed, private_browsing, default_area, false, navbar, Addon, for, file, Anti-Malware, Sprout, bpc-paywall-filter.txt
- **Parent:** [[Files/modules/programs/browser|modules/programs/browser]]

### Detected Declarations / Headings
- `nav-bar =`
- `#`
- `#`
- `#`
- `unified-extensions-area =`
- `#`
- `extensionSettings =`
- `blocked_install_message =`
- `installation_mode =`
- `private_browsing =`
- `default_area =`
- `installation_mode =`

### Detected References
- `url = "https://addons.mozilla.org/firefox/downloads/latest/ublock-origin/latest.xpi";`
- `url = "https://addons.mozilla.org/firefox/downloads/latest/firemonkey/latest.xpi";`
- `url = "https://addons.mozilla.org/firefox/downloads/latest/web-clipper-obsidian/latest.xpi";`
- `url = "https://addons.mozilla.org/firefox/downloads/latest/600-sound-volume-privacy/latest.xpi";`
- `url = "https://addons.mozilla.org/firefox/downloads/latest/onetab/latest.xpi";`
- `url = "https://addons.mozilla.org/firefox/downloads/latest/darkreader/latest.xpi";`
- `url = "https://addons.mozilla.org/firefox/downloads/latest/sponsorblock/latest.xpi";`
- `url = "https://addons.mozilla.org/firefox/downloads/latest/return-youtube-dislikes/latest.xpi";`
- `url = "https://addons.mozilla.org/firefox/downloads/latest/frankerfacez/latest.xpi";`
- `url = "https://github.com/mkaply/queryamoid/releases/download/v0.2/query_amo_addon_id-0.2-fx.xpi";`
- `sourcesLocation"`
- `importedLists = [`

## Source
```
nix
{ lib, ... }:
{
  nav-bar = [
    "extension_one-tab_com-browser-action"
    "clipper_obsidian_md-browser-action"
    "_8454caa8-cebc-4486-8b23-9771f187ed6c_-browser-action"
    "firemonkey_eros_man-browser-action"
    "ublock0_raymondhill_net-browser-action"
    # "addon_darkreader_org-browser-action"
    # "queryamoid_kaply_com-browser-action"
    # "_aecec67f-0d10-4fa7-b7c7-609a2db280cf_-browser-action"
  ];

  unified-extensions-area = [
    "ublock0_raymondhill_net-browser-action"
    "firemonkey_eros_man-browser-action"
    "addon_darkreader_org-browser-action"
    "queryamoid_kaply_com-browser-action"
    # "_aecec67f-0d10-4fa7-b7c7-609a2db280cf_-browser-action"
  ];

  extensionSettings = {
    "*" = {
      blocked_install_message = "Addon is not added in the nix config";
      installation_mode = "blocked";
    };
    "uBlock0@raymondhill.net" = {
      private_browsing = true;
      default_area = "navbar";
      installation_mode = "force_installed";
      install_url = "https://addons.mozilla.org/firefox/downloads/latest/ublock-origin/latest.xpi";
    };
    "firemonkey@eros.man" = {
      private_browsing = true;
      default_area = "navbar";
      installation_mode = "force_installed";
      install_url = "https://addons.mozilla.org/firefox/downloads/latest/firemonkey/latest.xpi";
    };
    "clipper@obsidian.md" = {
      private_browsing = false;
      default_area = "navbar";
      installation_mode = "force_installed";
      install_url = "https://addons.mozilla.org/firefox/downloads/latest/web-clipper-obsidian/latest.xpi";
    };
    "{8454caa8-cebc-4486-8b23-9771f187ed6c}" = {
      private_browsing = true;
      default_area = "navbar";
      installation_mode = "force_installed";
      install_url = "https://addons.mozilla.org/firefox/downloads/latest/600-sound-volume-privacy/latest.xpi";
    };
    "extension@one-tab.com" = {
      private_browsing = false;
      default_area = "navbar";
      installation_mode = "force_installed";
      install_url = "https://addons.mozilla.org/firefox/downloads/latest/onetab/latest.xpi";
    };
    "addon@darkreader.org" = {
      private_browsing = true;
      # default_area = "navbar";
      installation_mode = "force_installed";
      install_url = "https://addons.mozilla.org/firefox/downloads/latest/darkreader/latest.xpi";
    };
    "sponsorBlocker@ajay.app" = {
      private_browsing = true;
      default_area = "menupanel";
      installation_mode = "force_installed";
      install_url = "https://addons.mozilla.org/firefox/downloads/latest/sponsorblock/latest.xpi";
    };
    "{762f9885-5a13-4abd-9c77-433dcd38b8fd}" = {
      private_browsing = true;
      installation_mode = "force_installed";
      install_url = "https://addons.mozilla.org/firefox/downloads/latest/return-youtube-dislikes/latest.xpi";
    };
    "frankerfacez@frankerfacez.com" = {
      private_browsing = true;
      installation_mode = "force_installed";
      install_url = "https://addons.mozilla.org/firefox/downloads/latest/frankerfacez/latest.xpi";
    };
    # View Xpi Id's in Firefox Extension Store
    "queryamoid@kaply.com" = {
      private_browsing = true;
      installation_mode = "force_installed";
      install_url = "https://github.com/mkaply/queryamoid/releases/download/v0.2/query_amo_addon_id-0.2-fx.xpi";
    };
  };

  extensionConfig = {
    "uBlock0@raymondhill.net" = {
      advancedSettings = [
        [
          "userResourcesLocation"
          "https://raw.githubusercontent.com/pixeltris/TwitchAdSolutions/master/video-swap-new/video-swap-new-ublock-origin.js"
        ]
      ];
      adminSettings = {
        userFilters = lib.concatMapStrings (x: x + "\n") [
          "twitch.tv##+js(twitch-videoad)"
          "||1337x.vpnonly.site"
          "||snowvan.xyz^"
        ];
        userSettings = rec {
          uiTheme = "dark";
          uiAccentCustom = true;
          uiAccentCustom0 = "#CA9EE6";
          cloudStorageEnabled = lib.mkForce false;
          advancedUserEnabled = true;
          userFiltersTrusted = true;
          importedLists = [
            "https://raw.githubusercontent.com/reek/anti-adblock-killer/master/anti-adblock-killer-filters.txt"
            "https://easylist-downloads.adblockplus.org/antiadblockfilters.txt"
            "https://gitflic.ru/project/magnolia1234/bypass-paywalls-clean-filters/blob/raw?file=bpc-paywall-filter.txt"
            "https://raw.githubusercontent.com/DandelionSprout/adfilt/master/BrowseWebsitesWithoutLoggingIn.txt"
            "https://raw.githubusercontent.com/DandelionSprout/adfilt/master/ClearURLs for uBo/clear_urls_uboified.txt"
            "https://raw.githubusercontent.com/DandelionSprout/adfilt/master/Dandelion Sprout's Anti-Malware List.txt"
            "https://raw.githubusercontent.com/DandelionSprout/adfilt/master/LegitimateURLShortener.txt"
            # "https://raw.githubusercontent.com/OsborneLabs/Columbia/master/Columbia.txt"
            "https://raw.githubusercontent.com/bogachenko/fuckfuckadblock/master/fuckfuckadblock.txt?_=rawlist"
            "https://raw.githubusercontent.com/iam-py-test/my_filters_001/main/antimalware.txt"
            "https://raw.githubusercontent.com/liamengland1/miscfilters/master/antipaywall.txt"
            "https://raw.githubusercontent.com/yokoffing/filterlists/main/annoyance_list.txt"
            "https://raw.githubusercontent.com/yokoffing/filterlists/main/privacy_essentials.txt"
          ];
          externalLists = lib.concatStringsSep "\n" importedLists;
          popupPanelSections = 31;
        };
        selectedFilterLists = [
          "ublock-filters"
          "ublock-badware"
          "ublock-privacy"
          "ublock-quick-fixes"
          "ublock-unbreak"
          "easylist"
          "adguard-generic"
          "adguard-mobile"
          "easyprivacy"
          "adguard-spyware"
          "adguard-spyware-url"
          "block-lan"
          "urlhaus-1"
          "curben-phishing"
          "plowe-0"
          "dpollock-0"
          "fanboy-cookiemonster"
          "ublock-cookies-easylist"
          "adguard-cookies"
          "ublock-cookies-adguard"
          "fanboy-social"
          "adguard-social"
          "fanboy-thirdparty_social"
          "easylist-chat"
          "easylist-newsletters"
          "easylist-notifications"
          "easylist-annoyances"
          "adguard-mobile-app-banners"
          "adguard-other-annoyances"
          "adguard-popup-overlays"
          "adguard-widgets"
          "ublock-annoyances"
          "DEU-0"
          "FRA-0"
          "NLD-0"
          "RUS-0"
          "https://raw.githubusercontent.com/reek/anti-adblock-killer/master/anti-adblock-killer-filters.txt"
          "https://easylist-downloads.adblockplus.org/antiadblockfilters.txt"
          "https://raw.githubusercontent.com/DandelionSprout/adfilt/master/Dandelion Sprout's Anti-Malware List.txt"
          "https://raw.githubusercontent.com/DandelionSprout/adfilt/master/LegitimateURLShortener.txt"
          "https://raw.githubusercontent.com/DandelionSprout/adfilt/master/BrowseWebsitesWithoutLoggingIn.txt"
          "https://raw.githubusercontent.com/yokoffing/filterlists/main/privacy_essentials.txt"
          "https://raw.githubusercontent.com/yokoffing/filterlists/main/annoyance_list.txt"
          "https://raw.githubusercontent.com/liamengland1/miscfilters/master/antipaywall.txt"
          "https://gitflic.ru/project/magnolia1234/bypass-paywalls-clean-filters/blob/raw?file=bpc-paywall-filter.txt"
          "https://raw.githubusercontent.com/DandelionSprout/adfilt/master/ClearURLs for uBo/clear_urls_uboified.txt"
          "https://raw.githubusercontent.com/iam-py-test/my_filters_001/main/antimalware.txt"
          # "https://raw.githubusercontent.com/OsborneLabs/Columbia/master/Columbia.txt"
          "https://raw.githubusercontent.com/bogachenko/fuckfuckadblock/master/fuckfuckadblock.txt?_=rawlist"
          "user-filters"
        ];
      };
    };
    "addon@darkreader.org" = {
      enabled = true;
      automation = {
        enabled = true;
        behavior = "OnOff";
        mode = "system";
      };
      detectDarkTheme = true;
      enabledByDefault = true;
      changeBrowserTheme = false;
      enableForProtectedPages = true;
      fetchNews = true;
      syncSitesFixes = true;
      previewNewDesign = true;
      # previewNewestDesign = true; # TODO: test

      # Catppuccin mocha theme
      /*
        theme = {
          mode = 1;
          brightness = 100;
          contrast = 100;
          grayscale = 0;
          sepia = 0;
          useFont = false;
          fontFamily = "Open Sans";
          textStroke = 0;
          engine = "dynamicTheme";
          stylesheet = "";
          darkSchemeBackgroundColor = "#1e1e2e";
          darkSchemeTextColor = "#cdd6f4";
          lightSchemeBackgroundColor = "#eff1f5";
          lightSchemeTextColor = "#4c4f69";
          scrollbarColor = "";
          selectionColor = "#585b70"; # For the light scheme: #acb0be
          styleSystemControls = true;
          lightColorScheme = "Default";
          darkColorScheme = "Default";
          immediateModify = false;
        };
      */

      # enabledFor = [];
      # disabledFor = [];
    };
  };
}
```
