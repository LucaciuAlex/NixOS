# modules/programs/browser/firefox/policies.nix 
---
type: repository-file
source_path: "modules/programs/browser/firefox/policies.nix"
source_kind: text
extension: "nix"
bytes: 2008
sha256: 96641242a2d344d8f39127a31714d7bacc38f042ff14c837c69a38afede58ebb
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Program-specific NixOS or Home Manager configuration.
- **Repository path:** `modules/programs/browser/firefox/policies.nix`
- **Source kind:** text
- **Size:** 2008 bytes, 82 lines
- **SHA-256:** `96641242a2d344d8f39127a31714d7bacc38f042ff14c837c69a38afede58ebb`

## Searchable Metadata
- **Keywords:** false, true, Enabled, lib, Value, Locked, SponsoredPocket, Pocket, Highlights, Snippets, ManualAppUpdateOnly, HardwareAcceleration, NoDefaultBookmarks, ExtensionUpdate, EncryptedMediaExtensions
- **Parent:** [[Files/modules/programs/browser/firefox|modules/programs/browser/firefox]]

### Detected Declarations / Headings
- `extensions =`
- `AllowFileSelectionDialogs =`
- `AppAutoUpdate =`
- `AutofillAddressEnabled =`
- `AutofillCreditCardEnabled =`
- `BackgroundAppUpdate =`
- `BlockAboutAddons =`
- `BlockAboutConfig =`
- `BlockAboutProfiles =`
- `BlockAboutSupport =`
- `DisableAppUpdate =`
- `DisableFirefoxAccounts =`

### Detected References
- `import ../extensions.nix { inherit lib; };`

## Source
```
nix
{ lib, ... }:
let
  extensions = import ../extensions.nix { inherit lib; };
in
{
  AllowFileSelectionDialogs = true;
  AppAutoUpdate = false;
  AutofillAddressEnabled = false;
  AutofillCreditCardEnabled = false;
  #AutoLaunchProtocolsFromOrigins = { };
  BackgroundAppUpdate = false;
  BlockAboutAddons = false;
  BlockAboutConfig = false;
  BlockAboutProfiles = false;
  BlockAboutSupport = false;
  #Containers = { };
  DisableAppUpdate = true;
  DisableFirefoxAccounts = true;
  DisableFirefoxScreenshots = true;
  DisableFirefoxStudies = true;
  DisableFormHistory = true;
  DisableMasterPasswordCreation = true;
  DisablePocket = true;
  DisablePrivateBrowsing = false;
  DisableProfileImport = false;
  DisableProfileRefresh = false;
  DisableSafeMode = false;
  DisableTelemetry = true;
  DisableFeedbackCommands = true;
  DontCheckDefaultBrowser = true;
  DNSOverHTTPS = {
    Enabled = true;
  };
  EnableTrackingProtection = {
    Value = true;
    Locked = true;
    Cryptomining = true;
    Fingerprinting = true;
  };
  EncryptedMediaExtensions = {
    Enabled = true;
  };
  ExtensionUpdate = true;
  FirefoxHome = {
    Search = false;
    TopSites = false;
    SponsoredTopSites = false;
    Highlights = false;
    Pocket = false;
    SponsoredPocket = false;
    Snippets = false;
    Locked = false;
  };
  HardwareAcceleration = true;
  ManualAppUpdateOnly = true;
  NoDefaultBookmarks = false;
  OfferToSaveLogins = false;
  PasswordManagerEnabled = false;
  PictureInPicture = {
    Enabled = true;
  };
  PopupBlocking = {
    Allow = [ ];
    Default = true;
  };
  Preferences = {
    "browser.tabs.warnOnClose" = {
      Value = false;
    };
  };
  PromptForDownloadLocation = true;
  SearchSuggestEnabled = false;
  ShowHomeButton = false;
  StartDownloadsInTempDirectory = false;
  UserMessaging = {
    ExtensionRecommendations = false;
    SkipOnboarding = true;
  };
  ExtensionSettings = extensions.extensionSettings;
  "3rdparty".Extensions = extensions.extensionConfig;
}
```
