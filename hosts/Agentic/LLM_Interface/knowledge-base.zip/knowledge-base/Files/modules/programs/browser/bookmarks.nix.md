# modules/programs/browser/bookmarks.nix 
---
type: repository-file
source_path: "modules/programs/browser/bookmarks.nix"
source_kind: text
extension: "nix"
bytes: 3969
sha256: 5e33a7c5a99c8af46ad4600ba71e1f1c6f341a2022873c60dfe73a9e121a1b03
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Program-specific NixOS or Home Manager configuration.
- **Repository path:** `modules/programs/browser/bookmarks.nix`
- **Source kind:** text
- **Size:** 3969 bytes, 144 lines
- **SHA-256:** `5e33a7c5a99c8af46ad4600ba71e1f1c6f341a2022873c60dfe73a9e121a1b03`

## Searchable Metadata
- **Keywords:** name, url, https, NixOS, Bookmarks, Assets, Nix, true, Toolbar, Search, prfe, Startpage, Engines, Tracker, Interactive
- **Parent:** [[Files/modules/programs/browser|modules/programs/browser]]

### Detected Declarations / Headings
- `force =`
- `settings =`
- `name =`
- `toolbar =`
- `bookmarks =`
- `name =`
- `url =`
- `name =`
- `url =`
- `name =`
- `url =`
- `name =`

### Detected References
- `url = "https://www.youtube.com";`
- `url = "https://www.twitch.tv";`
- `url = "https://www.netflix.com";`
- `url = "https://github.com/";`
- `url = "https://chatgpt.com/";`
- `url = "https://arxiv.org/pdf/1904.06560";`
- `url = "https://arxiv.org/pdf/2502.16479";`
- `url = "https://arxiv.org/pdf/2502.01945";`
- `url = "https://arxiv.org/pdf/2502.18450";`
- `url = "https://arxiv.org/pdf/2502.18446";`
- `url = "https://mynixos.com/";`
- `url = "https://wiki.nixos.org/wiki/NixOS_Wiki";`

## Source
```
nix
{
  force = true;
  settings = [
    {
      name = "Bookmarks Toolbar";
      toolbar = true;
      bookmarks = [
        {
          name = "Youtube";
          url = "https://www.youtube.com";
        }
        {
          name = "Twitch";
          url = "https://www.twitch.tv";
        }
        {
          name = "Netflix";
          url = "https://www.netflix.com";
        }
        {
          name = "Github";
          url = "https://github.com/";
        }
        {
          name = "ChatGPT";
          url = "https://chatgpt.com/";
        }
        {
          name = "Physics";
          bookmarks = [
            {
              name = "Qubits";
              url = "https://arxiv.org/pdf/1904.06560";
            }
            {
              name = "Multi-Qubits";
              url = "https://arxiv.org/pdf/2502.16479";
            }
            {
              name = "Cryogenic Modeling";
              url = "https://arxiv.org/pdf/2502.01945";
            }
            {
              name = "Nuclear Spin Engineering";
              url = "https://arxiv.org/pdf/2502.18450";
            }
            {
              name = "Mixed State Entanglement";
              url = "https://arxiv.org/pdf/2502.18446";
            }
          ];
        }
        {
          name = "NixOS";
          bookmarks = [
            {
              name = "Search NixOS";
              url = "https://mynixos.com/";
            }
            {
              name = "NixOS Wiki";
              url = "https://wiki.nixos.org/wiki/NixOS_Wiki";
            }
            {
              name = "NixOS Packages";
              url = "https://search.nixos.org/packages";
            }
            {
              name = "NixOS Options";
              url = "https://search.nixos.org/options";
            }
            {
              name = "NixOS Configs";
              url = "https://wiki.nixos.org/wiki/Configuration_Collection";
            }
            {
              name = "Nix Docs";
              url = "https://noogle.dev/";
            }
            {
              name = "Learn Nix";
              url = "https://nix.dev/";
            }
            {
              name = "NixOS & Flakes Book";
              url = "https://nixos-and-flakes.thiscute.world/";
            }
            {
              name = "Interactive Nix Lessons";
              url = "https://nixcloud.io/tour/?id=introduction/nix";
            }
            {
              name = "Nixpkgs Issue Tracker";
              url = "https://nixpkgs-tracker.ocfox.me/";
            }
          ];
        }
        {
          name = "Search Engines";
          bookmarks = [
            {
              name = "Startpage";
              url = "https://www.startpage.com/do/mypage.pl?prfe=c602752472dd4a3d8286a7ce441403da08e5c4656092384ed3091a946a5a4a4c99962d0935b509f2866ff1fdeaa3c33a007d4d26e89149869f2f7d0bdfdb1b51aa7ae7f5f17ff4a233ff313d";
            }
            {
              name = "SearX";
              url = "https://searx.aicampground.com";
            }
          ];
        }
        {
          name = "Game Dev";
          bookmarks = [
            {
              name = "Kenny Assets";
              url = "https://kenney.nl/assets";
            }
            {
              name = "Itch.io Assets";
              url = "https://itch.io/game-assets/free";
            }
            {
              name = "Craftpix Assets";
              url = "https://craftpix.net/freebies";
            }
            {
              name = "Sketchfab user Assets";
              url = "https://sketchfab.com/Emerald_Eel/collections/free-game-assets-d7263076d3b043a296321b8085a723d9";
            }
            {
              name = "Low poly 3D Assets";
              url = "https://poly.pizza";
            }
            {
              name = "Ambientcg textures";
              url = "https://ambientcg.com";
            }
          ];
        }
      ];
    }
  ];
}
```
