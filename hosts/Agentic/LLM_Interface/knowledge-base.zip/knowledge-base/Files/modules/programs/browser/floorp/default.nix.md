# modules/programs/browser/floorp/default.nix 
---
type: repository-file
source_path: "modules/programs/browser/floorp/default.nix"
source_kind: text
extension: "nix"
bytes: 2980
sha256: cae28b9e60dadbd0afe2e50b7756e37caa57929902ac1ec97bdc8560f85eb883
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Program-specific NixOS or Home Manager configuration.
- **Repository path:** `modules/programs/browser/floorp/default.nix`
- **Source kind:** text
- **Size:** 2980 bytes, 64 lines
- **SHA-256:** `cae28b9e60dadbd0afe2e50b7756e37caa57929902ac1ec97bdc8560f85eb883`

## Searchable Metadata
- **Keywords:** lockPref, false, true, builtins.readFile, import, inputs.betterfox, default, profile, lib, name, inherit, profiles, isDefault, pkgs, extensions.formautofill.addresses.enabled
- **Parent:** [[Files/modules/programs/browser/floorp|modules/programs/browser/floorp]]

### Detected Declarations / Headings
- `enable =`
- `policies =`
- `languagePacks =`
- `profiles =`
- `default =`
- `#`
- `id =`
- `name =`
- `isDefault =`
- `settings =`
- `bookmarks =`
- `search =`

### Detected References
- `import ./policies.nix { inherit lib; };`
- `import ./settings.nix { inherit lib; };`
- `import ../bookmarks.nix;`
- `import ./search.nix { inherit pkgs; };`

## Source
```
nix
{
  inputs,
  lib,
  pkgs,
  ...
}:
{
  home-manager.sharedModules = [
    (_: {
      programs.floorp = {
        enable = true;
        policies = import ./policies.nix { inherit lib; };
        languagePacks = [
          "en-GB"
          "en-US"
        ];
        profiles = {
          default = {
            # choose a profile name; directory is /home/<user>/.mozilla/firefox/profile_0
            id = 0; # 0 is the default profile; see also option "isDefault"
            name = "default"; # name as listed in about:profiles
            isDefault = true; # can be omitted; true if profile ID is 0
            settings = import ./settings.nix { inherit lib; };
            bookmarks = import ../bookmarks.nix;
            search = import ./search.nix { inherit pkgs; };
            # userChrome = builtins.readFile ./userChrome.css;
            # userContent = builtins.readFile ./userContent.css;
            extraConfig = ''
              ${builtins.readFile "${inputs.betterfox}/Fastfox.js"}
              ${builtins.readFile "${inputs.betterfox}/Peskyfox.js"}
              ${builtins.readFile "${inputs.betterfox}/Securefox.js"}
              ${builtins.readFile "${inputs.betterfox}/Smoothfox.js"}
              lockPref("extensions.activeThemeID", "{8446b178-c865-4f5c-8ccc-1d7887811ae3}");
              lockPref("extensions.formautofill.addresses.enabled", false);
              lockPref("extensions.formautofill.creditCards.enabled", false);
              lockPref("dom.security.https_only_mode_pbm", true);
              lockPref("dom.security.https_only_mode_error_page_user_suggestions", true);
              lockPref("browser.firefox-view.feature-tour", "{\"screen\":\"\",\"complete\":true}");
              lockPref("identity.fxaccounts.enabled", false);
              lockPref("browser.tabs.firefox-view-next", false);
              lockPref("privacy.sanitize.sanitizeOnShutdown", false);
              lockPref("privacy.clearOnShutdown.cache", true);
              lockPref("privacy.clearOnShutdown.cookies", false);
              lockPref("privacy.clearOnShutdown.offlineApps", false);
              lockPref("browser.sessionstore.privacy_level", 0);
              lockPref("floorp.browser.sidebar.enable", false);
              lockPref("geo.enabled", false);
              lockPref("media.navigator.enabled", false);
              lockPref("dom.event.clipboardevents.enabled", false);
              lockPref("dom.event.contextmenu.enabled", false);
              lockPref("dom.battery.enabled", false);
              lockPref("extensions.enabledScopes", 15);
              lockPref("extensions.autoDisableScopes", 0);
              lockPref("browser.newtabpage.activity-stream.floorp.newtab.imagecredit.hide", true);
              lockPref("browser.newtabpage.activity-stream.floorp.newtab.releasenote.hide", true);
              lockPref("browser.search.separatePrivateDefault", true);
            '';
          };
        };
      };
    })
  ];
}
```
