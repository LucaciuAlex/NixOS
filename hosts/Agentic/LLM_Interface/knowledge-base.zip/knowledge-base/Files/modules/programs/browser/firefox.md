# modules/programs/browser/firefox  This page represents the repository directory `modules/programs/browser/firefox` and links to its indexed files.  ## Files
- [[modules/programs/browser/firefox/default.nix.md|modules/programs/browser/firefox/default.nix]]
- [[modules/programs/browser/firefox/policies.nix.md|modules/programs/browser/firefox/policies.nix]]
- [[modules/programs/browser/firefox/search.nix.md|modules/programs/browser/firefox/search.nix]]
- [[modules/programs/browser/firefox/settings.nix.md|modules/programs/browser/firefox/settings.nix]]
