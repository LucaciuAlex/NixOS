# modules/default.nix 
---
type: repository-file
source_path: "modules/default.nix"
source_kind: text
extension: "nix"
bytes: 1605
sha256: 3481a50e1c416194b9870a5cae6ee8b9869b8e612d46ea556fc5ea141a289aa3
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Repository text file or configuration artifact.
- **Repository path:** `modules/default.nix`
- **Source kind:** text
- **Size:** 1605 bytes, 53 lines
- **SHA-256:** `3481a50e1c416194b9870a5cae6ee8b9869b8e612d46ea556fc5ea141a289aa3`

## Searchable Metadata
- **Keywords:** variables.nix, defined, Set, you, gpu, host, vars.editor, terminal, vars.fileManager, editor, vars.terminal, manager, window, browser, vars.browser
- **Parent:** [[Files/modules|modules]]

### Detected Declarations / Headings
- `vars =`
- `imports =`
- `#`
- `#`
- `#`
- `#`
- `#`
- `#`
- `#`
- `#`

### Detected References
- `import ../hosts/${host}/variables.nix;`
- `imports = [`

## Source
```
nix
{ host, lib, ... }:
let
  vars = import ../hosts/${host}/variables.nix;
in
{
  imports = [
    # Core Modules (Don't change unless you know what you're doing)
    ./scripts
    ./core/boot.nix
    ./core/bash.nix
    ./core/zsh.nix
    ./core/starship.nix
    ./core/fonts.nix
    ./core/hardware.nix
    ./core/network.nix
    ./core/nh.nix
    ./core/packages.nix
    ./core/printing.nix
    ./core/sddm.nix
    ./core/security.nix
    ./core/services.nix
    ./core/syncthing.nix
    ./core/system.nix
    ./core/users.nix
    # ./core/flatpak.nix
    # ./core/virtualisation.nix
    # ./core/dlna.nix

    # Optional
    ./hardware/drives
    ./hardware/video/${vars.videoDriver}.nix # Enable gpu drivers defined in variables.nix
    ./desktop/${vars.desktop} # Set window manager defined in variables.nix
    ./programs/browser/${vars.browser} # Set browser defined in variables.nix
    ./programs/terminal/${vars.terminal} # Set terminal defined in variables.nix
    ./programs/editor/${vars.editor} # Set editor defined in variables.nix
    ./programs/file-manager/${vars.fileManager} # Set file-manager defined in variables.nix
    ./programs/cli/tmux
    ./programs/cli/direnv
    ./programs/cli/lazygit
    ./programs/cli/cava
    ./programs/cli/btop
    ./programs/media/discord
    ./programs/media/spicetify
    # ./programs/media/youtube-music
    # ./programs/media/thunderbird
    # ./programs/media/obs-studio
    ./programs/media/mpv
    ./programs/misc/tlp
    ./programs/misc/lact # GPU fan, clock and power configuration
  ]
  ++ lib.optional (vars.games == true) ./core/games.nix;
}
```
