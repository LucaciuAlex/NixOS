# modules/desktop/hyprland/programs/wlogout/icons/restart.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/wlogout/icons/restart.png"
source_kind: binary
extension: "png"
bytes: 7810
sha256: 878cd1e15ca9644bac715420a91b721668484dec2eadee44432a550eee9bcda7
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/wlogout/icons/restart.png`
- **Source kind:** binary
- **Size:** 7810 bytes
- **SHA-256:** `878cd1e15ca9644bac715420a91b721668484dec2eadee44432a550eee9bcda7`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/programs/wlogout/icons|modules/desktop/hyprland/programs/wlogout/icons]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
