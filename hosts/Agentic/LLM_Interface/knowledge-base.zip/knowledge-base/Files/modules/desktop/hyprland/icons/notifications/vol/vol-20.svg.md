# modules/desktop/hyprland/icons/notifications/vol/vol-20.svg 
---
type: repository-file
source_path: "modules/desktop/hyprland/icons/notifications/vol/vol-20.svg"
source_kind: text
extension: "svg"
bytes: 3386
sha256: b93717d92490461c1eac7ec8d79c9245cd8a9865e39abb046df2303e4afb85f3
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/svg
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/icons/notifications/vol/vol-20.svg`
- **Source kind:** text
- **Size:** 3386 bytes, 86 lines
- **SHA-256:** `b93717d92490461c1eac7ec8d79c9245cd8a9865e39abb046df2303e4afb85f3`

## Searchable Metadata
- **Keywords:** inkscape, label, sodipodi, display, fill, true, style, stroke-width, insensitive, fill-opacity, inline, http, xmlns, SVG, path
- **Parent:** [[Files/modules/desktop/hyprland/icons/notifications/vol|modules/desktop/hyprland/icons/notifications/vol]]

### Detected Declarations / Headings
- `height=`
- `width=`
- `version=`
- `id=`
- `viewBox=`
- `xmlns=`
- `id=`
- `id=`
- `pagecolor=`
- `bordercolor=`
- `borderopacity=`
- `showgrid=`

### Detected References
- `sourceforge.net/DTD/sodipodi-0.dtd"`

## Source
```
xml
<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<!-- Uploaded to: SVG Repo, www.svgrepo.com, Generator: SVG Repo Mixer Tools -->

<svg
   height="120px"
   width="120px"
   version="1.1"
   id="Layer_1"
   viewBox="0 0 496.8 496.8"
   xml:space="preserve"
   sodipodi:docname="vol-20.svg"
   inkscape:version="1.2.2 (b0a8486541, 2022-12-01)"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:svg="http://www.w3.org/2000/svg"><defs
   id="defs23" /><sodipodi:namedview
   id="namedview21"
   pagecolor="#ffffff"
   bordercolor="#000000"
   borderopacity="0.25"
   inkscape:showpageshadow="2"
   inkscape:pageopacity="0.0"
   inkscape:pagecheckerboard="0"
   inkscape:deskcolor="#d1d1d1"
   showgrid="true"
   inkscape:zoom="22.966828"
   inkscape:cx="21.269807"
   inkscape:cy="47.30736"
   inkscape:window-width="2524"
   inkscape:window-height="1011"
   inkscape:window-x="0"
   inkscape:window-y="0"
   inkscape:window-maximized="1"
   inkscape:current-layer="Layer_1"><inkscape:grid
     type="xygrid"
     id="grid3192" /></sodipodi:namedview>






<g
   id="g3158"
   inkscape:label="base"
   sodipodi:insensitive="true"><path
     style="display:inline;fill:#121c1b;fill-opacity:1;stroke-width:1.584"
     d="m 248.87519,445.92001 c 116.5824,0 212.8896,-91.2384 220.4928,-205.2864 0,5.0688 1.2672,8.8704 1.2672,13.9392 0,121.6512 -98.8416,221.76 -221.76,221.76 -121.6512,0 -221.759991,-98.8416 -221.759991,-221.76 0,-5.0688 0,-8.8704 1.2672,-13.9392 7.6032,114.048 103.910391,205.2864 220.492791,205.2864 z"
     id="path8"
     inkscape:label="shadow"
     sodipodi:insensitive="true" /><circle
     style="display:inline;fill:#283538;fill-opacity:1;stroke-width:1.584"
     cx="248.8752"
     cy="243.07127"
     r="221.76001"
     id="circle12"
     inkscape:label="dial"
     sodipodi:insensitive="true" /><path
     style="display:inline;fill:#000000;fill-opacity:0.153846;stroke-width:1.58653"
     d="m 405.74362,86.606184 c 86.3078,86.307816 86.3078,227.192636 0,313.500456 -86.30783,86.3078 -227.19264,86.3078 -313.500453,0"
     id="path14"
     inkscape:label="highlight"
     sodipodi:insensitive="true" /></g>

<g
   id="g3198"
   inkscape:label="main"><circle
     style="display:none;fill:#000000;fill-opacity:0;stroke-width:1.584"
     cx="-51.016773"
     cy="344.18829"
     r="221.76001"
     id="circle12-3"
     inkscape:label="anchor"
     transform="rotate(-54)"
     sodipodi:insensitive="true" /><path
     style="display:inline;fill:#121c1b;fill-opacity:1;stroke-width:1.584"
     d="m 163.39662,173.46888 c 6.15112,4.46905 7.27249,11.54916 2.80344,17.70028 v 0 c -4.46905,6.15112 -11.54916,7.2725 -17.70028,2.80344 l -41.00746,-29.79365 c -6.15111,-4.46907 -7.27249,-11.54918 -2.80344,-17.70028 v 0 c 4.46904,-6.15112 11.54916,-7.2725 17.70028,-2.80345 z"
     id="path3789"
     inkscape:label="shadow" /><path
     style="display:inline;fill:#ea398a;stroke-width:1.584"
     d="m 163.47531,165.66425 c 6.15112,4.46907 7.27249,11.54918 2.80344,17.7003 v 0 c -4.46904,6.1511 -11.54915,7.27249 -17.70027,2.80345 l -41.00746,-29.79367 c -6.15112,-4.46905 -7.2725,-11.54916 -2.80345,-17.70028 v 0 c 4.46905,-6.15113 11.54916,-7.2725 17.70028,-2.80345 z"
     id="path915"
     inkscape:label="pointer" /></g>
</svg>
```
