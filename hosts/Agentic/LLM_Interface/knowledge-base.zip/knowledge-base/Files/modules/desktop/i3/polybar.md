# modules/desktop/i3/polybar  This page represents the repository directory `modules/desktop/i3/polybar` and links to its indexed files.  ## Files
- [[modules/desktop/i3/polybar/default.nix.md|modules/desktop/i3/polybar/default.nix]]
- [[modules/desktop/i3/polybar/scripts/cava.nix.md|modules/desktop/i3/polybar/scripts/cava.nix]]
- [[modules/desktop/i3/polybar/scripts/gpu_temp.nix.md|modules/desktop/i3/polybar/scripts/gpu_temp.nix]]
- [[modules/desktop/i3/polybar/scripts/workspaces.nix.md|modules/desktop/i3/polybar/scripts/workspaces.nix]]
