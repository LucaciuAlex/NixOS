# modules/desktop/hyprland/programs/hypridle  This page represents the repository directory `modules/desktop/hyprland/programs/hypridle` and links to its indexed files.  ## Files
- [[modules/desktop/hyprland/programs/hypridle/default.nix.md|modules/desktop/hyprland/programs/hypridle/default.nix]]
