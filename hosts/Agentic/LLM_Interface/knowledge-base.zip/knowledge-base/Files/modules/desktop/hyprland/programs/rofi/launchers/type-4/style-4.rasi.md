# modules/desktop/hyprland/programs/rofi/launchers/type-4/style-4.rasi 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/launchers/type-4/style-4.rasi"
source_kind: text
extension: "rasi"
bytes: 9711
sha256: 808b697380dd9c1089548873a489518ac5069e1b203401811aaf2757ef95b356
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/rasi
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/launchers/type-4/style-4.rasi`
- **Source kind:** text
- **Size:** 9711 bytes, 275 lines
- **SHA-256:** `808b697380dd9c1089548873a489518ac5069e1b203401811aaf2757ef95b356`

## Searchable Metadata
- **Keywords:** background-color, text-color, rgba, true, transparent, var, inherit, border-colour, border-radius, border, padding, element, enabled, foreground-colour, border-color
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/launchers/type-4|modules/desktop/hyprland/programs/rofi/launchers/type-4]]

### Detected References
- `import                          "shared/colors.rasi"`
- `import                          "shared/fonts.rasi"`

## Source
```
css
/**
 *
 * Author : Aditya Shakya (adi1090x)
 * Github : @adi1090x
 * 
 * Rofi Theme File
 * Rofi Version: 1.7.3
 **/

/*****----- Configuration -----*****/
configuration {
	modi:                       "drun";
    show-icons:                 true;
    display-drun:               " ";
    display-run:                "";
    display-filebrowser:        "";
    display-window:             "";
	drun-display-format:        "{name} [<span weight='light' size='small'><i>({generic})</i></span>]";
	window-format:              "{w} · {c} · {t}";
}

/*****----- Global Properties -----*****/
@import                          "shared/colors.rasi"
@import                          "shared/fonts.rasi"

* {
    border-colour:               rgba(122, 162, 247, 80%);
    handle-colour:               rgba(122, 162, 247, 80%);
    background-colour:           rgba(30, 29, 47, 80%);
    foreground-colour:           #D9E0EEFF;
    alternate-background:        rgba(40, 40, 57, 80%);
    normal-background:           rgba(30, 29, 47, 80%);
    normal-foreground:           #D9E0EEFF;
    urgent-background:           rgba(242, 143, 173, 80%);
    urgent-foreground:           rgba(30, 29, 47, 80%);
    active-background:           rgba(171, 233, 179, 80%);
    active-foreground:           rgba(30, 29, 47, 80%);
    selected-normal-background:  rgba(122, 162, 247, 80%);
    selected-normal-foreground:  rgba(30, 29, 47, 80%);
    selected-urgent-background:  rgba(171, 233, 179, 80%);
    selected-urgent-foreground:  rgba(30, 29, 47, 80%);
    selected-active-background:  rgba(242, 143, 173, 80%);
    selected-active-foreground:  rgba(30, 29, 47, 80%);
    alternate-normal-background: rgba(30, 29, 47, 80%);
    alternate-normal-foreground: #D9E0EEFF;
    alternate-urgent-background: rgba(242, 143, 173, 80%);
    alternate-urgent-foreground: rgba(30, 29, 47, 80%);
    alternate-active-background: rgba(171, 233, 179, 80%);
    alternate-active-foreground: rgba(30, 29, 47, 80%);
}

/*****----- Main Window -----*****/
window {
    /* properties for window widget */
    transparency:                "real";
    location:                    center;
    anchor:                      center;
    fullscreen:                  false;
    width:                       800px;
    x-offset:                    0px;
    y-offset:                    0px;

    /* properties for all widgets */
    enabled:                     true;
    margin:                      0px;
    padding:                     0px;
    border:                      0px solid;
    border-radius:               15px;
    border-color:                @border-colour;
    cursor:                      "default";
    background-color:            @background-colour;
}

/*****----- Main Box -----*****/
mainbox {
    enabled:                     true;
    spacing:                     10px;
    margin:                      0px;
    padding:                     30px;
    border:                      0px solid;
    border-radius:               0px 0px 0px 0px;
    border-color:                @border-colour;
    background-color:            transparent;
    children:                    [ "inputbar", "listview" ];
}

/*****----- Inputbar -----*****/
inputbar {
    enabled:                     true;
    spacing:                     10px;
    margin:                      0px;
    padding:                     0px 0px 10px 10px;
    border:                      0px;
    border-radius:               0px;
    border-color:                @border-colour;
    background-color:            transparent;
    text-color:                  @foreground-colour;
    children:                    [ "textbox-prompt-colon", "entry" ];
}

prompt {
    enabled:                     true;
    background-color:            inherit;
    text-color:                  inherit;
}
textbox-prompt-colon {
    enabled:                     true;
    expand:                      false;
    str:                         " ";
    background-color:            inherit;
    text-color:                  inherit;
}
entry {
    enabled:                     true;
    background-color:            transparent;
    text-color:                  inherit;
    cursor:                      text;
    placeholder:                 "Search Emojis...";
    placeholder-color:           inherit;
}

/*****----- Listview -----*****/
listview {
    enabled:                     true;
    columns:                     1;
    lines:                       12;
    cycle:                       true;
    dynamic:                     true;
    scrollbar:                   false;
    layout:                      vertical;
    reverse:                     false;
    fixed-height:                true;
    fixed-columns:               true;
    
    spacing:                     0px;
    margin:                      0px;
    padding:                     0px;
    border:                      0px solid;
    border-radius:               0px;
    border-color:                @border-colour;
    background-color:            transparent;
    text-color:                  @foreground-colour;
    cursor:                      "default";
}
scrollbar {
    handle-width:                5px ;
    handle-color:                @handle-colour;
    border-radius:               0px;
    background-color:            @alternate-background;
}

/*****----- Elements -----*****/
element {
    enabled:                     true;
    spacing:                     10px;
    margin:                      0px;
    padding:                     5px;
    border:                      0px solid;
    border-radius:               12px;
    border-color:                @border-colour;
    background-color:            transparent;
    text-color:                  @foreground-colour;
    cursor:                      pointer;
}
element normal.normal {
    background-color:            transparent;
    text-color:                  var(normal-foreground);
}
element normal.urgent {
    background-color:            transparent;
    text-color:                  var(urgent-foreground);
}
element normal.active {
    background-color:            transparent;
    text-color:                  var(active-foreground);
}
element selected.normal {
    background-color:            var(alternate-background);
    text-color:                  var(foreground-colour);
}
element selected.urgent {
    background-color:            var(selected-urgent-background);
    text-color:                  var(selected-urgent-foreground);
}
element selected.active {
    background-color:            var(selected-active-background);
    text-color:                  var(selected-active-foreground);
}
element alternate.normal {
    background-color:            transparent;
    text-color:                  var(alternate-normal-foreground);
}
element alternate.urgent {
    background-color:            transparent;
    text-color:                  var(alternate-urgent-foreground);
}
element alternate.active {
    background-color:            transparent;
    text-color:                  var(alternate-active-foreground);
}
element-icon {
    background-color:            transparent;
    text-color:                  inherit;
    size:                        24px;
    cursor:                      inherit;
}
element-text {
    background-color:            transparent;
    text-color:                  inherit;
    highlight:                   inherit;
    cursor:                      inherit;
    vertical-align:              0.5;
    horizontal-align:            0.0;
}

/*****----- Mode Switcher -----*****/
mode-switcher{
    enabled:                     true;
    spacing:                     10px;
    margin:                      0px;
    padding:                     0px;
    border:                      0px solid;
    border-radius:               0px;
    border-color:                @border-colour;
    background-color:            transparent;
    text-color:                  @foreground-colour;
}
button {
    padding:                     10px;
    border:                      0px solid;
    border-radius:               0px;
    border-color:                @border-colour;
    background-color:            @alternate-background;
    text-color:                  inherit;
    cursor:                      pointer;
}
button selected {
    background-color:            var(selected-normal-background);
    text-color:                  var(selected-normal-foreground);
}

/*****----- Message -----*****/
message {
    enabled:                     true;
    margin:                      0px;
    padding:                     0px;
    border:                      0px solid;
    border-radius:               0px 0px 0px 0px;
    border-color:                @border-colour;
    background-color:            transparent;
    text-color:                  @foreground-colour;
}
textbox {
    padding:                     10px;
    border:                      0px solid;
    border-radius:               0px;
    border-color:                @border-colour;
    background-color:            @alternate-background;
    text-color:                  @foreground-colour;
    vertical-align:              0.5;
    horizontal-align:            0.0;
    highlight:                   none;
    placeholder-color:           @foreground-colour;
    blink:                       true;
    markup:                      true;
}
error-message {
    padding:                     10px;
    border:                      0px solid;
    border-radius:               0px;
    border-color:                @border-colour;
    background-color:            @background-colour;
    text-color:                  @foreground-colour;
}
```
