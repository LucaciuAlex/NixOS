# modules/desktop/hyprland/programs/rofi/launchers/type-2/shared/fonts.rasi 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/launchers/type-2/shared/fonts.rasi"
source_kind: text
extension: "rasi"
bytes: 135
sha256: c018a466dcf352f3a7a92371ee395811039ac811f327a39ef2fd0fe874903bf5
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/rasi
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/launchers/type-2/shared/fonts.rasi`
- **Source kind:** text
- **Size:** 135 bytes, 13 lines
- **SHA-256:** `c018a466dcf352f3a7a92371ee395811039ac811f327a39ef2fd0fe874903bf5`

## Searchable Metadata
- **Keywords:** adi1090x, font, Nerd, Mono, JetBrains, Fonts, Aditya, Author, Github, Shakya
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/launchers/type-2/shared|modules/desktop/hyprland/programs/rofi/launchers/type-2/shared]]

## Source
```
css
/**
 *
 * Author : Aditya Shakya (adi1090x)
 * Github : @adi1090x
 * 
 * Fonts
 *
 **/

* {
    font: "JetBrains Mono Nerd Font 10";
}
```
