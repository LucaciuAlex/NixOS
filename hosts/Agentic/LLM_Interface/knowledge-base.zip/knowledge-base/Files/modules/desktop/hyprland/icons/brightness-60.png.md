# modules/desktop/hyprland/icons/brightness-60.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/icons/brightness-60.png"
source_kind: binary
extension: "png"
bytes: 28411
sha256: a4c520e94d6ccbd8ad592b2b0d485c00150f0b4278fcbbdbf892c947665ff647
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/icons/brightness-60.png`
- **Source kind:** binary
- **Size:** 28411 bytes
- **SHA-256:** `a4c520e94d6ccbd8ad592b2b0d485c00150f0b4278fcbbdbf892c947665ff647`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/icons|modules/desktop/hyprland/icons]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
