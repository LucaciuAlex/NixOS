# modules/desktop/hyprland/scripts/screen-record.nix 
---
type: repository-file
source_path: "modules/desktop/hyprland/scripts/screen-record.nix"
source_kind: text
extension: "nix"
bytes: 929
sha256: 4b190d25e2d4cf1d5fb068a6430eb53b7ed23fe983da3a07ad99522985a03c16
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/scripts/screen-record.nix`
- **Source kind:** text
- **Size:** 929 bytes, 35 lines
- **SHA-256:** `4b190d25e2d4cf1d5fb068a6430eb53b7ed23fe983da3a07ad99522985a03c16`

## Searchable Metadata
- **Keywords:** XDG_VIDEOS_DIR, timestamp, REGION, exit, Select, Recording, pkgs.libnotify, low, EOF, pkgs.slurp, DIR, wf-recorder, pkgs.procps, print_error, Started
- **Parent:** [[Files/modules/desktop/hyprland/scripts|modules/desktop/hyprland/scripts]]

### Detected Declarations / Headings
- `XDG_VIDEOS_DIR=`
- `DIR=`
- `timestamp=`

## Source
```
nix
{ pkgs, ... }:
pkgs.writeShellScriptBin "screen-record" ''
  XDG_VIDEOS_DIR="''${XDG_VIDEOS_DIR:-$HOME/Videos}"
  DIR="''${XDG_VIDEOS_DIR}/screen-record"

  mkdir -p "$DIR"

  print_error() {
    cat <<EOF
  Usage: $(basename "$0") <action>
  Valid actions:
    a  : Select area
    m  : Select monitor
  EOF
    exit 1
  }

  timestamp=$(date +"%Y%m%d_%Hh%Mm%Ss")

  if ${pkgs.procps}/bin/pidof wf-recorder > /dev/null; then
    ${pkgs.procps}/bin/pkill wf-recorder
    ${pkgs.libnotify}/bin/notify-send -e -t 2500 -u low "Recording Finished" \
      "Saved to $DIR/recording_''${timestamp}.mp4"
    exit 0
  fi

  case "$1" in
    a) REGION=$(${pkgs.slurp}/bin/slurp) ;;
    m) REGION=$(${pkgs.slurp}/bin/slurp -o) ;;
    *) print_error ;;
  esac

  ${pkgs.wf-recorder}/bin/wf-recorder --audio -g "$REGION && $(${pkgs.libnotify}/bin/notify-send -e -t 2500 -u low "Recording Started")" -f "$DIR/recording_''${timestamp}.mp4"
''
```
