# modules/desktop/hyprland/programs/rofi/colors/paper.rasi 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/colors/paper.rasi"
source_kind: text
extension: "rasi"
bytes: 278
sha256: ee5594773706c18ef06dd7079079dcabc185943c27e3549ffbaca271bb75fd89
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/rasi
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/colors/paper.rasi`
- **Source kind:** text
- **Size:** 278 bytes, 17 lines
- **SHA-256:** `ee5594773706c18ef06dd7079079dcabc185943c27e3549ffbaca271bb75fd89`

## Searchable Metadata
- **Keywords:** adi1090x, foreground, E0E0E0FF, background-alt, selected, urgent, active, C30771FF, Shakya, Aditya, Author, Github, F1F1F1FF, background, Colors
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/colors|modules/desktop/hyprland/programs/rofi/colors]]

## Source
```
css
/**
 *
 * Author : Aditya Shakya (adi1090x)
 * Github : @adi1090x
 * 
 * Colors
 **/

* {
    background:     #F1F1F1FF;
    background-alt: #E0E0E0FF;
    foreground:     #252525FF;
    selected:       #008EC4FF;
    active:         #10A778FF;
    urgent:         #C30771FF;
}
```
