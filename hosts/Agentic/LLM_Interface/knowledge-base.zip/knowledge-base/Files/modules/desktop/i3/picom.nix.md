# modules/desktop/i3/picom.nix 
---
type: repository-file
source_path: "modules/desktop/i3/picom.nix"
source_kind: text
extension: "nix"
bytes: 1743
sha256: 95dd5d11488155b9658540b7a72dd1e53a743df3d2d0d5e7f78d3d983eec97d7
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/i3/picom.nix`
- **Source kind:** text
- **Size:** 1743 bytes, 71 lines
- **SHA-256:** `95dd5d11488155b9658540b7a72dd1e53a743df3d2d0d5e7f78d3d983eec97d7`

## Searchable Metadata
- **Keywords:** class_g, true, false, Blur, focused, let, name, strength, opacity., window, adjust, based, zen, Fading, not
- **Parent:** [[Files/modules/desktop/i3|modules/desktop/i3]]

### Detected Declarations / Headings
- `enable =`
- `settings =`
- `backend =`
- `glx-no-stencil =`
- `use-damage =`
- `xrender-sync-fence =`
- `vsync =`
- `refresh-rate =`
- `detect-client-opacity =`
- `inactive-opacity =`
- `active-opacity =`
- `frame-opacity =`

### Detected References
- `urlong.wezterm' && focused"`

## Source
```
nix
{
  services.picom = {
    enable = true;
    settings = {
      backend = "glx";
      glx-no-stencil = true;
      use-damage = true;
      xrender-sync-fence = true;
      vsync = true;
      refresh-rate = 0;
      detect-client-opacity = true;

      inactive-opacity = 0.7;
      active-opacity = 0.95;
      frame-opacity = 0.9;
      inactive-opacity-override = false;

      # Blur
      blur-background = true;
      blur = {
        method = "dual_kawase";
        strength = 3;
        size = 3; # Required for gaussian and box blur

        # strength = 6;
        # deviation = 1.0;
        # kernel = "11x11gaussian";
        # background = true;
        # background-frame = false;
        # background-fixed = false;
      };

      # blur-background-exclude = [
      #   "window_type = 'dock'"
      # ];

      # corner-radius = 5;
      # round-borders = 1;

      # Fading
      fading = false;
      fade-delta = 3;
      no-fading-openclose = false;

      # Dim inactive windows. (0.0 - 1.0)
      inactive-dim = 0.03;

      # Do not let dimness adjust based on window opacity.
      inactive-dim-fixed = true;

      # Do not let blur radius adjust based on window opacity.
      blur-background-fixed = true;

      # Can use name or class_g here
      opacity-rule = [
        "100:class_g = 'Rofi'"
        "100:class_g = 'zen'"
        "100:class_g = 'zen-beta'"
        "100:class_g = 'firefox'"
        "100:class_g = 'floorp'"
        "100:class_g = 'zen'"
        "100:class_g = 'Brave-browser'"
        "90:class_g = 'kitty' && focused"
        "90:class_g = 'Alacritty' && focused"
        "90:class_g = 'org.wezfurlong.wezterm' && focused"
        "80:name = 'Spotify' && !focused"
      ];
    };
  };
}
```
