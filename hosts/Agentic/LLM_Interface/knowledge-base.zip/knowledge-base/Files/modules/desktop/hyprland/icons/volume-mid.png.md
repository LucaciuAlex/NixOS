# modules/desktop/hyprland/icons/volume-mid.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/icons/volume-mid.png"
source_kind: binary
extension: "png"
bytes: 24989
sha256: bf78ff9a7cf75e9c80ec36d61ec4ef00bc5a7044b125699cc3576804eeadd56e
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/icons/volume-mid.png`
- **Source kind:** binary
- **Size:** 24989 bytes
- **SHA-256:** `bf78ff9a7cf75e9c80ec36d61ec4ef00bc5a7044b125699cc3576804eeadd56e`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/icons|modules/desktop/hyprland/icons]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
