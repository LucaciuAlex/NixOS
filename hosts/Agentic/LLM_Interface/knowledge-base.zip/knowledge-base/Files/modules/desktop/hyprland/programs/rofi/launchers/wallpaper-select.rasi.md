# modules/desktop/hyprland/programs/rofi/launchers/wallpaper-select.rasi 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/launchers/wallpaper-select.rasi"
source_kind: text
extension: "rasi"
bytes: 6245
sha256: a55789e1b166d4c538a11d628b7d04151f1995f15f31a09c0da67b563945f99a
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/rasi
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/launchers/wallpaper-select.rasi`
- **Source kind:** text
- **Size:** 6245 bytes, 175 lines
- **SHA-256:** `a55789e1b166d4c538a11d628b7d04151f1995f15f31a09c0da67b563945f99a`

## Searchable Metadata
- **Keywords:** rgba, background-color, true, inherit, text-color, enabled, transparent, cursor, border-colour, false, padding, border-radius, foreground-colour, border-color, spacing
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/launchers|modules/desktop/hyprland/programs/rofi/launchers]]

### Detected References
- `import "~/.config/rofi/colors/catppuccin.rasi"`

## Source
```
css
/*****----- Global Properties -----*****/
@import "~/.config/rofi/colors/catppuccin.rasi"

/*****----- Configuration -----*****/
configuration {
    modi:                       "drun";
    display-drun:               " ";
    drun-display-format:        "{name}";
    show-icons:                 true;
}

* {
    font: "JetBrains Mono Nerd Font 10";
    border-colour:               rgba(122, 162, 247, 80%);
    handle-colour:               rgba(122, 162, 247, 80%);
    background-colour:           rgba(30, 29, 47, 80%);
    foreground-colour:           #D9E0EEFF;
    alternate-background:        rgba(40, 40, 57, 80%);
    normal-background:           rgba(30, 29, 47, 80%);
    normal-foreground:           #D9E0EEFF;
    urgent-background:           rgba(242, 143, 173, 80%);
    urgent-foreground:           rgba(30, 29, 47, 80%);
    active-background:           rgba(171, 233, 179, 80%);
    active-foreground:           rgba(30, 29, 47, 80%);
    selected-normal-background:  rgba(122, 162, 247, 80%);
    selected-normal-foreground:  rgba(30, 29, 47, 80%);
    selected-urgent-background:  rgba(171, 233, 179, 80%);
    selected-urgent-foreground:  rgba(30, 29, 47, 80%);
    selected-active-background:  rgba(242, 143, 173, 80%);
    selected-active-foreground:  rgba(30, 29, 47, 80%);
    alternate-normal-background: rgba(30, 29, 47, 80%);
    alternate-normal-foreground: #D9E0EEFF;
    alternate-urgent-background: rgba(242, 143, 173, 80%);
    alternate-urgent-foreground: rgba(30, 29, 47, 80%);
    alternate-active-background: rgba(171, 233, 179, 80%);
    alternate-active-foreground: rgba(30, 29, 47, 80%);
}

/*****----- Main Window -----*****/
window {
    transparency:                "real";
    location:                    center;
    anchor:                      center;
    fullscreen:                  false;
    width:                       60%;
    // width:                       1080px;
    // height:                      270px;
    x-offset:                    0px;
    y-offset:                    0px;

    enabled:                     true;
    margin:                      0px;
    padding:                     0px;
    border:                      0px solid;
    border-radius:               12px;
    border-color:                @border-colour;
    background-color:            @background-colour;
    cursor:                      "default";
}

/*****----- Main Box -----*****/
mainbox {
    enabled:                     true;
    spacing:                     10px;
    margin:                      0px;
    padding:                     15px;
    border:                      0px solid;
    border-radius:               0px 0px 0px 0px;
    border-color:                @border-colour;
    background-color:            transparent;
    children:                    [ "inputbar", "listview" ];
}

/*****----- Inputbar -----*****/
inputbar {
    enabled:                     true;
    padding:                     10px 0px;
    background-color:            transparent;
    text-color:                  @foreground;
    children:                    [ "textbox-prompt-colon", "entry" ];
}

prompt {
    enabled:                     true;
    background-color:            inherit;
    text-color:                  inherit;
}
textbox-prompt-colon {
    enabled:                     true;
    expand:                      false;
    str:                         " ";
    background-color:            inherit;
    text-color:                  inherit;
}
entry {
    enabled:                     true;
    background-color:            transparent;
    text-color:                  inherit;
    cursor:                      text;
    placeholder:                 "Search Wallpapers...";
    placeholder-color:           inherit;
}

/*****----- Listview -----*****/
listview {
    enabled:                     true;
    columns:                     6;
    lines:                       1;
    cycle:                       true;
    dynamic:                     true;
    scrollbar:                   false;
    layout:                      vertical;
    reverse:                     false;
    fixed-height:                true;
    fixed-columns:               true;
    
    // Or set spacing to 10
    spacing:                     0px;
    margin:                      0px;
    padding:                     0px;
    border:                      0px solid;
    border-radius:               0px;
    border-color:                @border-colour;
    background-color:            transparent;
    text-color:                  @foreground-colour;
    cursor:                      "default";
}
scrollbar {
    handle-width:                5px ;
    handle-color:                @handle-colour;
    border-radius:               0px;
    background-color:            @alternate-background;
}

/*****----- Elements -----*****/
element {
    enabled:                     true;
    spacing:                     0px;
    margin:                      0px;
    padding:                     -20px 0px -20px 0px;
    border:                      0px solid;
    border-radius:               12px;
    border-color:                @border-colour;
    background-color:            transparent;
    text-color:                  @foreground-colour;
    cursor:                      pointer;
    orientation:                 vertical;
}

element normal.normal {
    background-color:            transparent;
    text-color:                  var(normal-foreground);
}
element selected.normal {
    background-color:            rgba(122, 162, 247, 80%);
    text-color:                  rgba(30, 29, 47, 80%);
    // background-color:            var(alternate-background);
    // text-color:                  var(foreground-colour);
}
element-icon {
    background-color:            transparent;
    text-color:                  inherit;
    size:                        160px;
    cursor:                      inherit;
}
element-text {
    enabled:                     false;
    background-color:            transparent;
    text-color:                  inherit;
    highlight:                   inherit;
    cursor:                      inherit;
    vertical-align:              0.0;
    horizontal-align:            0.5;
}
```
