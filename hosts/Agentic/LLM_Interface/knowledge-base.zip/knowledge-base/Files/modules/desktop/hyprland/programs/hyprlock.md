# modules/desktop/hyprland/programs/hyprlock  This page represents the repository directory `modules/desktop/hyprland/programs/hyprlock` and links to its indexed files.  ## Files
- [[modules/desktop/hyprland/programs/hyprlock/default.nix.md|modules/desktop/hyprland/programs/hyprlock/default.nix]]
