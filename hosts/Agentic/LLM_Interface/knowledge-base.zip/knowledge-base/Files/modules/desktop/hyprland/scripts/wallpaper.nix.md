# modules/desktop/hyprland/scripts/wallpaper.nix 
---
type: repository-file
source_path: "modules/desktop/hyprland/scripts/wallpaper.nix"
source_kind: text
extension: "nix"
bytes: 546
sha256: 43c74a3525cbbe356dddb439e1f3f6171728cab794f070ff75915c320d05e921
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/scripts/wallpaper.nix`
- **Source kind:** text
- **Size:** 546 bytes, 21 lines
- **SHA-256:** `43c74a3525cbbe356dddb439e1f3f6171728cab794f070ff75915c320d05e921`

## Searchable Metadata
- **Keywords:** awww, awww-daemon, then, Restore, wallpaper, defaultWallpaper, pkgs.awww, the, query, default, img, none, grep, image, pkgs.writeShellScriptBin
- **Parent:** [[Files/modules/desktop/hyprland/scripts|modules/desktop/hyprland/scripts]]

### Detected Declarations / Headings
- `awww =`
- `awww-daemon =`
- `#`
- `#`

## Source
```
nix
{ pkgs, defaultWallpaper, ... }:
let
  awww = "${pkgs.awww}/bin/awww";
  awww-daemon = "${pkgs.awww}/bin/awww-daemon";
in
pkgs.writeShellScriptBin "wallpaper" ''

if ! pgrep awww-daemon &> /dev/null; then
  ${awww-daemon} &
  sleep 0.5
fi

# Restore
${awww} restore &> /dev/null

# If there is no wallpaper then set the default
if ! ${awww} query | grep -q "image:" &> /dev/null; then
  ${awww} img "${../../../themes/wallpapers/${defaultWallpaper}}" --transition-step 255 --transition-duration 1 --transition-fps 60 --transition-type none
fi
''
```
