# modules/desktop/hyprland/scripts/file-manager.nix 
---
type: repository-file
source_path: "modules/desktop/hyprland/scripts/file-manager.nix"
source_kind: text
extension: "nix"
bytes: 553
sha256: 4e469e9810809817cd9808084a897843cfd5c3a4b38aba4390372a07ac1d44ee
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/scripts/file-manager.nix`
- **Source kind:** text
- **Size:** 553 bytes, 21 lines
- **SHA-256:** `4e469e9810809817cd9808084a897843cfd5c3a4b38aba4390372a07ac1d44ee`

## Searchable Metadata
- **Keywords:** exec, terminal, fileManager, yazi, pcmanfm, nemo, nautilus, nnn, ranger, thunar, dolphin, esac, file-manager, pkgs.writeShellScriptBin, term
- **Parent:** [[Files/modules/desktop/hyprland/scripts|modules/desktop/hyprland/scripts]]

### Detected Declarations / Headings
- `term=`

## Source
```
nix
{
  pkgs,
  terminal,
  ...
}:
pkgs.writeShellScriptBin "file-manager" ''
  term="${terminal}"
  case "$1" in
    thunar) exec thunar ;;
    dolphin) exec dolphin ;;
    nautilus) exec nautilus ;;
    pcmanfm) exec pcmanfm ;;
    nemo) exec nemo ;;
    yazi) exec ${terminal} --class "fileManager" -e yazi ;;
    lf) exec ${terminal} --class "fileManager" -e lf ;;
    nnn) exec ${terminal} --class "fileManager" -e nnn ;;
    ranger) exec ${terminal} --class "fileManager" -e ranger ;;
    mc) exec ${terminal} --class "fileManager" -e mc ;;
  esac
''
```
