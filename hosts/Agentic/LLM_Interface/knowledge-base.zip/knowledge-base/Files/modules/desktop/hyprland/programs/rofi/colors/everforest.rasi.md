# modules/desktop/hyprland/programs/rofi/colors/everforest.rasi 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/colors/everforest.rasi"
source_kind: text
extension: "rasi"
bytes: 278
sha256: eb142b609b71f73e736f8d92252d8074fa2f41be6cf0de08e3b2c6bd7e180e8a
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/rasi
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/colors/everforest.rasi`
- **Source kind:** text
- **Size:** 278 bytes, 17 lines
- **SHA-256:** `eb142b609b71f73e736f8d92252d8074fa2f41be6cf0de08e3b2c6bd7e180e8a`

## Searchable Metadata
- **Keywords:** adi1090x, selected, DAD1BEFF, foreground, active, urgent, A7C080FF, E67E80FF, Shakya, Aditya, Author, Github, background-alt, background, Colors
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/colors|modules/desktop/hyprland/programs/rofi/colors]]

## Source
```
css
/**
 *
 * Author : Aditya Shakya (adi1090x)
 * Github : @adi1090x
 * 
 * Colors
 **/

* {
    background:     #323D43FF;
    background-alt: #3C474DFF;
    foreground:     #DAD1BEFF;
    selected:       #7FBBB3FF;
    active:         #A7C080FF;
    urgent:         #E67E80FF;
}
```
