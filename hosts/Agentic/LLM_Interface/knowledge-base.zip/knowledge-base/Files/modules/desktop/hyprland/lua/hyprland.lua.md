# modules/desktop/hyprland/lua/hyprland.lua 
---
type: repository-file
source_path: "modules/desktop/hyprland/lua/hyprland.lua"
source_kind: text
extension: "lua"
bytes: 117
sha256: a32edd8bca7b969ff1e4cc9c424413eac73d36c5c60c8a98e008d4fd11048e11
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/lua
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/lua/hyprland.lua`
- **Source kind:** text
- **Size:** 117 bytes, 7 lines
- **SHA-256:** `a32edd8bca7b969ff1e4cc9c424413eac73d36c5c60c8a98e008d4fd11048e11`

## Searchable Metadata
- **Keywords:** require, animations, binds, rules, monitors, variables, settings
- **Parent:** [[Files/modules/desktop/hyprland/lua|modules/desktop/hyprland/lua]]

## Source
```
lua
require("monitors")
require("variables")
require("settings")
require("animations")
require("binds")
require("rules")
```
