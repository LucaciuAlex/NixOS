# modules/desktop/i3/polybar/scripts/cava.nix 
---
type: repository-file
source_path: "modules/desktop/i3/polybar/scripts/cava.nix"
source_kind: text
extension: "nix"
bytes: 593
sha256: e3f3eb95bd1defc9f0bf15dbb42c90829531b20367a86ca1e6eaadf9f138ee67
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/i3/polybar/scripts/cava.nix`
- **Source kind:** text
- **Size:** 593 bytes, 33 lines
- **SHA-256:** `e3f3eb95bd1defc9f0bf15dbb42c90829531b20367a86ca1e6eaadf9f138ee67`

## Searchable Metadata
- **Keywords:** cava, dict, bar, config_file, while, read, echo, done, line, raw_target, sed, method, raw, data_format, ascii_max_range
- **Parent:** [[Files/modules/desktop/i3/polybar/scripts|modules/desktop/i3/polybar/scripts]]

### Detected Declarations / Headings
- `bar=`
- `dict=`
- `#`
- `i=`
- `dict=`
- `i=`
- `#`
- `config_file=`
- `bars =`
- `method =`
- `raw_target =`
- `data_format =`

## Source
```
nix
{ pkgs, ... }:
pkgs.writeShellScriptBin "cava" ''

  bar="▁▂▃▄▅▆▇█"
  dict="s/;//g;"

  # creating "dictionary" to replace char with bar
  i=0
  while [ $i -lt ''${#bar} ]
  do
      dict="''${dict}s/$i/''${"bar:$i:1"}/g;"
      i=$((i=i+1))
  done

  # write cava config
  config_file="/tmp/polybar_cava_config"
  echo "
  [general]
  bars = 10

  [output]
  method = raw
  raw_target = /dev/stdout
  data_format = ascii
  ascii_max_range = 7
  " > $config_file

  # read stdout from cava
  cava -p $config_file | while read -r line; do
      echo $line | sed $dict
  done
''
```
