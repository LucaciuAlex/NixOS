# modules/desktop/hyprland/programs/rofi/assets/style_4.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/assets/style_4.png"
source_kind: binary
extension: "png"
bytes: 24896
sha256: a2e8b6d24963b774bc54d03b2ceb7cc0df7a548698b95a5a1c625605ae6f5151
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/assets/style_4.png`
- **Source kind:** binary
- **Size:** 24896 bytes
- **SHA-256:** `a2e8b6d24963b774bc54d03b2ceb7cc0df7a548698b95a5a1c625605ae6f5151`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/assets|modules/desktop/hyprland/programs/rofi/assets]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
