# modules/desktop/hyprland/programs/waybar  This page represents the repository directory `modules/desktop/hyprland/programs/waybar` and links to its indexed files.  ## Files
- [[modules/desktop/hyprland/programs/waybar/default.nix.md|modules/desktop/hyprland/programs/waybar/default.nix]]
- [[modules/desktop/hyprland/programs/waybar/minimal.nix.md|modules/desktop/hyprland/programs/waybar/minimal.nix]]
- [[modules/desktop/hyprland/programs/waybar/stylish.nix.md|modules/desktop/hyprland/programs/waybar/stylish.nix]]
