# modules/desktop/hyprland/programs/rofi/colors/nord.rasi 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/colors/nord.rasi"
source_kind: text
extension: "rasi"
bytes: 278
sha256: 4af40afe91ee3d2a5b2b50f46499ef064115d62f3a3ba05b85176525eeaf8656
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/rasi
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/colors/nord.rasi`
- **Source kind:** text
- **Size:** 278 bytes, 17 lines
- **SHA-256:** `4af40afe91ee3d2a5b2b50f46499ef064115d62f3a3ba05b85176525eeaf8656`

## Searchable Metadata
- **Keywords:** adi1090x, selected, E5E9F0FF, foreground, active, urgent, A3BE8CFF, BF616AFF, Shakya, Aditya, Author, Github, background-alt, background, Colors
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/colors|modules/desktop/hyprland/programs/rofi/colors]]

## Source
```
css
/**
 *
 * Author : Aditya Shakya (adi1090x)
 * Github : @adi1090x
 * 
 * Colors
 **/

* {
    background:     #2E3440FF;
    background-alt: #383E4AFF;
    foreground:     #E5E9F0FF;
    selected:       #81A1C1FF;
    active:         #A3BE8CFF;
    urgent:         #BF616AFF;
}
```
