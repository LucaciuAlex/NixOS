# modules/desktop/hyprland/scripts/volumecontrol.nix 
---
type: repository-file
source_path: "modules/desktop/hyprland/scripts/volumecontrol.nix"
source_kind: text
extension: "nix"
bytes: 2065
sha256: 3f0da19640de8ab655c00b7b644da5573cf00564a165a60efefaf3d932ea5a10
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/scripts/volumecontrol.nix`
- **Source kind:** text
- **Size:** 2065 bytes, 64 lines
- **SHA-256:** `3f0da19640de8ab655c00b7b644da5573cf00564a165a60efefaf3d932ea5a10`

## Searchable Metadata
- **Keywords:** srce, pkgs.pamixer, nsink, device, vol, dvce, icodir, notify_vol, System, pkgs.libnotify, step, pkgs.gnused, cat, print_error, notify_mute
- **Parent:** [[Files/modules/desktop/hyprland/scripts|modules/desktop/hyprland/scripts]]

### Detected Declarations / Headings
- `icodir=`
- `vol=`
- `angle=`
- `ico=`
- `bar=`
- `mute=`
- `srce=`
- `dvce=`
- `srce=`
- `dvce=`
- `step=`

### Detected References
- `sources | ${pkgs.gnugrep}/bin/grep "_input." | ${pkgs.coreutils}/bin/head -1 | ${pkgs.gawk}/bin/awk -F '" "' '{print $NF}' | ${pkgs.gnused}/bin/sed 's/"//')`
- `source"`

## Source
```
nix
{ pkgs, ... }:
pkgs.writeShellScriptBin "volumecontrol" ''
  icodir="$HOME/.config/hypr/icons/notifications/vol"

  print_error() {
    cat << "EOF"
    volumecontrol -[device] <action>
    ...valid device are...
        i -- [i]nput device
        o -- [o]utput device
    ...valid actions are...
        i -- <i>ncrease volume [+5]
        d -- <d>ecrease volume [-5]
        m -- <m>ute [x]
EOF
  }

  notify_vol() {
    vol=$(${pkgs.pamixer}/bin/pamixer $srce --get-volume | cat)
    angle=$((((vol + 2) / 5) * 5))
    ico="''${icodir}/vol-''${angle}.svg"
    bar=$(${pkgs.coreutils}/bin/seq -s "." $((vol / 15)) | ${pkgs.gnused}/bin/sed 's/[0-9]//g')
    ${pkgs.libnotify}/bin/notify-send -a "System" -r 91190 -t 800 -i "''${ico}" "''${vol}''${bar}" "$nsink"
  }

  notify_mute() {
    mute=$(${pkgs.pamixer}/bin/pamixer $srce --get-mute | cat)
    if [ "$mute" == "true" ] ; then
      ${pkgs.libnotify}/bin/notify-send -a "System" -r 61190 -t 800 -i "''${icodir}/muted-''${dvce}.svg" "Muted" "$nsink"
    else
      ${pkgs.libnotify}/bin/notify-send -a "System" -r 61190 -t 800 -i "''${icodir}/unmuted-''${dvce}.svg" "Unmuted" "$nsink"
    fi
  }

  while getopts io SetSrc
  do
    case $SetSrc in
    i) nsink=$(${pkgs.pamixer}/bin/pamixer --list-sources | ${pkgs.gnugrep}/bin/grep "_input." | ${pkgs.coreutils}/bin/head -1 | ${pkgs.gawk}/bin/awk -F '" "' '{print $NF}' | ${pkgs.gnused}/bin/sed 's/"//')
        srce="--default-source"
        dvce="mic" ;;
    o) nsink=$(${pkgs.pamixer}/bin/pamixer --get-default-sink | ${pkgs.gnugrep}/bin/grep "_output." | ${pkgs.gawk}/bin/awk -F '" "' '{print $NF}' | ${pkgs.gnused}/bin/sed 's/"//')
        srce=""
        dvce="speaker" ;;
    esac
  done

  if [ $OPTIND -eq 1 ] ; then
    print_error
  fi

  shift $((OPTIND -1))
  step="''${2:-1}"

  case $1 in
    i) ${pkgs.pamixer}/bin/pamixer $srce -i ''${step}
        notify_vol ;;
    d) ${pkgs.pamixer}/bin/pamixer $srce -d ''${step}
        notify_vol ;;
    m) ${pkgs.pamixer}/bin/pamixer $srce -t
        notify_mute ;;
    *) print_error ;;
  esac
''
```
