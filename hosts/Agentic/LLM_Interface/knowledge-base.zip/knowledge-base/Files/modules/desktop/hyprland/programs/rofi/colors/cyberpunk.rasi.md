# modules/desktop/hyprland/programs/rofi/colors/cyberpunk.rasi 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/colors/cyberpunk.rasi"
source_kind: text
extension: "rasi"
bytes: 278
sha256: 5ccabcd4db152f001bdc70aa264c3b9c4f2ba8a0fa80f725fee42a82f1e2f838
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/rasi
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/colors/cyberpunk.rasi`
- **Source kind:** text
- **Size:** 278 bytes, 17 lines
- **SHA-256:** `5ccabcd4db152f001bdc70aa264c3b9c4f2ba8a0fa80f725fee42a82f1e2f838`

## Searchable Metadata
- **Keywords:** adi1090x, selected, foreground, background-alt, urgent, active, FF0000FF, Shakya, Aditya, Author, background, Colors, Github
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/colors|modules/desktop/hyprland/programs/rofi/colors]]

## Source
```
css
/**
 *
 * Author : Aditya Shakya (adi1090x)
 * Github : @adi1090x
 * 
 * Colors
 **/

* {
    background:     #000B1EFF;
    background-alt: #0A1528FF;
    foreground:     #0ABDC6FF;
    selected:       #0ABDC6FF;
    active:         #00FF00FF;
    urgent:         #FF0000FF;
}
```
