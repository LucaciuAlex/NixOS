# modules/desktop/hyprland/icons/notifications/arch.svg 
---
type: repository-file
source_path: "modules/desktop/hyprland/icons/notifications/arch.svg"
source_kind: text
extension: "svg"
bytes: 7488
sha256: 29e4ed84877fee2acd8e406a9b055e05944cf7fa17f40c59cb0605b1f23a121e
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/svg
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/icons/notifications/arch.svg`
- **Source kind:** text
- **Size:** 7488 bytes, 130 lines
- **SHA-256:** `29e4ed84877fee2acd8e406a9b055e05944cf7fa17f40c59cb0605b1f23a121e`

## Searchable Metadata
- **Keywords:** Inkscape, fill, sodipodi, label, style, display, inline, fill-opacity, stroke-width, path, none, true, round, http, xmlns
- **Parent:** [[Files/modules/desktop/hyprland/icons/notifications|modules/desktop/hyprland/icons/notifications]]

### Detected Declarations / Headings
- `width=`
- `height=`
- `viewBox=`
- `version=`
- `id=`
- `xmlns=`
- `id=`
- `pagecolor=`
- `bordercolor=`
- `borderopacity=`
- `showgrid=`
- `id=`

### Detected References
- `sourceforge.net/DTD/sodipodi-0.dtd"`
- `url(#clipPath8)"`
- `url(#clipPath7)"`
- `url(#clipPath6)"`

## Source
```
xml
<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<!-- Created with Inkscape (http://www.inkscape.org/) -->

<svg
   width="300"
   height="300"
   viewBox="0 0 1 1"
   version="1.1"
   id="svg1"
   inkscape:version="1.3 (0e150ed6c4, 2023-07-21)"
   sodipodi:docname="arch.svg"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:svg="http://www.w3.org/2000/svg">
  <sodipodi:namedview
     id="namedview1"
     pagecolor="#ffffff"
     bordercolor="#000000"
     borderopacity="0.25"
     inkscape:showpageshadow="2"
     inkscape:pageopacity="0.0"
     inkscape:pagecheckerboard="0"
     inkscape:deskcolor="#d1d1d1"
     inkscape:document-units="mm"
     showgrid="true"
     inkscape:zoom="3.1251122"
     inkscape:cx="123.67556"
     inkscape:cy="187.99325"
     inkscape:window-width="2540"
     inkscape:window-height="1032"
     inkscape:window-x="0"
     inkscape:window-y="0"
     inkscape:window-maximized="1"
     inkscape:current-layer="layer1">
    <inkscape:grid
       id="grid1"
       units="mm"
       originx="0"
       originy="0"
       spacingx="0.012598425"
       spacingy="0.012598425"
       empcolor="#0099e5"
       empopacity="0.30196078"
       color="#0099e5"
       opacity="0.14901961"
       empspacing="5"
       dotted="false"
       gridanglex="30"
       gridanglez="30"
       visible="true" />
  </sodipodi:namedview>
  <defs
     id="defs1">
    <clipPath
       clipPathUnits="userSpaceOnUse"
       id="clipPath8">
      <path
         d="m 418.65593,41.52652 c -9.29195,23.22986 -15.26534,37.83149 -25.8847,60.39764 6.6371,7.30082 14.60163,15.26535 27.21212,23.89358 -13.93791,-5.30968 -23.22985,-11.28307 -29.86696,-17.25647 -13.93792,28.53955 -35.17665,68.36218 -77.65412,146.0163 33.18552,-19.91132 59.73394,-31.85811 84.29123,-36.50408 -1.32742,-4.64596 -1.99113,-9.29194 -1.99113,-14.60163 v -0.6637 c 0.66371,-21.90245 11.94678,-38.49522 25.22098,-37.16779 13.27421,0.66371 23.89358,19.24761 23.22987,41.15005 l -1.32742,11.28307 c 23.89358,4.64597 49.77828,17.25648 82.96381,35.84036 l -17.92019,-33.18551 c -8.62823,-6.63711 -17.92018,-15.26534 -36.50408,-25.221 12.61051,3.31855 21.90246,7.30082 29.20327,11.28308 C 442.54951,101.26046 437.90354,87.32254 418.65593,40.8628 Z"
         fill="#1793d1"
         id="path9"
         style="display:inline;fill:#000000;fill-opacity:1;stroke-width:0.663711"
         inkscape:label="clip" />
    </clipPath>
    <clipPath
       clipPathUnits="userSpaceOnUse"
       id="clipPath7">
      <path
         d="m 418.65593,41.52652 c -9.29195,23.22986 -15.26534,37.83149 -25.8847,60.39764 6.6371,7.30082 14.60163,15.26535 27.21212,23.89358 -13.93791,-5.30968 -23.22985,-11.28307 -29.86696,-17.25647 -13.93792,28.53955 -35.17665,68.36218 -77.65412,146.0163 33.18552,-19.91132 59.73394,-31.85811 84.29123,-36.50408 -1.32742,-4.64596 -1.99113,-9.29194 -1.99113,-14.60163 v -0.6637 c 0.66371,-21.90245 11.94678,-38.49522 25.22098,-37.16779 13.27421,0.66371 23.89358,19.24761 23.22987,41.15005 l -1.32742,11.28307 c 23.89358,4.64597 49.77828,17.25648 82.96381,35.84036 l -17.92019,-33.18551 c -8.62823,-6.63711 -17.92018,-15.26534 -36.50408,-25.221 12.61051,3.31855 21.90246,7.30082 29.20327,11.28308 C 442.54951,101.26046 437.90354,87.32254 418.65593,40.8628 Z"
         fill="#1793d1"
         id="path7"
         style="display:inline;fill:#000000;fill-opacity:1;stroke-width:0.663711"
         inkscape:label="clip" />
    </clipPath>
    <clipPath
       clipPathUnits="userSpaceOnUse"
       id="clipPath6">
      <path
         d="m 418.65593,41.52652 c -9.29195,23.22986 -15.26534,37.83149 -25.8847,60.39764 6.6371,7.30082 14.60163,15.26535 27.21212,23.89358 -13.93791,-5.30968 -23.22985,-11.28307 -29.86696,-17.25647 -13.93792,28.53955 -35.17665,68.36218 -77.65412,146.0163 33.18552,-19.91132 59.73394,-31.85811 84.29123,-36.50408 -1.32742,-4.64596 -1.99113,-9.29194 -1.99113,-14.60163 v -0.6637 c 0.66371,-21.90245 11.94678,-38.49522 25.22098,-37.16779 13.27421,0.66371 23.89358,19.24761 23.22987,41.15005 l -1.32742,11.28307 c 23.89358,4.64597 49.77828,17.25648 82.96381,35.84036 l -17.92019,-33.18551 c -8.62823,-6.63711 -17.92018,-15.26534 -36.50408,-25.221 12.61051,3.31855 21.90246,7.30082 29.20327,11.28308 C 442.54951,101.26046 437.90354,87.32254 418.65593,40.8628 Z"
         fill="#1793d1"
         id="path6"
         style="display:inline;fill:#000000;fill-opacity:1;stroke-width:0.663711"
         inkscape:label="clip" />
    </clipPath>
  </defs>
  <g
     inkscape:label="Layer 1"
     inkscape:groupmode="layer"
     id="layer1"
     transform="matrix(1.0598908,0,0,1.0598908,-0.03941891,-0.03583263)">
    <g
       id="g21"
       inkscape:label="arch"
       transform="matrix(0.00333333,0,0,0.00333333,-0.88260858,0.01685136)"
       style="display:inline">
      <path
         d="m 418.65593,41.52652 c -9.29195,23.22986 -15.26534,37.83149 -25.8847,60.39764 6.6371,7.30082 14.60163,15.26535 27.21212,23.89358 -13.93791,-5.30968 -23.22985,-11.28307 -29.86696,-17.25647 -13.93792,28.53955 -35.17665,68.36218 -77.65412,146.0163 33.18552,-19.91132 59.73394,-31.85811 84.29123,-36.50408 -1.32742,-4.64596 -1.99113,-9.29194 -1.99113,-14.60163 v -0.6637 c 0.66371,-21.90245 11.94678,-38.49522 25.22098,-37.16779 13.27421,0.66371 23.89358,19.24761 23.22987,41.15005 l -1.32742,11.28307 c 23.89358,4.64597 49.77828,17.25648 82.96381,35.84036 l -17.92019,-33.18551 c -8.62823,-6.63711 -17.92018,-15.26534 -36.50408,-25.221 12.61051,3.31855 21.90246,7.30082 29.20327,11.28308 C 442.54951,101.26046 437.90354,87.32254 418.65593,40.8628 Z"
         fill="#1793d1"
         id="path1-2"
         style="display:inline;fill:#313244;fill-opacity:1;stroke-width:0.663711"
         inkscape:label="arch"
         sodipodi:insensitive="true" />
      <path
         style="display:inline;opacity:1;fill:#ebbcba;fill-opacity:1;stroke:none;stroke-width:9.99999;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:none;stroke-opacity:1"
         d="M 309.2552,25.453285 471.27515,43.441735 397.21699,246.7304 283.64418,245.35855 Z"
         id="path18"
         sodipodi:nodetypes="ccccc"
         inkscape:label="rose_pine"
         clip-path="url(#clipPath8)"
         sodipodi:insensitive="true" />
      <path
         style="display:inline;opacity:1;fill:#c79bf0;fill-opacity:1;stroke:none;stroke-width:9.99999;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:none;stroke-opacity:1"
         d="m 404.44355,32.67351 c -16.5012,34.788169 -23.41457,57.362678 -27.2413,104.79371 -3.74908,46.46851 8.7204,102.56519 15.29829,107.68453 L 289.62826,255.68581 302.84361,32.762342 Z"
         id="path19"
         inkscape:label="decay_ce"
         clip-path="url(#clipPath7)"
         sodipodi:nodetypes="cscccc"
         sodipodi:insensitive="true" />
      <path
         style="display:inline;opacity:1;fill:#a9b1d6;fill-opacity:1;stroke:none;stroke-width:11.365;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:none;stroke-opacity:1"
         d="m 395.51413,30.654091 c -18.08973,8.534584 -60.3024,26.582721 -63.64955,72.955579 -4.50511,62.41512 36.15313,116.34568 64.00652,142.55838 L 300.61179,260.47098 296.44134,39.3843 Z"
         id="path21"
         inkscape:label="tokyo_night"
         clip-path="url(#clipPath6)"
         sodipodi:nodetypes="cscccc"
         sodipodi:insensitive="true" />
    </g>
  </g>
</svg>
```
