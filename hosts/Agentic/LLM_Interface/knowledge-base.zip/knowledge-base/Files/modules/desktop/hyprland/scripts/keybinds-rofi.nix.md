# modules/desktop/hyprland/scripts/keybinds-rofi.nix 
---
type: repository-file
source_path: "modules/desktop/hyprland/scripts/keybinds-rofi.nix"
source_kind: text
extension: "nix"
bytes: 860
sha256: 358b5d834c836d2e1dbc1261d474c5643fa7982093e89018da32f0640db6176a
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/scripts/keybinds-rofi.nix`
- **Source kind:** text
- **Size:** 860 bytes, 25 lines
- **SHA-256:** `358b5d834c836d2e1dbc1261d474c5643fa7982093e89018da32f0640db6176a`

## Searchable Metadata
- **Keywords:** keybinds, echo, pkgs.procps, XDG_CONFIG_HOME, keybinds_conf, msg, r_override, then, rofi_theme, display_keybinds, rofi, ENTER, will, have, function
- **Parent:** [[Files/modules/desktop/hyprland/scripts|modules/desktop/hyprland/scripts]]

### Detected Declarations / Headings
- `keybinds_conf=`
- `rofi_theme=`
- `r_override=`
- `msg=`
- `keybinds=`
- `display_keybinds=`

## Source
```
nix
{ pkgs, ... }:
pkgs.writeShellScriptBin "keybinds-show" ''
  ${pkgs.procps}/bin/pkill yad || true

  if ${pkgs.procps}/bin/pidof rofi > /dev/null; then
    ${pkgs.procps}/bin/pkill rofi
  fi

  keybinds_conf="''${XDG_CONFIG_HOME:-$HOME/.config}/hypr/hyprland.conf"
  rofi_theme="''${XDG_CONFIG_HOME:-$HOME/.config}/rofi/launchers/type-4/style-4.rasi"
  r_override="entry{placeholder:'Search KeyBinds...';}"
  msg='☣️ NOTE ☣️: Clicking with Mouse or Pressing ENTER will have NO function'

  keybinds=$(cat "$keybinds_conf" | ${pkgs.gnugrep}/bin/grep -E '^bind')

  if [[ -z "$keybinds" ]]; then
    echo "no keybinds found."
    exit 1
  fi

  display_keybinds=$(echo "$keybinds" | ${pkgs.gnused}/bin/sed 's/\$mainMod/SUPER/g')

  echo "$display_keybinds" | ${pkgs.rofi}/bin/rofi -dmenu -i -theme-str "$r_override" -config "$rofi_theme" -mesg "$msg"
''
```
