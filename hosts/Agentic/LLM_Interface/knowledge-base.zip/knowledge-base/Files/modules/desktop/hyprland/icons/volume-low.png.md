# modules/desktop/hyprland/icons/volume-low.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/icons/volume-low.png"
source_kind: binary
extension: "png"
bytes: 22565
sha256: c39ed05c349f435bd7fbb9cd2f6606486f064d68f1fe84899f5a087cfb61a1b1
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/icons/volume-low.png`
- **Source kind:** binary
- **Size:** 22565 bytes
- **SHA-256:** `c39ed05c349f435bd7fbb9cd2f6606486f064d68f1fe84899f5a087cfb61a1b1`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/icons|modules/desktop/hyprland/icons]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
