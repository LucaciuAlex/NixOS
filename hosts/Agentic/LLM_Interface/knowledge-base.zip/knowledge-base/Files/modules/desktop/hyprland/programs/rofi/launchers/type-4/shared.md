# modules/desktop/hyprland/programs/rofi/launchers/type-4/shared  This page represents the repository directory `modules/desktop/hyprland/programs/rofi/launchers/type-4/shared` and links to its indexed files.  ## Files
- [[modules/desktop/hyprland/programs/rofi/launchers/type-4/shared/colors.rasi.md|modules/desktop/hyprland/programs/rofi/launchers/type-4/shared/colors.rasi]]
- [[modules/desktop/hyprland/programs/rofi/launchers/type-4/shared/fonts.rasi.md|modules/desktop/hyprland/programs/rofi/launchers/type-4/shared/fonts.rasi]]
