# modules/desktop/hyprland/programs/rofi/colors/solarized.rasi 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/colors/solarized.rasi"
source_kind: text
extension: "rasi"
bytes: 278
sha256: 13d9abfece6a84dceac0860fa876e4bc68481ee66c6b0f2a7d6abee3d1f42972
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/rasi
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/colors/solarized.rasi`
- **Source kind:** text
- **Size:** 278 bytes, 17 lines
- **SHA-256:** `13d9abfece6a84dceac0860fa876e4bc68481ee66c6b0f2a7d6abee3d1f42972`

## Searchable Metadata
- **Keywords:** adi1090x, selected, EEE8D5FF, foreground, urgent, active, DC322FFF, background-alt, Shakya, Aditya, Author, background, Colors, Github
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/colors|modules/desktop/hyprland/programs/rofi/colors]]

## Source
```
css
/**
 *
 * Author : Aditya Shakya (adi1090x)
 * Github : @adi1090x
 * 
 * Colors
 **/

* {
    background:     #002B36FF;
    background-alt: #073642FF;
    foreground:     #EEE8D5FF;
    selected:       #268BD2FF;
    active:         #859900FF;
    urgent:         #DC322FFF;
}
```
