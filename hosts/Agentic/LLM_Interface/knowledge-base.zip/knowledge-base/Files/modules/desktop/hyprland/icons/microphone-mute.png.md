# modules/desktop/hyprland/icons/microphone-mute.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/icons/microphone-mute.png"
source_kind: binary
extension: "png"
bytes: 27368
sha256: 85c9bc8dfe25a678117c0abbd6f86978660023a3a1cfbfb4fe2ce4aec4b2129d
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/icons/microphone-mute.png`
- **Source kind:** binary
- **Size:** 27368 bytes
- **SHA-256:** `85c9bc8dfe25a678117c0abbd6f86978660023a3a1cfbfb4fe2ce4aec4b2129d`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/icons|modules/desktop/hyprland/icons]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
