# modules/desktop/hyprland/icons/notifications/vol/vol-5.svg 
---
type: repository-file
source_path: "modules/desktop/hyprland/icons/notifications/vol/vol-5.svg"
source_kind: text
extension: "svg"
bytes: 3374
sha256: f685a34bff7b8686daff7266cc30fa536f666cdb22dbcdca5918a50e6629e8fe
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/svg
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/icons/notifications/vol/vol-5.svg`
- **Source kind:** text
- **Size:** 3374 bytes, 85 lines
- **SHA-256:** `f685a34bff7b8686daff7266cc30fa536f666cdb22dbcdca5918a50e6629e8fe`

## Searchable Metadata
- **Keywords:** inkscape, label, sodipodi, fill, display, style, stroke-width, true, inline, fill-opacity, http, xmlns, SVG, path, insensitive
- **Parent:** [[Files/modules/desktop/hyprland/icons/notifications/vol|modules/desktop/hyprland/icons/notifications/vol]]

### Detected Declarations / Headings
- `height=`
- `width=`
- `version=`
- `id=`
- `viewBox=`
- `xmlns=`
- `id=`
- `id=`
- `pagecolor=`
- `bordercolor=`
- `borderopacity=`
- `showgrid=`

### Detected References
- `sourceforge.net/DTD/sodipodi-0.dtd"`

## Source
```
xml
<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<!-- Uploaded to: SVG Repo, www.svgrepo.com, Generator: SVG Repo Mixer Tools -->

<svg
   height="120px"
   width="120px"
   version="1.1"
   id="Layer_1"
   viewBox="0 0 496.8 496.8"
   xml:space="preserve"
   sodipodi:docname="vol-5.svg"
   inkscape:version="1.2.2 (b0a8486541, 2022-12-01)"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:svg="http://www.w3.org/2000/svg"><defs
   id="defs23" /><sodipodi:namedview
   id="namedview21"
   pagecolor="#ffffff"
   bordercolor="#000000"
   borderopacity="0.25"
   inkscape:showpageshadow="2"
   inkscape:pageopacity="0.0"
   inkscape:pagecheckerboard="0"
   inkscape:deskcolor="#d1d1d1"
   showgrid="true"
   inkscape:zoom="11.483414"
   inkscape:cx="58.08377"
   inkscape:cy="40.623806"
   inkscape:window-width="1867"
   inkscape:window-height="1011"
   inkscape:window-x="0"
   inkscape:window-y="0"
   inkscape:window-maximized="1"
   inkscape:current-layer="Layer_1"><inkscape:grid
     type="xygrid"
     id="grid3192" /></sodipodi:namedview>






<g
   id="g3158"
   inkscape:label="base"
   sodipodi:insensitive="true"><path
     style="display:inline;fill:#121c1b;fill-opacity:1;stroke-width:1.584"
     d="m 248.87519,445.92001 c 116.5824,0 212.8896,-91.2384 220.4928,-205.2864 0,5.0688 1.2672,8.8704 1.2672,13.9392 0,121.6512 -98.8416,221.76 -221.76,221.76 -121.6512,0 -221.759991,-98.8416 -221.759991,-221.76 0,-5.0688 0,-8.8704 1.2672,-13.9392 7.6032,114.048 103.910391,205.2864 220.492791,205.2864 z"
     id="path8"
     inkscape:label="shadow"
     sodipodi:insensitive="true" /><circle
     style="display:inline;fill:#283538;fill-opacity:1;stroke-width:1.584"
     cx="248.8752"
     cy="243.07127"
     r="221.76001"
     id="circle12"
     inkscape:label="dial"
     sodipodi:insensitive="true" /><path
     style="display:inline;fill:#000000;fill-opacity:0.153846;stroke-width:1.58653"
     d="m 405.74362,86.606184 c 86.3078,86.307816 86.3078,227.192636 0,313.500456 -86.30783,86.3078 -227.19264,86.3078 -313.500453,0"
     id="path14"
     inkscape:label="highlight"
     sodipodi:insensitive="true" /></g>

<g
   id="g3198"
   inkscape:label="main"><circle
     style="display:none;fill:#000000;fill-opacity:0;stroke-width:1.584"
     cx="-201.71448"
     cy="283.51288"
     r="221.76001"
     id="circle12-3"
     inkscape:label="anchor"
     transform="rotate(-81)" /><path
     style="display:inline;fill:#121c1b;fill-opacity:1;stroke-width:1.584"
     d="m 137.08929,220.92041 c 7.50959,1.18941 11.72305,6.98874 10.53365,14.49833 v 0 c -1.18941,7.50959 -6.98874,11.72305 -14.49833,10.53365 L 83.060659,238.02304 C 75.551067,236.83363 71.337608,231.0343 72.52701,223.52471 v 0 c 1.189403,-7.50959 6.988733,-11.72305 14.498325,-10.53365 z"
     id="path3789"
     inkscape:label="shadow" /><path
     style="display:inline;fill:#ea398a;stroke-width:1.584"
     d="m 137.36486,212.74235 c 7.5096,1.18941 11.72306,6.98874 10.53365,14.49833 v 0 c -1.1894,7.50959 -6.98873,11.72305 -14.49832,10.53365 l -50.063957,-7.92935 c -7.509592,-1.18941 -11.723052,-6.98874 -10.533649,-14.49833 v 0 c 1.189402,-7.50959 6.988732,-11.72305 14.498324,-10.53365 z"
     id="path915"
     inkscape:label="pointer" /></g>
</svg>
```
