# modules/desktop/hyprland/programs/rofi/launchers/type-3/shared/fonts.rasi 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/launchers/type-3/shared/fonts.rasi"
source_kind: text
extension: "rasi"
bytes: 128
sha256: 559635e45dbd86acfe32335245cc976d64e26735b06d22a2b24e3df82f545ac3
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/rasi
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/launchers/type-3/shared/fonts.rasi`
- **Source kind:** text
- **Size:** 128 bytes, 13 lines
- **SHA-256:** `559635e45dbd86acfe32335245cc976d64e26735b06d22a2b24e3df82f545ac3`

## Searchable Metadata
- **Keywords:** adi1090x, font, Fonts, Iosevka, Nerd, Aditya, Author, Github, Shakya
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/launchers/type-3/shared|modules/desktop/hyprland/programs/rofi/launchers/type-3/shared]]

## Source
```
css
/**
 *
 * Author : Aditya Shakya (adi1090x)
 * Github : @adi1090x
 * 
 * Fonts
 *
 **/

* {
    font: "Iosevka Nerd Font 10";
}
```
