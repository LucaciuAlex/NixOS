# modules/desktop/hyprland/programs/rofi/assets/style_5.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/assets/style_5.png"
source_kind: binary
extension: "png"
bytes: 30179
sha256: fce6c5e8f863fe2e3fc120b443aa556e77657439044026b26565c195558e0177
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/assets/style_5.png`
- **Source kind:** binary
- **Size:** 30179 bytes
- **SHA-256:** `fce6c5e8f863fe2e3fc120b443aa556e77657439044026b26565c195558e0177`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/assets|modules/desktop/hyprland/programs/rofi/assets]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
