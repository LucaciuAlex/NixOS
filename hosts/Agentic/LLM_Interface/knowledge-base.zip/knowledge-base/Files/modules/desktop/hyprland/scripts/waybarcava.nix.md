# modules/desktop/hyprland/scripts/waybarcava.nix 
---
type: repository-file
source_path: "modules/desktop/hyprland/scripts/waybarcava.nix"
source_kind: text
extension: "nix"
bytes: 682
sha256: c4fe4cdf49f936c48ad729e4dc79f0156e406be44e8d7b27182612c1d40ab632
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/scripts/waybarcava.nix`
- **Source kind:** text
- **Size:** 682 bytes, 34 lines
- **SHA-256:** `c4fe4cdf49f936c48ad729e4dc79f0156e406be44e8d7b27182612c1d40ab632`

## Searchable Metadata
- **Keywords:** config_file, dict, bar, for, method, done, EOF, bar_length, cava, ascii_max_range, monitor, ascii, data_format, pkgs.procps, pkgs.gawk
- **Parent:** [[Files/modules/desktop/hyprland/scripts|modules/desktop/hyprland/scripts]]

### Detected Declarations / Headings
- `bar=`
- `dict=`
- `bar_length=`
- `config_file=`
- `bars =`
- `method =`
- `source =`
- `method =`
- `raw_target =`
- `data_format =`
- `ascii_max_range =`

### Detected References
- `source = auto`

## Source
```
nix
{ pkgs, ... }:
pkgs.writeShellScriptBin "waybarcava" ''
  bar="▁▂▃▄▅▆▇█"
  dict="s/;//g"

  bar_length=''${#bar}

  for ((i = 0; i < bar_length; i++)); do
    dict+=";s/$i/''${bar:$i:1}/g"
  done

  config_file="/tmp/bar_cava_config"
  cat >"$config_file" <<EOF
[general]
bars = 10

[input]
method = pulse
source = auto

[output]
method = raw
raw_target = /dev/stdout
data_format = ascii
ascii_max_range = 7
EOF

  ${pkgs.procps}/bin/pkill -f "cava -p $config_file"

  for monitor in $(hyprctl monitors | ${pkgs.gnugrep}/bin/grep "ID" | ${pkgs.gawk}/bin/awk '{print $2}'); do
    ${pkgs.cava}/bin/cava -p "$config_file" | ${pkgs.gnused}/bin/sed -u "$dict"
  done
''
```
