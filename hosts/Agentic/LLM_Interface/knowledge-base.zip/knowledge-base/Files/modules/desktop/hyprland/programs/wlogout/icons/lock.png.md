# modules/desktop/hyprland/programs/wlogout/icons/lock.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/wlogout/icons/lock.png"
source_kind: binary
extension: "png"
bytes: 5771
sha256: cbc578381229b0f19c2746e2959ebbaba99c59835a77244efcea0a885afaced9
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/wlogout/icons/lock.png`
- **Source kind:** binary
- **Size:** 5771 bytes
- **SHA-256:** `cbc578381229b0f19c2746e2959ebbaba99c59835a77244efcea0a885afaced9`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/programs/wlogout/icons|modules/desktop/hyprland/programs/wlogout/icons]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
