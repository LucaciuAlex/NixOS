# modules/desktop/hyprland/programs/wlogout/default.nix.bak 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/wlogout/default.nix.bak"
source_kind: text
extension: "bak"
bytes: 2807
sha256: 85253c9c9e6300d9088b724ef8fd8badd7cc8d20cc9bd87409efe8dca681f7bd
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/bak
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/wlogout/default.nix.bak`
- **Source kind:** text
- **Size:** 2807 bytes, 122 lines
- **SHA-256:** `85253c9c9e6300d9088b724ef8fd8badd7cc8d20cc9bd87409efe8dca681f7bd`

## Searchable Metadata
- **Keywords:** url, background-image, label, action, text, image, suspend, systemctl, reboot, rgba, button, hibernate, logout, shutdown, lock
- **Parent:** [[Files/modules/desktop/hyprland/programs/wlogout|modules/desktop/hyprland/programs/wlogout]]

### Detected Declarations / Headings
- `source =`
- `recursive =`

### Detected References
- `source = ./icons;`
- `url("./icons/lock.png"),`
- `url("/usr/share/wlogout/icons/lock.png"),`
- `url("/usr/local/share/wlogout/icons/lock.png")`
- `url("./icons/logout.png"),`
- `url("/usr/share/wlogout/icons/logout.png"),`
- `url("/usr/local/share/wlogout/icons/logout.png")`
- `url("./icons/suspend.png"),`
- `url("/usr/share/wlogout/icons/suspend.png"),`
- `url("/usr/local/share/wlogout/icons/suspend.png")`
- `url("./icons/hibernate.png"),`
- `url("/usr/share/wlogout/icons/hibernate.png"),`

## Source
```
text
{
  config,
  pkgs,
  ...
}: {
  programs.wlogout.enable = true;
  home.file.".config/wlogout/icons" = {
    source = ./icons;
    recursive = true;
  };

  home.file.".config/wlogout/layout".text = ''
    {
    	"label" : "lock",
    		"action" : "swaylock",
    		"text" : "Lock"
    }
    {
    	"label" : "hibernate",
    		"action" : "systemctl hibernate",
    		"text" : "Hibernate"
    }
    {
    	"label" : "logout",
    		"action" : "hyprctl dispatch exit 0",
    		"text" : "Logout"
    }
    {
    	"label" : "shutdown",
    		"action" : "systemctl poweroff",
    		"text" : "Shutdown"
    }
    {
    	"label" : "suspend",
    		"action" : "systemctl suspend",
    		"text" : "Suspend"
    }
    {
    	"label" : "reboot",
    		"action" : "systemctl reboot",
    		"text" : "Reboot"
    }
  '';
  home.file.".config/wlogout/style.css".text = ''
    		* {
    			background-image: none;
    		}
    	window {
    		background-color: transparent;
    	}
    	button {
    color: #53565c;
           background-color: rgba(24, 26, 31, .5);
           border-style: solid;
           border-color: rgba(24, 26, 31, .5);
           border-width: 2px;
           border-radius: 7px;
           background-repeat: no-repeat;
           background-position: center;
           background-size: 25%;
    margin: 10px;
    	}

    button:focus,
    	       button:active,
    	       button:hover {
    		       background-color: rgba(24, 26, 31, .7);
    		       border-color: rgba(24, 26, 31, .7);
    color: #d4d4d6;
           outline-style: none;
    	       }

    #lock {
    	background-image: image(
    			url("./icons/lock.png"),
    			url("/usr/share/wlogout/icons/lock.png"),
    			url("/usr/local/share/wlogout/icons/lock.png")
    			);
    }

    #logout {
    	background-image: image(
    			url("./icons/logout.png"),
    			url("/usr/share/wlogout/icons/logout.png"),
    			url("/usr/local/share/wlogout/icons/logout.png")
    			);
    }

    #suspend {
    	background-image: image(
    			url("./icons/suspend.png"),
    			url("/usr/share/wlogout/icons/suspend.png"),
    			url("/usr/local/share/wlogout/icons/suspend.png")
    			);
    }

    #hibernate {
    	background-image: image(
    			url("./icons/hibernate.png"),
    			url("/usr/share/wlogout/icons/hibernate.png"),
    			url("/usr/local/share/wlogout/icons/hibernate.png")
    			);
    }

    #shutdown {
    	background-image: image(
    			url("./icons/shutdown.png"),
    			url("/usr/share/wlogout/icons/shutdown.png"),
    			url("/usr/local/share/wlogout/icons/shutdown.png")
    			);
    }

    #reboot {
    	background-image: image(
    			url("./icons/reboot.png"),
    			url("/usr/share/wlogout/icons/reboot.png"),
    			url("/usr/local/share/wlogout/icons/reboot.png")
    			);
    }
  '';
}
```
