# modules/desktop/hyprland/icons/brightness-40.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/icons/brightness-40.png"
source_kind: binary
extension: "png"
bytes: 23444
sha256: ef93376a898d2778f88214ccf739429c86be262dbd110ffc12c48e20261881d1
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/icons/brightness-40.png`
- **Source kind:** binary
- **Size:** 23444 bytes
- **SHA-256:** `ef93376a898d2778f88214ccf739429c86be262dbd110ffc12c48e20261881d1`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/icons|modules/desktop/hyprland/icons]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
