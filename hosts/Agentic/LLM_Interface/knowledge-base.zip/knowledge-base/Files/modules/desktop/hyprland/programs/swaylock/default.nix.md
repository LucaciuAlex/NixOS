# modules/desktop/hyprland/programs/swaylock/default.nix 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/swaylock/default.nix"
source_kind: text
extension: "nix"
bytes: 1146
sha256: aaf4b645249fb102beff544a7e429e76ee560c62fcc8ffae81dbdeed43c807f3
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/swaylock/default.nix`
- **Source kind:** text
- **Size:** 1146 bytes, 42 lines
- **SHA-256:** `aaf4b645249fb102beff544a7e429e76ee560c62fcc8ffae81dbdeed43c807f3`

## Searchable Metadata
- **Keywords:** f4dbd6, f5a97f, ee99a0, a6da95, cad3f5, true, line-wrong-color, ring-ver-color, ring-caps-lock-color, ring-color, ring-clear-color, b7bdf8, ring-wrong-color, text-wrong-color, text-ver-color
- **Parent:** [[Files/modules/desktop/hyprland/programs/swaylock|modules/desktop/hyprland/programs/swaylock]]

### Detected Declarations / Headings
- `color=`
- `bs-hl-color=`
- `caps-lock-bs-hl-color=`
- `caps-lock-key-hl-color=`
- `inside-color=`
- `inside-clear-color=`
- `inside-caps-lock-color=`
- `inside-ver-color=`
- `inside-wrong-color=`
- `key-hl-color=`
- `layout-bg-color=`
- `layout-border-color=`

## Source
```
nix
{ ... }:
{
  home-manager.sharedModules = [
    (_: {
      xdg.configFile."swaylock/config".text = ''
        color=24273a
        bs-hl-color=f4dbd6
        caps-lock-bs-hl-color=f4dbd6
        caps-lock-key-hl-color=a6da95
        inside-color=00000000
        inside-clear-color=00000000
        inside-caps-lock-color=00000000
        inside-ver-color=00000000
        inside-wrong-color=00000000
        key-hl-color=a6da95
        layout-bg-color=00000000
        layout-border-color=00000000
        layout-text-color=cad3f5
        line-color=00000000
        line-clear-color=00000000
        line-caps-lock-color=00000000
        line-ver-color=00000000
        line-wrong-color=00000000
        ring-color=b7bdf8
        ring-clear-color=f4dbd6
        ring-caps-lock-color=f5a97f
        ring-ver-color=8aadf4
        ring-wrong-color=ee99a0
        separator-color=00000000
        text-color=cad3f5
        text-clear-color=f4dbd6
        text-caps-lock-color=f5a97f
        text-ver-color=8aadf4
        text-wrong-color=ee99a0
      '';

      programs.swaylock.enable = true;
      programs.wlogout.enable = true;
    })
  ];
}
```
