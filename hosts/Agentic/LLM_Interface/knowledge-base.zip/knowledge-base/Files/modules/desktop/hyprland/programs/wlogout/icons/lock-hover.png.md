# modules/desktop/hyprland/programs/wlogout/icons/lock-hover.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/wlogout/icons/lock-hover.png"
source_kind: binary
extension: "png"
bytes: 5771
sha256: 336b55138423b18f3cc472867e6ebc2456ed0a5faf97a53c36684e8da3d4b1ab
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/wlogout/icons/lock-hover.png`
- **Source kind:** binary
- **Size:** 5771 bytes
- **SHA-256:** `336b55138423b18f3cc472867e6ebc2456ed0a5faf97a53c36684e8da3d4b1ab`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/programs/wlogout/icons|modules/desktop/hyprland/programs/wlogout/icons]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
