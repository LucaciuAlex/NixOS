# modules/desktop/hyprland/programs/caelestia-shell  This page represents the repository directory `modules/desktop/hyprland/programs/caelestia-shell` and links to its indexed files.  ## Files
- [[modules/desktop/hyprland/programs/caelestia-shell/default.nix.md|modules/desktop/hyprland/programs/caelestia-shell/default.nix]]
