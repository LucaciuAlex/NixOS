# modules/desktop/i3/scripts/wallpaper.nix 
---
type: repository-file
source_path: "modules/desktop/i3/scripts/wallpaper.nix"
source_kind: text
extension: "nix"
bytes: 183
sha256: 6b6bf8b42468539517bf74833119f13fd9682b2e85ed524cfbcafa3d31c30532
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/i3/scripts/wallpaper.nix`
- **Source kind:** text
- **Size:** 183 bytes, 7 lines
- **SHA-256:** `6b6bf8b42468539517bf74833119f13fd9682b2e85ed524cfbcafa3d31c30532`

## Searchable Metadata
- **Keywords:** output, print, awk, done, feh, xrandr, wallpaper, pkgs.writeShellScriptBin, pkgs, for
- **Parent:** [[Files/modules/desktop/i3/scripts|modules/desktop/i3/scripts]]

## Source
```
nix
{ pkgs, ... }:
pkgs.writeShellScriptBin "wallpaper" ''
for output in $(xrandr --listmonitors | awk 'NR>1 {print $4}'); do
    feh --bg-fill "$1" --no-fehbg --output "$output"
done
''
```
