# modules/desktop/hyprland/icons/battery-status.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/icons/battery-status.png"
source_kind: binary
extension: "png"
bytes: 8682
sha256: f56dd3ec87b2678069d5624f1ce62b13445d875c3c1645243163b79561187a78
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/icons/battery-status.png`
- **Source kind:** binary
- **Size:** 8682 bytes
- **SHA-256:** `f56dd3ec87b2678069d5624f1ce62b13445d875c3c1645243163b79561187a78`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/icons|modules/desktop/hyprland/icons]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
