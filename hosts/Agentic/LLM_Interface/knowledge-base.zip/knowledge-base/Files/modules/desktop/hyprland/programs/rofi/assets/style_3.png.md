# modules/desktop/hyprland/programs/rofi/assets/style_3.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/assets/style_3.png"
source_kind: binary
extension: "png"
bytes: 25220
sha256: f2f970cac855f24e45a8e3a97430325933e538c0c0a4feff93fdb551249e7e84
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/assets/style_3.png`
- **Source kind:** binary
- **Size:** 25220 bytes
- **SHA-256:** `f2f970cac855f24e45a8e3a97430325933e538c0c0a4feff93fdb551249e7e84`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/assets|modules/desktop/hyprland/programs/rofi/assets]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
