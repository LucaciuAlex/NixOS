# modules/desktop/hyprland/icons/uptime.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/icons/uptime.png"
source_kind: binary
extension: "png"
bytes: 17642
sha256: c08e80e78ae3878741b1f092c67410d783c362ae111eeda865cb558f8e9f4f4b
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/icons/uptime.png`
- **Source kind:** binary
- **Size:** 17642 bytes
- **SHA-256:** `c08e80e78ae3878741b1f092c67410d783c362ae111eeda865cb558f8e9f4f4b`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/icons|modules/desktop/hyprland/icons]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
