# modules/desktop/hyprland/programs/rofi/default.nix 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/default.nix"
source_kind: text
extension: "nix"
bytes: 730
sha256: f270c74102c7bbaa250b61727aa8606554dedea68175d5a308e86b14e9700370
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/default.nix`
- **Source kind:** text
- **Size:** 730 bytes, 34 lines
- **SHA-256:** `f270c74102c7bbaa250b61727aa8606554dedea68175d5a308e86b14e9700370`

## Searchable Metadata
- **Keywords:** terminal, true, getExe, source, recursive, https, xdg.configFile., inherit, lib, host, import, pkgs, extraConfig, rofi-games, enable
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi|modules/desktop/hyprland/programs/rofi]]

### Detected Declarations / Headings
- `enable =`
- `terminal =`
- `plugins =`
- `extraConfig =`
- `source =`
- `recursive =`
- `source =`
- `recursive =`

### Detected References
- `import ../../../../../hosts/${host}/variables.nix) terminal;`
- `import ./config.nix;`
- `source = ./launchers;`
- `source = ./colors;`

## Source
```
nix
{
  pkgs,
  lib,
  host,
  ...
}:
let
  inherit (import ../../../../../hosts/${host}/variables.nix) terminal;
  inherit (lib) getExe;
in
{
  home-manager.sharedModules = [
    (_: {
      programs.rofi = {
        enable = true;
        terminal = "${getExe pkgs.${terminal}}";
        plugins = with pkgs; [
          rofi-emoji # https://github.com/Mange/rofi-emoji 🤯
          rofi-games # https://github.com/Rolv-Apneseth/rofi-games 🎮
        ];
        extraConfig = import ./config.nix;
      };
      xdg.configFile."rofi/launchers" = {
        source = ./launchers;
        recursive = true;
      };
      xdg.configFile."rofi/colors" = {
        source = ./colors;
        recursive = true;
      };
    })
  ];
}
```
