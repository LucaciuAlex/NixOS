# modules/desktop/hyprland/programs/rofi/launchers/type-3/shared  This page represents the repository directory `modules/desktop/hyprland/programs/rofi/launchers/type-3/shared` and links to its indexed files.  ## Files
- [[modules/desktop/hyprland/programs/rofi/launchers/type-3/shared/colors.rasi.md|modules/desktop/hyprland/programs/rofi/launchers/type-3/shared/colors.rasi]]
- [[modules/desktop/hyprland/programs/rofi/launchers/type-3/shared/fonts.rasi.md|modules/desktop/hyprland/programs/rofi/launchers/type-3/shared/fonts.rasi]]
