# modules/desktop/hyprland/programs/wlogout/icons/restart-hover.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/wlogout/icons/restart-hover.png"
source_kind: binary
extension: "png"
bytes: 7810
sha256: 18c5e6b3ca933b444f981019146989f7f06fd225053c9905739d9a177cd3386d
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/wlogout/icons/restart-hover.png`
- **Source kind:** binary
- **Size:** 7810 bytes
- **SHA-256:** `18c5e6b3ca933b444f981019146989f7f06fd225053c9905739d9a177cd3386d`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/programs/wlogout/icons|modules/desktop/hyprland/programs/wlogout/icons]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
