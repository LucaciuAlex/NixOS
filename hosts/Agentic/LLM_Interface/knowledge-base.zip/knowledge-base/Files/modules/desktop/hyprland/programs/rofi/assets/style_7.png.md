# modules/desktop/hyprland/programs/rofi/assets/style_7.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/assets/style_7.png"
source_kind: binary
extension: "png"
bytes: 20313
sha256: 3c97c0024cd460b2e557fc271ee7cd9e508a4e2ba4777f26b4c195617ffab95a
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/assets/style_7.png`
- **Source kind:** binary
- **Size:** 20313 bytes
- **SHA-256:** `3c97c0024cd460b2e557fc271ee7cd9e508a4e2ba4777f26b4c195617ffab95a`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/assets|modules/desktop/hyprland/programs/rofi/assets]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
