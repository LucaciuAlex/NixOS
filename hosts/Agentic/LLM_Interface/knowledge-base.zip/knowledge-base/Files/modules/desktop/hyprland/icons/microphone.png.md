# modules/desktop/hyprland/icons/microphone.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/icons/microphone.png"
source_kind: binary
extension: "png"
bytes: 24921
sha256: b8adc3aab1ea73c88422933eb70097474025848d9c1a209a9f326d8796825ebb
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/icons/microphone.png`
- **Source kind:** binary
- **Size:** 24921 bytes
- **SHA-256:** `b8adc3aab1ea73c88422933eb70097474025848d9c1a209a9f326d8796825ebb`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/icons|modules/desktop/hyprland/icons]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
