# modules/desktop/hyprland/programs/rofi/assets/style_8.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/assets/style_8.png"
source_kind: binary
extension: "png"
bytes: 21338
sha256: 8a179fd42a74d7d37adb18b373b4328b90cc211d4a3a33e3e4c3f9766daded8d
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/assets/style_8.png`
- **Source kind:** binary
- **Size:** 21338 bytes
- **SHA-256:** `8a179fd42a74d7d37adb18b373b4328b90cc211d4a3a33e3e4c3f9766daded8d`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/assets|modules/desktop/hyprland/programs/rofi/assets]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
