# modules/desktop/i3/polybar/scripts/workspaces.nix 
---
type: repository-file
source_path: "modules/desktop/i3/polybar/scripts/workspaces.nix"
source_kind: text
extension: "nix"
bytes: 608
sha256: 057db3061d5ece8b34b0920d7294e29d99ff7da53bfac0c3eb90b54375a65b89
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/i3/polybar/scripts/workspaces.nix`
- **Source kind:** text
- **Size:** 608 bytes, 17 lines
- **SHA-256:** `057db3061d5ece8b34b0920d7294e29d99ff7da53bfac0c3eb90b54375a65b89`

## Searchable Metadata
- **Keywords:** echo, workspaces, pkgs.jq, then, FOCUSED, get_workspaces, EXISTING, pkgs.i3, workspace, cba6f7, for, done, else, elif, grep
- **Parent:** [[Files/modules/desktop/i3/polybar/scripts|modules/desktop/i3/polybar/scripts]]

### Detected Declarations / Headings
- `WORKSPACES=`
- `EXISTING=`
- `FOCUSED=`
- `#`
- `#`

## Source
```
nix
{ pkgs, ... }:
pkgs.writeShellScriptBin "workspaces" ''
  WORKSPACES=(1 2 3 4 5 6 7 8 9 10)
  EXISTING=$(${pkgs.i3}/bin/i3-msg -t get_workspaces | ${pkgs.jq}/bin/jq -r '.[] | .num')
  FOCUSED=$(${pkgs.i3}/bin/i3-msg -t get_workspaces | ${pkgs.jq}/bin/jq -r '.[] | select(.focused==true).num')
  echo -n " " # Add spacing before first workspace
  for ws in "''${WORKSPACES[@]}"; do
    if [ "$ws" -eq "$FOCUSED" ]; then
      echo -n "%{F#cba6f7}$ws%{F-} "
    # elif echo "$EXISTING" | grep -q "$ws"; then
    #   echo -n "%{F#89b4fa}$ws%{F-} "
    else
      echo -n "%{F#6c7086}$ws%{F-} "
    fi
  done
''
```
