# modules/desktop/hyprland/programs/rofi/colors/tokyonight.rasi 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/colors/tokyonight.rasi"
source_kind: text
extension: "rasi"
bytes: 289
sha256: fece7d13084665cf4eec29b5d5949cf0f869933f924d6a3347b9e24999d3d400
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/rasi
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/colors/tokyonight.rasi`
- **Source kind:** text
- **Size:** 289 bytes, 17 lines
- **SHA-256:** `fece7d13084665cf4eec29b5d5949cf0f869933f924d6a3347b9e24999d3d400`

## Searchable Metadata
- **Keywords:** fishyfishfish55, selected, C0CAF5FF, foreground, urgent, active, F7768EFF, background-alt, Lacoss, Levi, Author, background, Colors, Github
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/colors|modules/desktop/hyprland/programs/rofi/colors]]

## Source
```
css
/**
 *
 * Author : Levi Lacoss (fishyfishfish55)
 * Github : @fishyfishfish55
 *
 * Colors
 **/

* {
    background:     #15161EFF;
    background-alt: #1A1B26FF;
    foreground:     #C0CAF5FF;
    selected:       #33467CFF;
    active:         #414868FF;
    urgent:         #F7768EFF;
}
```
