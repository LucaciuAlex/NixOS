# modules/desktop/hyprland/programs/rofi/colors/dracula.rasi 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/colors/dracula.rasi"
source_kind: text
extension: "rasi"
bytes: 278
sha256: db08b87b28015712008bfa0eb8ef8e1b4944aa5cf55bf78b03871ee47429d124
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/rasi
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/colors/dracula.rasi`
- **Source kind:** text
- **Size:** 278 bytes, 17 lines
- **SHA-256:** `db08b87b28015712008bfa0eb8ef8e1b4944aa5cf55bf78b03871ee47429d124`

## Searchable Metadata
- **Keywords:** adi1090x, selected, FFFFFFFF, foreground, BD93F9FF, urgent, active, FF5555FF, Shakya, Aditya, Author, Github, background-alt, background, Colors
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/colors|modules/desktop/hyprland/programs/rofi/colors]]

## Source
```
css
/**
 *
 * Author : Aditya Shakya (adi1090x)
 * Github : @adi1090x
 * 
 * Colors
 **/

* {
    background:     #1E1F29FF;
    background-alt: #282A36FF;
    foreground:     #FFFFFFFF;
    selected:       #BD93F9FF;
    active:         #50FA7BFF;
    urgent:         #FF5555FF;
}
```
