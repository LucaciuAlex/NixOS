# modules/desktop/hyprland/scripts/autoclicker.nix 
---
type: repository-file
source_path: "modules/desktop/hyprland/scripts/autoclicker.nix"
source_kind: text
extension: "nix"
bytes: 1211
sha256: dd1128005c922b2f4fc1f058f25dfe49e80177a60472087c2ec2a692e5c037c3
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/scripts/autoclicker.nix`
- **Source kind:** text
- **Size:** 1211 bytes, 44 lines
- **SHA-256:** `dd1128005c922b2f4fc1f058f25dfe49e80177a60472087c2ec2a692e5c037c3`

## Searchable Metadata
- **Keywords:** import, auto-clicker, uinput.BTN_LEFT, print, Clicks, per, Set, time.sleep, CPS, os.getpid, with, default, Starting, delay, device.emit
- **Parent:** [[Files/modules/desktop/hyprland/scripts|modules/desktop/hyprland/scripts]]

### Detected Declarations / Headings
- `libraries =`
- `flakeIgnore =`
- `#`
- `parser =`
- `args =`
- `#`
- `click_delay =`
- `#`
- `keys =`
- `device =`

### Detected References
- `import os`
- `import time`
- `import uinput`
- `import argparse`

## Source
```
nix
{ pkgs, ... }:
pkgs.writers.writePython3Bin "auto-clicker"
  {
    libraries = [ pkgs.python3Packages.python-uinput ];
    flakeIgnore = [
      "E265"
      "E225"
      "E501"
    ];
  }
  ''
    import os
    import time
    import uinput
    import argparse

    # Set up command line argument parsing
    parser = argparse.ArgumentParser(description='Auto-clicker with configurable CPS')
    parser.add_argument('--cps', type=float, default=40.0, help='Clicks per second (default: 40)')
    args = parser.parse_args()

    # Calculate delay based on CPS
    click_delay = 1 / args.cps

    # Set up the uinput device
    keys = [uinput.BTN_LEFT]
    with open("/tmp/auto-clicker.pid", "w") as f:
        f.write(str(os.getpid()))

    print(f"Starting auto-clicker at {args.cps} clicks per second")
    print(f"PID: {os.getpid()} (saved to /tmp/auto-clicker.pid)")

    device = uinput.Device(keys)
    time.sleep(0.2)  # Small delay before starting to click

    try:
        while True:
            device.emit(uinput.BTN_LEFT, 1)  # Press
            device.emit(uinput.BTN_LEFT, 0)  # Release
            time.sleep(click_delay)
    except KeyboardInterrupt:
        print("Auto-clicker stopped")
  ''
```
