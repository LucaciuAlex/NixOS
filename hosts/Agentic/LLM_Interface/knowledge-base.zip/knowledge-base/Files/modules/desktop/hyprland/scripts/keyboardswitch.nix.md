# modules/desktop/hyprland/scripts/keyboardswitch.nix 
---
type: repository-file
source_path: "modules/desktop/hyprland/scripts/keyboardswitch.nix"
source_kind: text
extension: "nix"
bytes: 411
sha256: 1b82aae30768ecdfcc4dec8bb275ebc1306a99573719c8f98aeef2eb16998587
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/scripts/keyboardswitch.nix`
- **Source kind:** text
- **Size:** 411 bytes, 9 lines
- **SHA-256:** `1b82aae30768ecdfcc4dec8bb275ebc1306a99573719c8f98aeef2eb16998587`

## Searchable Metadata
- **Keywords:** layMain, pkgs.jq, true, select, System, print, pkgs.libnotify, pkgs.gawk, active_keymap, keyboardswitch, hyprctl, pkgs, pkgs.writeShellScriptBin, next, devices
- **Parent:** [[Files/modules/desktop/hyprland/scripts|modules/desktop/hyprland/scripts]]

### Detected Declarations / Headings
- `layMain=`

## Source
```
nix
{ pkgs, ... }:
pkgs.writeShellScriptBin "keyboardswitch" ''
  hyprctl switchxkblayout all next

  layMain=$(/bin/hyprctl -j devices | ${pkgs.jq}/bin/jq '.keyboards' | ${pkgs.jq}/bin/jq '.[] | select (.main == true)' | ${pkgs.gawk}/bin/awk -F '"' '{if ($2=="active_keymap") print $4}')

  ${pkgs.libnotify}/bin/notify-send -a "System" -r 91190 -t 800 -i "$HOME/.config/hypr/icons/keyboard.svg" "''${layMain}"
''
```
