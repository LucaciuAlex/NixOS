# modules/desktop/hyprland/programs/swaync/music.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/swaync/music.png"
source_kind: binary
extension: "png"
bytes: 26416
sha256: 96a04f67914bbc295abb5970c13154227852f00af2ce3aea0df9f8004a438e3b
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/swaync/music.png`
- **Source kind:** binary
- **Size:** 26416 bytes
- **SHA-256:** `96a04f67914bbc295abb5970c13154227852f00af2ce3aea0df9f8004a438e3b`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/programs/swaync|modules/desktop/hyprland/programs/swaync]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
