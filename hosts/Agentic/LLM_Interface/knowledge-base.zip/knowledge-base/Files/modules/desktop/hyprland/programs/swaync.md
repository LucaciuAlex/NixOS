# modules/desktop/hyprland/programs/swaync  This page represents the repository directory `modules/desktop/hyprland/programs/swaync` and links to its indexed files.  ## Files
- [[modules/desktop/hyprland/programs/swaync/default.nix.md|modules/desktop/hyprland/programs/swaync/default.nix]]
- [[modules/desktop/hyprland/programs/swaync/music.png.md|modules/desktop/hyprland/programs/swaync/music.png]]
