# modules/desktop/hyprland/icons/volume-mute.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/icons/volume-mute.png"
source_kind: binary
extension: "png"
bytes: 23907
sha256: f0726cf88c06092cb52026a87d90571c9a8bb869a975ab6969f2b3a0ece9248b
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/icons/volume-mute.png`
- **Source kind:** binary
- **Size:** 23907 bytes
- **SHA-256:** `f0726cf88c06092cb52026a87d90571c9a8bb869a975ab6969f2b3a0ece9248b`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/icons|modules/desktop/hyprland/icons]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
