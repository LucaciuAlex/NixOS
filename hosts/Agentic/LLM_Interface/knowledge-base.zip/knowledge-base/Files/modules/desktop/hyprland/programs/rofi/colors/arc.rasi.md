# modules/desktop/hyprland/programs/rofi/colors/arc.rasi 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/colors/arc.rasi"
source_kind: text
extension: "rasi"
bytes: 278
sha256: a8b8ee97da9a76c349b3e93889335b886b522be8b91dfc77978a982e18263e6d
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/rasi
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/colors/arc.rasi`
- **Source kind:** text
- **Size:** 278 bytes, 17 lines
- **SHA-256:** `a8b8ee97da9a76c349b3e93889335b886b522be8b91dfc77978a982e18263e6d`

## Searchable Metadata
- **Keywords:** adi1090x, selected, BAC5D0FF, foreground, urgent, active, E06B74FF, background-alt, Shakya, Aditya, Author, background, Colors, Github
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/colors|modules/desktop/hyprland/programs/rofi/colors]]

## Source
```
css
/**
 *
 * Author : Aditya Shakya (adi1090x)
 * Github : @adi1090x
 * 
 * Colors
 **/

* {
    background:     #2F343FFF;
    background-alt: #383C4AFF;
    foreground:     #BAC5D0FF;
    selected:       #5294E2FF;
    active:         #98C379FF;
    urgent:         #E06B74FF;
}
```
