# modules/desktop/hyprland/programs/hypridle/default.nix 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/hypridle/default.nix"
source_kind: text
extension: "nix"
bytes: 1051
sha256: 07f52b2a56be6a2268d4e0e22f43835e4f2cf4b8a9f3ad44fe8a0bbaf9cbf0ce
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/hypridle/default.nix`
- **Source kind:** text
- **Size:** 1051 bytes, 40 lines
- **SHA-256:** `07f52b2a56be6a2268d4e0e22f43835e4f2cf4b8a9f3ad44fe8a0bbaf9cbf0ce`

## Searchable Metadata
- **Keywords:** timeout, hyprctl, dispatch, dpms, on-timeout, hyprlock, pkgs, loginctl, Minutes, lock-session, after_sleep_cmd, before_sleep_cmd, systemctl, suspend, on-resume
- **Parent:** [[Files/modules/desktop/hyprland/programs/hypridle|modules/desktop/hyprland/programs/hypridle]]

### Detected Declarations / Headings
- `enable =`
- `settings =`
- `general =`
- `ignore_dbus_inhibit =`
- `lock_cmd =`
- `unlock_cmd =`
- `before_sleep_cmd =`
- `after_sleep_cmd =`
- `listener =`
- `timeout =`
- `on-timeout =`
- `timeout =`

## Source
```
nix
{ pkgs, ... }:
{
  environment.systemPackages = with pkgs; [ hypridle ];
  home-manager.sharedModules = [
    (_: {
      services.hypridle = {
        enable = true;
        settings = {
          general = {
            ignore_dbus_inhibit = false;
            lock_cmd = "pidof hyprlock || hyprlock";
            unlock_cmd = "pkill --signal SIGUSR1 hyprlock";
            before_sleep_cmd = "loginctl lock-session";
            after_sleep_cmd = "hyprctl dispatch dpms on";
          };
          listener = [
            {
              timeout = 600; # 10 Minutes
              on-timeout = "loginctl lock-session";
            }
            /*
              {
                timeout = 360; # 6 Minutes
                on-timeout = "hyprctl dispatch dpms off";
                on-resume = "hyprctl dispatch dpms on";
              }
            */
            /*
              {
                timeout = 600; # 10m
                on-timeout = "systemctl suspend";
              }
            */
          ];
        };
      };
    })
  ];
}
```
