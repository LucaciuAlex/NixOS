# modules/desktop/gnome/default.nix 
---
type: repository-file
source_path: "modules/desktop/gnome/default.nix"
source_kind: text
extension: "nix"
bytes: 1084
sha256: 006072433efd7990ad61f12794822f4d06edcad1294fd7cfe77f1927500e2e18
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/gnome/default.nix`
- **Source kind:** text
- **Size:** 1084 bytes, 46 lines
- **SHA-256:** `006072433efd7990ad61f12794822f4d06edcad1294fd7cfe77f1927500e2e18`

## Searchable Metadata
- **Keywords:** pkgs, false, with, gnomeExtensions.arcmenu, environment.systemPackages, gnomeExtensions.vitals, gnome-tweaks, geary, gnome-initial-setup, gnome-contacts, cheese, epiphany, gedit, gnomeExtensions.dash-to-panel, gnomeExtensions.gtile
- **Parent:** [[Files/modules/desktop/gnome|modules/desktop/gnome]]

### Detected Declarations / Headings
- `imports =`
- `services =`
- `#`
- `#`
- `#`
- `#`
- `#`
- `#`
- `#`
- `#`
- `#`
- `#`

### Detected References
- `imports = [`

## Source
```
nix
{ lib, pkgs, ... }:
{
  imports = [
    ./dconf.nix
    ../../themes/Catppuccin
  ];
  services = {
    desktopManager.gnome.enable = true;
    gnome.gnome-initial-setup.enable = false;
    gnome.games.enable = false;
    tlp.enable = lib.mkForce false; # gnome has builtin power management
  };

  environment.gnome.excludePackages = with pkgs; [
    #gnome-backgrounds
    #pkgs.gnome-video-effects
    gnome-maps
    gnome-music
    gnome-tour
    gnome-text-editor
    gnome-user-docs
    gnome-contacts
    gnome-initial-setup
    geary
    gedit
    epiphany
    cheese
  ];
  environment.systemPackages = with pkgs; [
    gnome-tweaks
    gnomeExtensions.vitals
    gnomeExtensions.arcmenu
    # gnomeExtensions.appindicator
    # gnomeExtensions.blur-my-shell
    # gnomeExtensions.burn-my-windows
    # gnomeExtensions.compact-top-bar
    # gnomeExtensions.custom-accent-colors
    # gradience
    # gnomeExtensions.gtile
    # gnomeExtensions.dash-to-panel
    # gnomeExtensions.tray-icons-reloaded
    # gnomeExtensions.paperwm
    # gnomeExtensions.just-perfection
  ];
}
```
