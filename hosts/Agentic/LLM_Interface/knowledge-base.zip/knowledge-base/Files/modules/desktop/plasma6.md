# modules/desktop/plasma6  This page represents the repository directory `modules/desktop/plasma6` and links to its indexed files.  ## Files
- [[modules/desktop/plasma6/default.nix.md|modules/desktop/plasma6/default.nix]]
