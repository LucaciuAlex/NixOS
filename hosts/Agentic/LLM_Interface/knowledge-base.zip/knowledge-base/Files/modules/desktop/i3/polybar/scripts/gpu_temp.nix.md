# modules/desktop/i3/polybar/scripts/gpu_temp.nix 
---
type: repository-file
source_path: "modules/desktop/i3/polybar/scripts/gpu_temp.nix"
source_kind: text
extension: "nix"
bytes: 614
sha256: 50e011fcd2de1b050e483957c673deca28ebc1745a9b03b79aa0c0deecec6da4
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/i3/polybar/scripts/gpu_temp.nix`
- **Source kind:** text
- **Size:** 614 bytes, 22 lines
- **SHA-256:** `50e011fcd2de1b050e483957c673deca28ebc1745a9b03b79aa0c0deecec6da4`

## Searchable Metadata
- **Keywords:** TEMP, then, echo, GPU, done, for, nvidia-smi, card, exit, found, hwmon, not, temperature, cat, command
- **Parent:** [[Files/modules/desktop/i3/polybar/scripts|modules/desktop/i3/polybar/scripts]]

### Detected Declarations / Headings
- `TEMP=`
- `TEMP=`
- `TEMP=`

## Source
```
nix
{ pkgs, ... }:
pkgs.writeShellScriptBin "gpu_temp" ''
  if command -v nvidia-smi &>/dev/null; then
    TEMP=$(nvidia-smi --query-gpu=temperature.gpu --format=csv,noheader,nounits)
    echo "GPU $TEMP°C"
  else
    for card in /sys/class/drm/card*; do
      if [ -e "$card/device/hwmon" ]; then
        for hwmon in "$card/device/hwmon/hwmon"*; do
          if [ -e "$hwmon/temp1_input" ]; then
            TEMP=$(cat "$hwmon/temp1_input")
            TEMP=$((TEMP / 1000))
            echo "GPU $TEMP°C"
            exit 0
          fi
        done
      fi
    done
    echo "GPU temperature not found"
  fi
''
```
