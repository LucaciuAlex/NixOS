# modules/desktop/gnome  This page represents the repository directory `modules/desktop/gnome` and links to its indexed files.  ## Files
- [[modules/desktop/gnome/dconf.nix.md|modules/desktop/gnome/dconf.nix]]
- [[modules/desktop/gnome/default.nix.md|modules/desktop/gnome/default.nix]]
