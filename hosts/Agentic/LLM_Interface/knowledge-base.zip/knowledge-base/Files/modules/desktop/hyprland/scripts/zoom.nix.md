# modules/desktop/hyprland/scripts/zoom.nix 
---
type: repository-file
source_path: "modules/desktop/hyprland/scripts/zoom.nix"
source_kind: text
extension: "nix"
bytes: 791
sha256: fb5d7263170c4aa6486c6d618087c1dd32e91aea9912aa0238ed9137a8ef29ca
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/scripts/zoom.nix`
- **Source kind:** text
- **Size:** 791 bytes, 34 lines
- **SHA-256:** `fb5d7263170c4aa6486c6d618087c1dd32e91aea9912aa0238ed9137a8ef29ca`

## Searchable Metadata
- **Keywords:** new_zoom, echo, pkgs.bc, zoom_step, min_zoom, current_zoom, max_zoom, then, reset, hyprctl, cursor, out, zoom_factor, exit, sleep
- **Parent:** [[Files/modules/desktop/hyprland/scripts|modules/desktop/hyprland/scripts]]

### Detected Declarations / Headings
- `current_zoom=`
- `zoom_step=`
- `min_zoom=`
- `max_zoom=`
- `new_zoom=`
- `new_zoom=`
- `new_zoom=`
- `new_zoom=`
- `new_zoom=`

## Source
```
nix
{ pkgs, ... }:
pkgs.writeShellScriptBin "zoom" ''
  current_zoom=$(hyprctl getoption cursor:zoom_factor -j | ${pkgs.jq}/bin/jq -r '.float')

  zoom_step=1.0
  min_zoom=1.0
  max_zoom=5.0

  case "$1" in
    "in")
      new_zoom=$(echo "$current_zoom + $zoom_step" | ${pkgs.bc}/bin/bc)
      if (( $(echo "$new_zoom > $max_zoom" | ${pkgs.bc}/bin/bc -l) )); then
        new_zoom=$max_zoom
      fi
      ;;
    "out")
      new_zoom=$(echo "$current_zoom - $zoom_step" | ${pkgs.bc}/bin/bc)
      if (( $(echo "$new_zoom < $min_zoom" | ${pkgs.bc}/bin/bc -l) )); then
        new_zoom=$min_zoom
      fi
      ;;
    "reset")
      new_zoom=1.0
      ;;
    *)
      echo "Usage: $0 {in|out|reset}"
      exit 1
      ;;
  esac

  hyprctl keyword cursor:zoom_factor "$new_zoom"
  sleep 0.05
''
```
