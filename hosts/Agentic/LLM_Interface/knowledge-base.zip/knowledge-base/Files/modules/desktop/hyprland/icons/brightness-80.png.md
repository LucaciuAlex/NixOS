# modules/desktop/hyprland/icons/brightness-80.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/icons/brightness-80.png"
source_kind: binary
extension: "png"
bytes: 32409
sha256: 04135476f02389d47243c23e023e79b3bd33c2644700f65181b94e9cd37aad64
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/icons/brightness-80.png`
- **Source kind:** binary
- **Size:** 32409 bytes
- **SHA-256:** `04135476f02389d47243c23e023e79b3bd33c2644700f65181b94e9cd37aad64`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/icons|modules/desktop/hyprland/icons]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
