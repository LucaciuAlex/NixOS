# modules/desktop/hyprland/programs/noctalia-shell/profile-picture.jpg 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/noctalia-shell/profile-picture.jpg"
source_kind: binary
extension: "jpg"
bytes: 580013
sha256: 6af1362365f1ac01279c00e39c532a390b81588b8e580b107bb62dbbd25446e9
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/jpg
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/noctalia-shell/profile-picture.jpg`
- **Source kind:** binary
- **Size:** 580013 bytes
- **SHA-256:** `6af1362365f1ac01279c00e39c532a390b81588b8e580b107bb62dbbd25446e9`

## Searchable Metadata
- **Keywords:** jpg
- **Parent:** [[Files/modules/desktop/hyprland/programs/noctalia-shell|modules/desktop/hyprland/programs/noctalia-shell]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.jpg`
