# modules/desktop/hyprland/programs/rofi/colors/catppuccin.rasi 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/colors/catppuccin.rasi"
source_kind: text
extension: "rasi"
bytes: 278
sha256: 11d01002ce3a9d4167a1e150582e463d23d10e979889c8f494da141101b7ad6c
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/rasi
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/colors/catppuccin.rasi`
- **Source kind:** text
- **Size:** 278 bytes, 17 lines
- **SHA-256:** `11d01002ce3a9d4167a1e150582e463d23d10e979889c8f494da141101b7ad6c`

## Searchable Metadata
- **Keywords:** adi1090x, selected, D9E0EEFF, foreground, active, urgent, ABE9B3FF, F28FADFF, Shakya, Aditya, Author, Github, background-alt, background, Colors
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/colors|modules/desktop/hyprland/programs/rofi/colors]]

## Source
```
css
/**
 *
 * Author : Aditya Shakya (adi1090x)
 * Github : @adi1090x
 * 
 * Colors
 **/

* {
    background:     #1E1D2FFF;
    background-alt: #282839FF;
    foreground:     #D9E0EEFF;
    selected:       #7AA2F7FF;
    active:         #ABE9B3FF;
    urgent:         #F28FADFF;
}
```
