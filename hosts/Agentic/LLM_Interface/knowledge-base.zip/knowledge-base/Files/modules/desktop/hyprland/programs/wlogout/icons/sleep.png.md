# modules/desktop/hyprland/programs/wlogout/icons/sleep.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/wlogout/icons/sleep.png"
source_kind: binary
extension: "png"
bytes: 5721
sha256: f1cc023c939c4190bf8b708a5578fc02f6d864a68626389c7de2e69e821a9bc7
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/wlogout/icons/sleep.png`
- **Source kind:** binary
- **Size:** 5721 bytes
- **SHA-256:** `f1cc023c939c4190bf8b708a5578fc02f6d864a68626389c7de2e69e821a9bc7`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/programs/wlogout/icons|modules/desktop/hyprland/programs/wlogout/icons]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
