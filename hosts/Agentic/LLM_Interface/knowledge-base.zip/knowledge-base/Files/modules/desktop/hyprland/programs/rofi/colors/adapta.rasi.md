# modules/desktop/hyprland/programs/rofi/colors/adapta.rasi 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/colors/adapta.rasi"
source_kind: text
extension: "rasi"
bytes: 278
sha256: 3e5be2fabfc3b41503845c8c6deb332848ebdfee841a3b63998da2331221b45c
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/rasi
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/colors/adapta.rasi`
- **Source kind:** text
- **Size:** 278 bytes, 17 lines
- **SHA-256:** `3e5be2fabfc3b41503845c8c6deb332848ebdfee841a3b63998da2331221b45c`

## Searchable Metadata
- **Keywords:** adi1090x, selected, B8C2C6FF, foreground, urgent, active, FF4B60FF, background-alt, Shakya, Aditya, Author, background, Colors, Github
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/colors|modules/desktop/hyprland/programs/rofi/colors]]

## Source
```
css
/**
 *
 * Author : Aditya Shakya (adi1090x)
 * Github : @adi1090x
 * 
 * Colors
 **/

* {
    background:     #222D32FF;
    background-alt: #29353BFF;
    foreground:     #B8C2C6FF;
    selected:       #00BCD4FF;
    active:         #21FF90FF;
    urgent:         #FF4B60FF;
}
```
