# modules/desktop/hyprland/lua  This page represents the repository directory `modules/desktop/hyprland/lua` and links to its indexed files.  ## Files
- [[modules/desktop/hyprland/lua/animations.lua.md|modules/desktop/hyprland/lua/animations.lua]]
- [[modules/desktop/hyprland/lua/binds.lua.md|modules/desktop/hyprland/lua/binds.lua]]
- [[modules/desktop/hyprland/lua/hyprland.lua.md|modules/desktop/hyprland/lua/hyprland.lua]]
- [[modules/desktop/hyprland/lua/monitors.lua.md|modules/desktop/hyprland/lua/monitors.lua]]
- [[modules/desktop/hyprland/lua/rules.lua.md|modules/desktop/hyprland/lua/rules.lua]]
- [[modules/desktop/hyprland/lua/settings.lua.md|modules/desktop/hyprland/lua/settings.lua]]
