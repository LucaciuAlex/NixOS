# modules/desktop/hyprland/icons/dropper.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/icons/dropper.png"
source_kind: binary
extension: "png"
bytes: 24962
sha256: 03611bbead8b62de1ef179cd37250507e6f04c3145f492855d60ee97d3082044
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/icons/dropper.png`
- **Source kind:** binary
- **Size:** 24962 bytes
- **SHA-256:** `03611bbead8b62de1ef179cd37250507e6f04c3145f492855d60ee97d3082044`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/icons|modules/desktop/hyprland/icons]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
