# modules/desktop/hyprland/scripts/brightnesscontrol.nix 
---
type: repository-file
source_path: "modules/desktop/hyprland/scripts/brightnesscontrol.nix"
source_kind: text
extension: "nix"
bytes: 1353
sha256: 8df15e429e56a57d2271551790e5a0d0b9a4f66ca9c5130ed5e026dac6129cd5
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/scripts/brightnesscontrol.nix`
- **Source kind:** text
- **Size:** 1353 bytes, 42 lines
- **SHA-256:** `8df15e429e56a57d2271551790e5a0d0b9a4f66ca9c5130ed5e026dac6129cd5`

## Searchable Metadata
- **Keywords:** pkgs.brightnessctl, brightness, send_notification, set, info, get_brightness, bar, pkgs.coreutils, ico, brightinfo, angle, pkgs.gnugrep, EOF, icodir, print_error
- **Parent:** [[Files/modules/desktop/hyprland/scripts|modules/desktop/hyprland/scripts]]

### Detected Declarations / Headings
- `icodir=`
- `brightness=`
- `brightinfo=`
- `angle=`
- `ico=`
- `bar=`

## Source
```
nix
{ pkgs, ... }:
pkgs.writeShellScriptBin "brightnesscontrol" ''
  icodir="$HOME/.config/hypr/icons/notifications/vol"

  print_error() {
    cat << "EOF"
    brightnesscontrol <action>
    ...valid actions are...
        i -- <i>ncrease brightness [+5%]
        d -- <d>ecrease brightness [-5%]
EOF
  }

  send_notification() {
    brightness=$(${pkgs.brightnessctl}/bin/brightnessctl info | ${pkgs.gnugrep}/bin/grep -oP "(?<=\()\d+(?=%)" | cat)
    brightinfo=$(${pkgs.brightnessctl}/bin/brightnessctl info | ${pkgs.gawk}/bin/awk -F "'" '/Device/ {print $2}')
    angle="$(((($brightness + 2) / 5) * 5))"
    ico="''${icodir}/vol-''${angle}.svg"
    bar=$(${pkgs.coreutils}/bin/seq -s "." $(($brightness / 15)) | ${pkgs.gnused}/bin/sed 's/[0-9]//g')
    ${pkgs.libnotify}/bin/notify-send -a "System" -r 91190 -t 800 -i "''${ico}" "''${brightness}''${bar}" "''${brightinfo}"
  }

  get_brightness() {
    ${pkgs.brightnessctl}/bin/brightnessctl -m | ${pkgs.gnugrep}/bin/grep -o '[0-9]\+%' | ${pkgs.coreutils}/bin/head -c-2
  }

  case $1 in
  i)
    ${pkgs.brightnessctl}/bin/brightnessctl set +5%
    send_notification ;;
  d)
    if [[ $(get_brightness) -lt 5 ]] ; then
      ${pkgs.brightnessctl}/bin/brightnessctl set 1%
    else
      ${pkgs.brightnessctl}/bin/brightnessctl set 5%-
    fi
    send_notification ;;
  *)
    print_error ;;
  esac
''
```
