# modules/desktop/hyprland/default.nix 
---
type: repository-file
source_path: "modules/desktop/hyprland/default.nix"
source_kind: text
extension: "nix"
bytes: 2513
sha256: 7ac4516ca0972d8c9b4da68de398beae83941b6c9f78e5bccaf1414355660a20
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/default.nix`
- **Source kind:** text
- **Size:** 2513 bytes, 100 lines
- **SHA-256:** `7ac4516ca0972d8c9b4da68de398beae83941b6c9f78e5bccaf1414355660a20`

## Searchable Metadata
- **Keywords:** true, GTK, bar, graphical-session.target, hyprland, pkgs, host, inputs.hyprland.packages., pkgs.stdenv.hostPlatform.system, enable, with, lib, config, inherit, optional
- **Parent:** [[Files/modules/desktop/hyprland|modules/desktop/hyprland]]

### Detected Declarations / Headings
- `imports =`
- `description =`
- `wantedBy =`
- `wants =`
- `after =`
- `serviceConfig =`
- `Type =`
- `ExecStart =`
- `Restart =`
- `RestartSec =`
- `TimeoutStopSec =`
- `enable =`

### Detected References
- `import ../../../hosts/${host}/variables.nix) bar;`
- `imports = [`
- `source = ./lua/hyprland.lua;`
- `source = ./lua/monitors.lua;`
- `source = ./lua/settings.lua;`
- `source = ./lua/animations.lua;`
- `source = ./lua/binds.lua;`
- `source = ./lua/rules.lua;`
- `source = ./icons;`

## Source
```
nix
{
  host,
  inputs,
  config,
  lib,
  pkgs,
  ...
}:
let
  inherit (lib) optional;
  inherit (import ../../../hosts/${host}/variables.nix) bar;
in
{
  imports = [
    ../../themes/Catppuccin # Catppuccin GTK and QT themes
    ./variables.nix
    ./programs/${bar}
    ./programs/wlogout
    ./programs/rofi
    ./programs/hypridle
    ./programs/hyprlock
  ]
  ++ optional (bar != "hyprpanel" && bar != "wayle") ./programs/swaync;

  environment.systemPackages = with pkgs; [
    pavucontrol
    swappy
    cliphist
    wl-clipboard
    brightnessctl
    playerctl
    pamixer
    hyprsunset
    btop
    hyprpicker
  ];

  systemd.user.services.hyprpolkitagent = {
    description = "Hyprpolkitagent - Polkit authentication agent";
    wantedBy = [ "graphical-session.target" ];
    wants = [ "graphical-session.target" ];
    after = [ "graphical-session.target" ];
    serviceConfig = {
      Type = "simple";
      ExecStart = "${pkgs.hyprpolkitagent}/libexec/hyprpolkitagent";
      Restart = "on-failure";
      RestartSec = 1;
      TimeoutStopSec = 10;
    };
  };
  services.displayManager.defaultSession = "hyprland";

  programs.hyprland = {
    enable = true;
    package = inputs.hyprland.packages.${pkgs.stdenv.hostPlatform.system}.hyprland;
    portalPackage = inputs.hyprland.packages.${pkgs.stdenv.hostPlatform.system}.xdg-desktop-portal-hyprland;
    # withUWSM = true;
  };

  home-manager.sharedModules = [
    (_: {
      xdg.portal = {
        enable = true;
        extraPortals = with pkgs; [
          xdg-desktop-portal-gtk
        ];
        xdgOpenUsePortal = true;
        configPackages = [ config.programs.hyprland.package ];
        config.hyprland = {
          default = [
            "hyprland"
            "gtk"
          ];
          "org.freedesktop.impl.portal.OpenURI" = "gtk";
          "org.freedesktop.impl.portal.FileChooser" = "gtk";
          "org.freedesktop.impl.portal.Print" = "gtk";
        };
      };

      # Set wallpaper
      services.awww.enable = true;

      # Hyprland config
      xdg.configFile = {
        "hypr/hyprland.lua".source = ./lua/hyprland.lua;
        "hypr/monitors.lua".source = ./lua/monitors.lua;
        "hypr/settings.lua".source = ./lua/settings.lua;
        "hypr/animations.lua".source = ./lua/animations.lua;
        "hypr/binds.lua".source = ./lua/binds.lua;
        "hypr/rules.lua".source = ./lua/rules.lua;

        "hypr/icons" = {
          source = ./icons;
          recursive = true;
        };
      };
    })
  ];
}
```
