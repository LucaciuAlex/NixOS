# modules/desktop/hyprland/programs/rofi/assets/steamdeck_holographic.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/assets/steamdeck_holographic.png"
source_kind: binary
extension: "png"
bytes: 67530
sha256: 9a4b1d5fe6911ca4369099aaa55725ec9cf4dc9eeec9843c1a396ba86b31d6a8
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/assets/steamdeck_holographic.png`
- **Source kind:** binary
- **Size:** 67530 bytes
- **SHA-256:** `9a4b1d5fe6911ca4369099aaa55725ec9cf4dc9eeec9843c1a396ba86b31d6a8`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/assets|modules/desktop/hyprland/programs/rofi/assets]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
