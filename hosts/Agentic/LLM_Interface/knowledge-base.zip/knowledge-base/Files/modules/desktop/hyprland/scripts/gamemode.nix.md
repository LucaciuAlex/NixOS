# modules/desktop/hyprland/scripts/gamemode.nix 
---
type: repository-file
source_path: "modules/desktop/hyprland/scripts/gamemode.nix"
source_kind: text
extension: "nix"
bytes: 1087
sha256: 5ca6f9f2ab7e923732e2e04f8f1dcd710c25f477f056bb3ad969749604d94a5e
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/scripts/gamemode.nix`
- **Source kind:** text
- **Size:** 1087 bytes, 29 lines
- **SHA-256:** `5ca6f9f2ab7e923732e2e04f8f1dcd710c25f477f056bb3ad969749604d94a5e`

## Searchable Metadata
- **Keywords:** keyword, decoration, hyprctl, noanim, layerrule, enabled, general, blur, HYPRGAMEMODE, animations, fullscreen_opacity, inactive_opacity, waybar, swaync-notification-window, awww-daemon
- **Parent:** [[Files/modules/desktop/hyprland/scripts|modules/desktop/hyprland/scripts]]

### Detected Declarations / Headings
- `HYPRGAMEMODE=`

## Source
```
nix
{ pkgs, ... }:
pkgs.writeShellScriptBin "gamemode" ''
  HYPRGAMEMODE=$(hyprctl getoption animations:enabled | ${pkgs.gnused}/bin/sed -n '1p' | ${pkgs.gawk}/bin/awk '{print $2}')

  if [ "$HYPRGAMEMODE" = 1 ]; then
    hyprctl -q --batch "\
          keyword animations:enabled 0;\
          keyword decoration:shadow:enabled 0;\
          keyword decoration:drop_shadow 0;\
          keyword decoration:blur:enabled 0;\
          keyword decoration:blur:xray 1;\
          keyword general:gaps_in 0;\
          keyword general:gaps_out 0;\
          keyword general:border_size 1;\
          keyword decoration:rounding 0;\
          keyword decoration:active_opacity 1 ;\
          keyword decoration:inactive_opacity 1 ;\
          keyword decoration:fullscreen_opacity 1 ;\
          keyword layerrule noanim,waybar ;\
          keyword layerrule noanim,swaync-notification-window ;\
          keyword layerrule noanim,awww-daemon ;\
          keyword layerrule noanim,rofi"
    hyprctl 'keyword windowrule opaque,class:(.*)'
    exit
  else
    hyprctl reload config-only -q
  fi
''
```
