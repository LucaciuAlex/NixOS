# modules/desktop/hyprland/variables.nix 
---
type: repository-file
source_path: "modules/desktop/hyprland/variables.nix"
source_kind: text
extension: "nix"
bytes: 2606
sha256: 8a5cb72be453d4d9201702ce40b5c634dd79c4b1f0eb6b82994ed62d4687aa5c
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/variables.nix`
- **Source kind:** text
- **Size:** 2606 bytes, 75 lines
- **SHA-256:** `8a5cb72be453d4d9201702ce40b5c634dd79c4b1f0eb6b82994ed62d4687aa5c`

## Searchable Metadata
- **Keywords:** pkgs.callPackage, getExe, inherit, bar, terminal, capslockAsESC, launcher, rofimusic, fileManagerScript, gamemode, clipmanager, autoclicker, batterynotify, wallpaper, screenshot
- **Parent:** [[Files/modules/desktop/hyprland|modules/desktop/hyprland]]

### Detected Declarations / Headings
- `#`
- `#`
- `autoclicker =`
- `batterynotify =`
- `clipmanager =`
- `fileManagerScript =`
- `gamemode =`
- `keyboardswitch =`
- `keybinds-yad =`
- `#`
- `#`
- `launcher =`

### Detected References
- `import ../../../hosts/${host}/variables.nix)`

## Source
```
nix
{
  host,
  lib,
  pkgs,
  ...
}:
let
  inherit (lib) getExe;
  inherit (import ../../../hosts/${host}/variables.nix)
    bar
    browser
    terminal
    fileManager
    kbdLayout
    kbdVariant
    capslockAsESC
    defaultWallpaper
    ;

  # Import script modules
  # autowaybar = pkgs.callPackage ./scripts/autowaybar.nix { };
  autoclicker = pkgs.callPackage ./scripts/autoclicker.nix { };
  batterynotify = pkgs.callPackage ./scripts/batterynotify.nix { };
  clipmanager = pkgs.callPackage ./scripts/clipmanager.nix { };
  fileManagerScript = pkgs.callPackage ./scripts/file-manager.nix { inherit terminal; };
  gamemode = pkgs.callPackage ./scripts/gamemode.nix { };
  keyboardswitch = pkgs.callPackage ./scripts/keyboardswitch.nix { };
  keybinds-yad = pkgs.callPackage ./scripts/keybinds-yad.nix { };
  # keybinds-rofi = pkgs.callPackage ./scripts/keybinds-yad.nix { };
  # mediactrl = pkgs.callPackage ./scripts/mediactrl.nix { };
  launcher = pkgs.callPackage ../../scripts/launcher.nix { inherit lib pkgs terminal; };
  rofimusic = pkgs.callPackage ./scripts/rofimusic.nix { };
  screen-record = pkgs.callPackage ./scripts/screen-record.nix { };
  screenshot = pkgs.callPackage ./scripts/screenshot.nix { };
  wallpaper = pkgs.callPackage ./scripts/wallpaper.nix { inherit defaultWallpaper; };
  zoom = pkgs.callPackage ./scripts/zoom.nix { };
in
{
  home-manager.sharedModules = [
    (
      { config, ... }:
      {
        xdg.configFile."hypr/variables.lua" = {
          text = ''
            -- Scripts
            autoclicker = "${getExe autoclicker}"
            batterynotify = "${getExe batterynotify}"
            clipmanager = "${getExe clipmanager}"
            fileManagerScript = "${getExe fileManagerScript}"
            gamemode = "${getExe gamemode}"
            keyboardswitch = "${getExe keyboardswitch}"
            keybinds_yad = "${getExe keybinds-yad}"
            rofimusic = "${getExe rofimusic}"
            screen_record = "${getExe screen-record}"
            screenshot = "${getExe screenshot}"
            wallpaper = "${getExe wallpaper}"
            zoom = "${getExe zoom}"

            mainMod = "SUPER"
            launcher = "${getExe launcher}"
            bar = "${if bar == "wayle" then "wayle shell" else bar}"
            term = "${terminal}"
            editor = "code --disable-gpu"
            browser = "${browser}"
            fileManager = "${fileManager}"
            capslockAsESC = ${lib.boolToString capslockAsESC}
            kbdLayout = "${kbdLayout}"
            kbdVariant = "${kbdVariant}"
          '';
        };
      }
    )
  ];
}
```
