# modules/desktop/hyprland/programs/rofi/launchers/type-2/style-10.rasi 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/launchers/type-2/style-10.rasi"
source_kind: text
extension: "rasi"
bytes: 6331
sha256: 1a40d2d5f2061296d734c64008af9d55748189c669e3e0a2ab85909aeeb97423
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/rasi
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/launchers/type-2/style-10.rasi`
- **Source kind:** text
- **Size:** 6331 bytes, 205 lines
- **SHA-256:** `1a40d2d5f2061296d734c64008af9d55748189c669e3e0a2ab85909aeeb97423`

## Searchable Metadata
- **Keywords:** background-color, true, inherit, text-color, selected, enabled, border, foreground, border-radius, border-color, background, cursor, solid, padding, margin
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/launchers/type-2|modules/desktop/hyprland/programs/rofi/launchers/type-2]]

## Source
```
css
/**
 *
 * Author : Aditya Shakya (adi1090x)
 * Github : @adi1090x
 * 
 * Rofi Theme File
 * Rofi Version: 1.7.3
 **/

/*****----- Configuration -----*****/
configuration {
	modi:                       "drun";
    show-icons:                 true;
    display-drun:               "";
	drun-display-format:        "{name}";
}

/*****----- Global Properties -----*****/
* {
    background:     #1E2127FF;
    background-alt: #282B31FF;
    foreground:     #FFFFFFFF;
    selected:       #61AFEFFF;
    active:         #98C379FF;
    urgent:         #E06C75FF;
}

* {
    font: "Iosevka Nerd Font 10";
}

* {
    /* For Screens with 1920x1080 resolution */
    screen-margin:               180px 150px;
    box-spacing:                 40px;
    icon-size:                   96px;
    element-padding:             30px;
    element-spacing:             15px;

    /* For Screens with 1366x768 resolution */
    /*
    screen-margin:               120px 60px;
    box-spacing:                 40px;
    icon-size:                   64px;
    element-padding:             20px;
    element-spacing:             10px;
    */
    /* Use this as reference and create for your screen resolution */
}

/*****----- Main Window -----*****/
window {
    transparency:                "real";
    location:                    center;
    anchor:                      center;
    fullscreen:                  true;
    width:                       1366px;
    height:                      768px;
    x-offset:                    0px;
    y-offset:                    0px;

    enabled:                     true;
    margin:                      0px;
    padding:                     0px;
    border:                      0px solid;
    border-radius:               0px;
    border-color:                @selected;
    background-color:            @background;
    cursor:                      "default";
}

/*****----- Main Box -----*****/
mainbox {
    enabled:                     true;
    spacing:                     @box-spacing;
    margin:                      @screen-margin;
    padding:                     0px;
    border:                      0px solid;
    border-radius:               0px 0px 0px 0px;
    border-color:                @selected;
    background-color:            transparent;
    children:                    [ "inputbar", "listview" ];
}

/*****----- Inputbar -----*****/
inputbar {
    enabled:                     true;
    spacing:                     10px;
    margin:                      0px 50% 0px 0px;
    padding:                     15px;
    border:                      0px solid;
    border-radius:               100%;
    border-color:                @selected;
    background-color:            @selected;
    text-color:                  @background;
    children:                    [ "prompt", "entry" ];
}

prompt {
    enabled:                     true;
    background-color:            inherit;
    text-color:                  inherit;
}
textbox-prompt-colon {
    enabled:                     true;
    expand:                      false;
    str:                         "::";
    background-color:            inherit;
    text-color:                  inherit;
}
entry {
    enabled:                     true;
    background-color:            inherit;
    text-color:                  inherit;
    cursor:                      text;
    placeholder:                 "Search...";
    placeholder-color:           inherit;
}

/*****----- Listview -----*****/
listview {
    enabled:                     true;
    columns:                     8;
    lines:                       3;
    cycle:                       true;
    dynamic:                     true;
    scrollbar:                   false;
    layout:                      vertical;
    reverse:                     false;
    fixed-height:                true;
    fixed-columns:               true;
    
    spacing:                     @element-spacing;
    margin:                      0px;
    padding:                     0px;
    border:                      0px solid;
    border-radius:               0px;
    border-color:                @selected;
    background-color:            transparent;
    text-color:                  @foreground;
    cursor:                      "default";
}
scrollbar {
    handle-width:                5px ;
    handle-color:                @selected;
    border-radius:               0px;
    background-color:            @background-alt;
}

/*****----- Elements -----*****/
element {
    enabled:                     true;
    spacing:                     @element-spacing;
    margin:                      0px;
    padding:                     @element-padding;
    border:                      0px solid;
    border-radius:               30px;
    border-color:                @selected;
    background-color:            transparent;
    text-color:                  @foreground;
    orientation:                 vertical;
    cursor:                      pointer;
}
element normal.normal {
    background-color:            @background;
    text-color:                  @foreground;
}
element selected.normal {
    border:                      0px 0px 4px 0px;
    border-color:                @selected;
    background-color:            @background-alt;
    text-color:                  @foreground;
}
element-icon {
    background-color:            transparent;
    text-color:                  inherit;
    size:                        @icon-size;
    cursor:                      inherit;
}
element-text {
    background-color:            transparent;
    text-color:                  inherit;
    highlight:                   inherit;
    cursor:                      inherit;
    vertical-align:              0.5;
    horizontal-align:            0.5;
}

/*****----- Message -----*****/
error-message {
    padding:                     150px;
    border:                      0px solid;
    border-radius:               0px;
    border-color:                @selected;
    background-color:            @background;
    text-color:                  @foreground;
}
textbox {
    background-color:            @background;
    text-color:                  @foreground;
    vertical-align:              0.5;
    horizontal-align:            0.0;
    highlight:                   none;
}
```
