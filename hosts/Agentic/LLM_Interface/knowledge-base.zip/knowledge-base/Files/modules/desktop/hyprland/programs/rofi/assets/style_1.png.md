# modules/desktop/hyprland/programs/rofi/assets/style_1.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/assets/style_1.png"
source_kind: binary
extension: "png"
bytes: 17830
sha256: 2c536d7dbfd04ee86c57c1b51951b4b0e6b72dee8085dd4d75892a38ede11257
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/assets/style_1.png`
- **Source kind:** binary
- **Size:** 17830 bytes
- **SHA-256:** `2c536d7dbfd04ee86c57c1b51951b4b0e6b72dee8085dd4d75892a38ede11257`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/assets|modules/desktop/hyprland/programs/rofi/assets]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
