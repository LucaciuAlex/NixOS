# modules/desktop/hyprland/icons/battery-quarter-solid.svg 
---
type: repository-file
source_path: "modules/desktop/hyprland/icons/battery-quarter-solid.svg"
source_kind: text
extension: "svg"
bytes: 523
sha256: 6f9d019e8d6bcd43731df2f0f06d28c81f4b2de36c45290b1a92ae3dcab58f26
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/svg
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/icons/battery-quarter-solid.svg`
- **Source kind:** text
- **Size:** 523 bytes, 1 lines
- **SHA-256:** `6f9d019e8d6bcd43731df2f0f06d28c81f4b2de36c45290b1a92ae3dcab58f26`

## Searchable Metadata
- **Keywords:** License, https, Commercial, path, Inc., Fonticons, Copyright, fontawesome, http, xmlns, svg, viewBox, Pro, Awesome, Font
- **Parent:** [[Files/modules/desktop/hyprland/icons|modules/desktop/hyprland/icons]]

## Source
```
xml
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><!--! Font Awesome Pro 6.2.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M0 176c0-44.2 35.8-80 80-80H464c44.2 0 80 35.8 80 80v16c17.7 0 32 14.3 32 32v64c0 17.7-14.3 32-32 32v16c0 44.2-35.8 80-80 80H80c-44.2 0-80-35.8-80-80V176zm80-16c-8.8 0-16 7.2-16 16V336c0 8.8 7.2 16 16 16H464c8.8 0 16-7.2 16-16V176c0-8.8-7.2-16-16-16H80zm112 32V320H96V192h96z"/></svg>
```
