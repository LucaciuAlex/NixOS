# modules/desktop/hyprland/scripts/autowaybar.nix 
---
type: repository-file
source_path: "modules/desktop/hyprland/scripts/autowaybar.nix"
source_kind: text
extension: "nix"
bytes: 965
sha256: 9747c1d5fd8bd35130d8f10ea66fd43c8339ab9c1e9b2a413d88f61bc859306d
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/scripts/autowaybar.nix`
- **Source kind:** text
- **Size:** 965 bytes, 39 lines
- **SHA-256:** `9747c1d5fd8bd35130d8f10ea66fd43c8339ab9c1e9b2a413d88f61bc859306d`

## Searchable Metadata
- **Keywords:** pkgs.jq, toggle_waybar, clients, event, pkgs.procps, waybar, hide_waybar, then, show_waybar, check_workspace_empty, hyprctl, active_workspace, activewindow, while, UNIX-CONNECT
- **Parent:** [[Files/modules/desktop/hyprland/scripts|modules/desktop/hyprland/scripts]]

### Detected Declarations / Headings
- `UID_VAL=`
- `active_workspace=`
- `clients=`

## Source
```
nix
{ pkgs, ... }:
pkgs.writeShellScriptBin "autowaybar" ''
  UID_VAL=$(${pkgs.coreutils}/bin/id -u)

  check_workspace_empty() {
    active_workspace=$(hyprctl activeworkspace -j | ${pkgs.jq}/bin/jq '.id')
    clients=$(hyprctl clients -j | ${pkgs.jq}/bin/jq "[.[] | select(.workspace.id == $active_workspace)]")
    [ "$(echo "$clients" | ${pkgs.jq}/bin/jq 'length')" -eq 0 ]
  }

  show_waybar() {
    if ! ${pkgs.procps}/bin/pgrep "waybar" > /dev/null; then
      ${pkgs.waybar}/bin/waybar &
    fi
  }

  hide_waybar() {
    ${pkgs.procps}/bin/pkill waybar
  }

  toggle_waybar() {
    if check_workspace_empty; then
      hide_waybar
    else
      show_waybar
    fi
  }

  toggle_waybar

  ${pkgs.socat}/bin/socat -U - UNIX-CONNECT:/run/user/$UID_VAL/hypr/$HYPRLAND_INSTANCE_SIGNATURE/.socket2.sock | while read -r event; do
    case "$event" in
      workspace* | openwindow* | closewindow* | activewindow*)
        toggle_waybar
        ;;
    esac
  done
''
```
