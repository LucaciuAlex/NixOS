# modules/desktop/hyprland/programs/noctalia-shell  This page represents the repository directory `modules/desktop/hyprland/programs/noctalia-shell` and links to its indexed files.  ## Files
- [[modules/desktop/hyprland/programs/noctalia-shell/default.nix.md|modules/desktop/hyprland/programs/noctalia-shell/default.nix]]
- [[modules/desktop/hyprland/programs/noctalia-shell/profile-picture.jpg.md|modules/desktop/hyprland/programs/noctalia-shell/profile-picture.jpg]]
