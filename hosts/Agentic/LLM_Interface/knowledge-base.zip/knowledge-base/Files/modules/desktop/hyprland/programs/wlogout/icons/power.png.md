# modules/desktop/hyprland/programs/wlogout/icons/power.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/wlogout/icons/power.png"
source_kind: binary
extension: "png"
bytes: 10782
sha256: c3fbcbcfb2ba6cce57e02dc28b997d5aaa0110ec7ec4a945c119adaa2dd3c0ee
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/wlogout/icons/power.png`
- **Source kind:** binary
- **Size:** 10782 bytes
- **SHA-256:** `c3fbcbcfb2ba6cce57e02dc28b997d5aaa0110ec7ec4a945c119adaa2dd3c0ee`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/programs/wlogout/icons|modules/desktop/hyprland/programs/wlogout/icons]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
