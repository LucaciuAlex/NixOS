# modules/desktop/hyprland/programs/rofi/colors/gruvbox.rasi 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/colors/gruvbox.rasi"
source_kind: text
extension: "rasi"
bytes: 278
sha256: 1fb29ff0bed1624a5ba2ff58438b2fc63b363ac86796991627a21a82e8bdbc9f
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/rasi
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/colors/gruvbox.rasi`
- **Source kind:** text
- **Size:** 278 bytes, 17 lines
- **SHA-256:** `1fb29ff0bed1624a5ba2ff58438b2fc63b363ac86796991627a21a82e8bdbc9f`

## Searchable Metadata
- **Keywords:** adi1090x, selected, EBDBB2FF, foreground, active, urgent, B8BB26FF, FB4934FF, Shakya, Aditya, Author, Github, background-alt, background, Colors
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/colors|modules/desktop/hyprland/programs/rofi/colors]]

## Source
```
css
/**
 *
 * Author : Aditya Shakya (adi1090x)
 * Github : @adi1090x
 * 
 * Colors
 **/

* {
    background:     #282828FF;
    background-alt: #353535FF;
    foreground:     #EBDBB2FF;
    selected:       #83A598FF;
    active:         #B8BB26FF;
    urgent:         #FB4934FF;
}
```
