# modules/desktop/hyprland/icons/notifications/vol/vol-85.svg 
---
type: repository-file
source_path: "modules/desktop/hyprland/icons/notifications/vol/vol-85.svg"
source_kind: text
extension: "svg"
bytes: 3375
sha256: ce03f33db19dcafe0a626499e77340c08ddfcb2569b09c7fecbbdad733dac894
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/svg
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/icons/notifications/vol/vol-85.svg`
- **Source kind:** text
- **Size:** 3375 bytes, 86 lines
- **SHA-256:** `ce03f33db19dcafe0a626499e77340c08ddfcb2569b09c7fecbbdad733dac894`

## Searchable Metadata
- **Keywords:** inkscape, label, sodipodi, display, fill, true, style, stroke-width, insensitive, fill-opacity, inline, http, xmlns, SVG, path
- **Parent:** [[Files/modules/desktop/hyprland/icons/notifications/vol|modules/desktop/hyprland/icons/notifications/vol]]

### Detected Declarations / Headings
- `height=`
- `width=`
- `version=`
- `id=`
- `viewBox=`
- `xmlns=`
- `id=`
- `id=`
- `pagecolor=`
- `bordercolor=`
- `borderopacity=`
- `showgrid=`

### Detected References
- `sourceforge.net/DTD/sodipodi-0.dtd"`

## Source
```
xml
<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<!-- Uploaded to: SVG Repo, www.svgrepo.com, Generator: SVG Repo Mixer Tools -->

<svg
   height="120px"
   width="120px"
   version="1.1"
   id="Layer_1"
   viewBox="0 0 496.8 496.8"
   xml:space="preserve"
   sodipodi:docname="vol-85.svg"
   inkscape:version="1.2.2 (b0a8486541, 2022-12-01)"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:svg="http://www.w3.org/2000/svg"><defs
   id="defs23" /><sodipodi:namedview
   id="namedview21"
   pagecolor="#ffffff"
   bordercolor="#000000"
   borderopacity="0.25"
   inkscape:showpageshadow="2"
   inkscape:pageopacity="0.0"
   inkscape:pagecheckerboard="0"
   inkscape:deskcolor="#d1d1d1"
   showgrid="true"
   inkscape:zoom="22.966828"
   inkscape:cx="88.192414"
   inkscape:cy="43.911157"
   inkscape:window-width="2524"
   inkscape:window-height="1011"
   inkscape:window-x="0"
   inkscape:window-y="0"
   inkscape:window-maximized="1"
   inkscape:current-layer="Layer_1"><inkscape:grid
     type="xygrid"
     id="grid3192" /></sodipodi:namedview>






<g
   id="g3158"
   inkscape:label="base"
   sodipodi:insensitive="true"><path
     style="display:inline;fill:#121c1b;fill-opacity:1;stroke-width:1.584"
     d="m 248.87519,445.92001 c 116.5824,0 212.8896,-91.2384 220.4928,-205.2864 0,5.0688 1.2672,8.8704 1.2672,13.9392 0,121.6512 -98.8416,221.76 -221.76,221.76 -121.6512,0 -221.759991,-98.8416 -221.759991,-221.76 0,-5.0688 0,-8.8704 1.2672,-13.9392 7.6032,114.048 103.910391,205.2864 220.492791,205.2864 z"
     id="path8"
     inkscape:label="shadow"
     sodipodi:insensitive="true" /><circle
     style="display:inline;fill:#283538;fill-opacity:1;stroke-width:1.584"
     cx="248.8752"
     cy="243.07127"
     r="221.76001"
     id="circle12"
     inkscape:label="dial"
     sodipodi:insensitive="true" /><path
     style="display:inline;fill:#000000;fill-opacity:0.153846;stroke-width:1.58653"
     d="m 405.74362,86.606184 c 86.3078,86.307816 86.3078,227.192636 0,313.500456 -86.30783,86.3078 -227.19264,86.3078 -313.500453,0"
     id="path14"
     inkscape:label="highlight"
     sodipodi:insensitive="true" /></g>

<g
   id="g3198"
   inkscape:label="main"><circle
     style="display:none;fill:#000000;fill-opacity:0;stroke-width:1.584"
     cx="329.83514"
     cy="-110.80194"
     r="221.76001"
     id="circle12-3"
     inkscape:label="anchor"
     sodipodi:insensitive="true"
     transform="rotate(63)" /><path
     style="display:inline;fill:#121c1b;fill-opacity:1;stroke-width:1.584"
     d="m 356.38984,209.74363 c -6.77449,3.45178 -13.592,1.23661 -17.04377,-5.5379 v 0 c -3.45181,-6.77449 -1.23668,-13.59203 5.53784,-17.04379 l 45.16334,-23.01189 c 6.77452,-3.45176 13.59204,-1.23661 17.0438,5.53789 v 0 c 3.45179,6.77448 1.23664,13.59202 -5.53787,17.0438 z"
     id="path3789"
     inkscape:label="shadow" /><path
     style="display:inline;fill:#ea398a;stroke-width:1.584"
     d="m 356.47823,203.22787 c -6.7745,3.45177 -13.59201,1.2366 -17.0438,-5.53789 v 0 c -3.45178,-6.77447 -1.23663,-13.592 5.53787,-17.0438 l 45.16335,-23.01186 c 6.7745,-3.4518 13.59201,-1.23664 17.0438,5.53786 v 0 c 3.45179,6.77452 1.23663,13.59203 -5.53787,17.0438 z"
     id="path915"
     inkscape:label="pointer" /></g>
</svg>
```
