# modules/desktop/hyprland/icons/picture.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/icons/picture.png"
source_kind: binary
extension: "png"
bytes: 30151
sha256: ab16422c30f6d1944316519a14387fa0af64ebccdbfe36c86f6167e1aa39bf44
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/icons/picture.png`
- **Source kind:** binary
- **Size:** 30151 bytes
- **SHA-256:** `ab16422c30f6d1944316519a14387fa0af64ebccdbfe36c86f6167e1aa39bf44`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/icons|modules/desktop/hyprland/icons]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
