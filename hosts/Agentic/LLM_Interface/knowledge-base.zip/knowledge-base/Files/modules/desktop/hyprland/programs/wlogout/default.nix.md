# modules/desktop/hyprland/programs/wlogout/default.nix 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/wlogout/default.nix"
source_kind: text
extension: "nix"
bytes: 2982
sha256: 87d82522654b21976b9a58529677aa09fee7fb310f721d54474a89e10c8cd523
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/wlogout/default.nix`
- **Source kind:** text
- **Size:** 2982 bytes, 112 lines
- **SHA-256:** `87d82522654b21976b9a58529677aa09fee7fb310f721d54474a89e10c8cd523`

## Searchable Metadata
- **Keywords:** image, background-image, url, text, action, keybind, label, focus, background-color, suspend, reboot, systemctl, shutdown, lock, rgba
- **Parent:** [[Files/modules/desktop/hyprland/programs/wlogout|modules/desktop/hyprland/programs/wlogout]]

### Detected Declarations / Headings
- `enable =`
- `layout =`
- `#`
- `#`
- `#`
- `#`
- `#`
- `#`
- `#`
- `#`
- `#`
- `#`

### Detected References
- `source = ./icons;`
- `url("icons/lock.png"));`
- `url("icons/lock-hover.png"));`
- `url("icons/logout.png"));`
- `url("icons/logout-hover.png"));`
- `url("icons/sleep.png"));`
- `url("icons/sleep-hover.png"));`
- `url("icons/power.png"));`
- `url("icons/power-hover.png"));`
- `url("icons/restart.png"));`
- `url("icons/restart-hover.png"));`

## Source
```
nix
{ ... }:
{
  home-manager.sharedModules = [
    (_: {
      xdg.configFile."wlogout/icons".source = ./icons;
      programs.wlogout = {
        enable = true;
        layout = [
          # {
          #   label = "lock";
          #   action = "${pkgs.hyprlock}/bin/hyprlock";
          #   text = "Lock";
          #   keybind = "l";
          # }
          # {
          #   label = "hibernate";
          #   action = "systemctl hibernate";
          #   text = "Hibernate";
          #   keybind = "h";
          # }
          {
            label = "logout";
            action = "hyprctl dispatch exit 0";
            # action = "killall -9 Hyprland sleep 2";
            text = "Exit";
            keybind = "e";
          }
          {
            label = "shutdown";
            action = "systemctl poweroff";
            text = "Shutdown";
            keybind = "s";
          }
          {
            label = "suspend";
            action = "systemctl suspend";
            text = "Suspend";
            keybind = "u";
          }
          {
            label = "reboot";
            action = "systemctl reboot";
            text = "Reboot";
            keybind = "r";
          }
        ];
        style = ''
          window {
            font-family: monospace;
            font-size: 14pt;
            color: #cdd6f4; /* text */
            background-color: rgba(30, 30, 46, 0.5);
          }

          button {
            background-repeat: no-repeat;
            background-position: center;
            background-size: 25%;
            border: none;
            background-color: rgba(30, 30, 46, 0);
            margin: 5px;
            transition: box-shadow 0.2s ease-in-out, background-color 0.2s ease-in-out;
          }

          button:hover {
            background-color: rgba(49, 50, 68, 0.1);
          }

          button:focus {
            background-color: #cba6f7;
            color: #1e1e2e;
          }
          #lock {
            background-image: image(url("icons/lock.png"));
          }
          #lock:focus {
            background-image: image(url("icons/lock-hover.png"));
          }

          #logout {
            background-image: image(url("icons/logout.png"));
          }
          #logout:focus {
            background-image: image(url("icons/logout-hover.png"));
          }

          #suspend {
            background-image: image(url("icons/sleep.png"));
          }
          #suspend:focus {
            background-image: image(url("icons/sleep-hover.png"));
          }

          #shutdown {
            background-image: image(url("icons/power.png"));
          }
          #shutdown:focus {
            background-image: image(url("icons/power-hover.png"));
          }

          #reboot {
            background-image: image(url("icons/restart.png"));
          }
          #reboot:focus {
            background-image: image(url("icons/restart-hover.png"));
          }
        '';
      };
    })
  ];
}
```
