# modules/desktop/hyprland/programs/rofi/colors/onedark.rasi 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/colors/onedark.rasi"
source_kind: text
extension: "rasi"
bytes: 278
sha256: 3d029680cc46676c7c8bc5189471284ca4c683539da6ff7d4836fd6e189fa26b
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/rasi
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/colors/onedark.rasi`
- **Source kind:** text
- **Size:** 278 bytes, 17 lines
- **SHA-256:** `3d029680cc46676c7c8bc5189471284ca4c683539da6ff7d4836fd6e189fa26b`

## Searchable Metadata
- **Keywords:** adi1090x, selected, FFFFFFFF, foreground, urgent, active, E06C75FF, background-alt, Shakya, Aditya, Author, background, Colors, Github
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/colors|modules/desktop/hyprland/programs/rofi/colors]]

## Source
```
css
/**
 *
 * Author : Aditya Shakya (adi1090x)
 * Github : @adi1090x
 * 
 * Colors
 **/

* {
    background:     #1E2127FF;
    background-alt: #282B31FF;
    foreground:     #FFFFFFFF;
    selected:       #61AFEFFF;
    active:         #98C379FF;
    urgent:         #E06C75FF;
}
```
