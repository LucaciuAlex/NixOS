# modules/desktop/hyprland/programs/rofi/launchers/type-1/shared/colors.rasi 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/launchers/type-1/shared/colors.rasi"
source_kind: text
extension: "rasi"
bytes: 401
sha256: 8ffb0ccf33aa4bcef01f28e3919e394e3519c1f1aaa96b8067fcc2c80f98b70a
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/rasi
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/launchers/type-1/shared/colors.rasi`
- **Source kind:** text
- **Size:** 401 bytes, 19 lines
- **SHA-256:** `8ffb0ccf33aa4bcef01f28e3919e394e3519c1f1aaa96b8067fcc2c80f98b70a`

## Searchable Metadata
- **Keywords:** Colors, Import, adi1090x, black, dracula, nord, solarized, gruvbox, lovelace, from, directory, color-scheme, onedark, yousai, cyberpunk
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/launchers/type-1/shared|modules/desktop/hyprland/programs/rofi/launchers/type-1/shared]]

### Detected References
- `import "~/.config/rofi/colors/catppuccin.rasi"`

## Source
```
css
/**
 *
 * Author : Aditya Shakya (adi1090x)
 * Github : @adi1090x
 * 
 * Colors
 *
 * Available Colors Schemes
 *
 * adapta    catppuccin    everforest    navy       paper
 * arc       cyberpunk     gruvbox       nord       solarized
 * black     dracula       lovelace      onedark    yousai
 *
 **/

/* Import color-scheme from `colors` directory */

@import "~/.config/rofi/colors/catppuccin.rasi"
```
