# modules/desktop/hyprland/icons/notifications/vol/muted-mic.svg 
---
type: repository-file
source_path: "modules/desktop/hyprland/icons/notifications/vol/muted-mic.svg"
source_kind: text
extension: "svg"
bytes: 855
sha256: 242bc66f50ae6dc43ada7fc25ee33e9878456be4f1611bb0aa631e6cdfbcd047
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/svg
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/icons/notifications/vol/muted-mic.svg`
- **Source kind:** text
- **Size:** 855 bytes, 11 lines
- **SHA-256:** `242bc66f50ae6dc43ada7fc25ee33e9878456be4f1611bb0aa631e6cdfbcd047`

## Searchable Metadata
- **Keywords:** svg, round, Repo, stroke-linecap, stroke-linejoin, stroke-width, http, SVGRepo_bgCarrier, SVGRepo_tracerCarrier, SVGRepo_iconCarrier, style, ffffff, data-darkreader-inline-stroke, path, M9.40137
- **Parent:** [[Files/modules/desktop/hyprland/icons/notifications/vol|modules/desktop/hyprland/icons/notifications/vol]]

## Source
```
xml
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
<!-- Uploaded to: SVG Repo, www.svgrepo.com, Transformed by: SVG Repo Mixer Tools -->
<svg width="120px" height="120px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">

<g id="SVGRepo_bgCarrier" stroke-width="0"/>

<g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"/>

<g id="SVGRepo_iconCarrier"> <path d="M9.40137 4.5C9.92008 3.6033 10.8896 3 12 3C13.6569 3 15 4.34315 15 6V10M18 12C18 12.3407 17.9716 12.6748 17.9171 13M3 3L21 21M12 18C8.68629 18 6 15.3137 6 12M12 18C12.3407 18 12.6748 17.9716 13 17.917M12 18V21M12 21H15M12 21H9" stroke="#000000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="--darkreader-inline-stroke: #ffffff;" data-darkreader-inline-stroke=""/> </g>

</svg>
```
