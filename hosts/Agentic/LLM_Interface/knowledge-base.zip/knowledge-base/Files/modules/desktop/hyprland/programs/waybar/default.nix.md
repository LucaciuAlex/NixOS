# modules/desktop/hyprland/programs/waybar/default.nix 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/waybar/default.nix"
source_kind: text
extension: "nix"
bytes: 150
sha256: 7c7e71231b13bb34e7267e3e06e0e95f2d5b20369c242663058c7ccdd25755e8
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/waybar/default.nix`
- **Source kind:** text
- **Size:** 150 bytes, 10 lines
- **SHA-256:** `7c7e71231b13bb34e7267e3e06e0e95f2d5b20369c242663058c7ccdd25755e8`

## Searchable Metadata
- **Keywords:** waybarTheme, host, import, imports, lib, let, inherit
- **Parent:** [[Files/modules/desktop/hyprland/programs/waybar|modules/desktop/hyprland/programs/waybar]]

### Detected Declarations / Headings
- `imports =`

### Detected References
- `import ../../../../../hosts/${host}/variables.nix) waybarTheme;`
- `imports = [`

## Source
```
nix
{ host, lib, ... }:
let
  inherit (import ../../../../../hosts/${host}/variables.nix) waybarTheme;
in
{
  imports = [
    ./${waybarTheme}.nix
  ];
}
```
