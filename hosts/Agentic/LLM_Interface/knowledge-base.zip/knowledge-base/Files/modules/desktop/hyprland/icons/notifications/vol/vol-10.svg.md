# modules/desktop/hyprland/icons/notifications/vol/vol-10.svg 
---
type: repository-file
source_path: "modules/desktop/hyprland/icons/notifications/vol/vol-10.svg"
source_kind: text
extension: "svg"
bytes: 3405
sha256: 193bfd5c696b641c82c583fd4610c5511be94da7c8e221023fefe442c5ae3ef3
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/svg
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/icons/notifications/vol/vol-10.svg`
- **Source kind:** text
- **Size:** 3405 bytes, 86 lines
- **SHA-256:** `193bfd5c696b641c82c583fd4610c5511be94da7c8e221023fefe442c5ae3ef3`

## Searchable Metadata
- **Keywords:** inkscape, label, sodipodi, display, fill, true, style, stroke-width, insensitive, fill-opacity, inline, http, xmlns, SVG, path
- **Parent:** [[Files/modules/desktop/hyprland/icons/notifications/vol|modules/desktop/hyprland/icons/notifications/vol]]

### Detected Declarations / Headings
- `height=`
- `width=`
- `version=`
- `id=`
- `viewBox=`
- `xmlns=`
- `id=`
- `id=`
- `pagecolor=`
- `bordercolor=`
- `borderopacity=`
- `showgrid=`

### Detected References
- `sourceforge.net/DTD/sodipodi-0.dtd"`

## Source
```
xml
<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<!-- Uploaded to: SVG Repo, www.svgrepo.com, Generator: SVG Repo Mixer Tools -->

<svg
   height="120px"
   width="120px"
   version="1.1"
   id="Layer_1"
   viewBox="0 0 496.8 496.8"
   xml:space="preserve"
   sodipodi:docname="vol-10.svg"
   inkscape:version="1.2.2 (b0a8486541, 2022-12-01)"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:svg="http://www.w3.org/2000/svg"><defs
   id="defs23" /><sodipodi:namedview
   id="namedview21"
   pagecolor="#ffffff"
   bordercolor="#000000"
   borderopacity="0.25"
   inkscape:showpageshadow="2"
   inkscape:pageopacity="0.0"
   inkscape:pagecheckerboard="0"
   inkscape:deskcolor="#d1d1d1"
   showgrid="true"
   inkscape:zoom="22.966828"
   inkscape:cx="46.828408"
   inkscape:cy="45.914046"
   inkscape:window-width="2524"
   inkscape:window-height="1011"
   inkscape:window-x="0"
   inkscape:window-y="0"
   inkscape:window-maximized="1"
   inkscape:current-layer="Layer_1"><inkscape:grid
     type="xygrid"
     id="grid3192" /></sodipodi:namedview>






<g
   id="g3158"
   inkscape:label="base"
   sodipodi:insensitive="true"><path
     style="display:inline;fill:#121c1b;fill-opacity:1;stroke-width:1.584"
     d="m 248.87519,445.92001 c 116.5824,0 212.8896,-91.2384 220.4928,-205.2864 0,5.0688 1.2672,8.8704 1.2672,13.9392 0,121.6512 -98.8416,221.76 -221.76,221.76 -121.6512,0 -221.759991,-98.8416 -221.759991,-221.76 0,-5.0688 0,-8.8704 1.2672,-13.9392 7.6032,114.048 103.910391,205.2864 220.492791,205.2864 z"
     id="path8"
     inkscape:label="shadow"
     sodipodi:insensitive="true" /><circle
     style="display:inline;fill:#283538;fill-opacity:1;stroke-width:1.584"
     cx="248.8752"
     cy="243.07127"
     r="221.76001"
     id="circle12"
     inkscape:label="dial"
     sodipodi:insensitive="true" /><path
     style="display:inline;fill:#000000;fill-opacity:0.153846;stroke-width:1.58653"
     d="m 405.74362,86.606184 c 86.3078,86.307816 86.3078,227.192636 0,313.500456 -86.30783,86.3078 -227.19264,86.3078 -313.500453,0"
     id="path14"
     inkscape:label="highlight"
     sodipodi:insensitive="true" /></g>

<g
   id="g3198"
   inkscape:label="main"><circle
     style="display:none;fill:#000000;fill-opacity:0;stroke-width:1.584"
     cx="-154.87985"
     cy="311.57745"
     r="221.76001"
     id="circle12-3"
     inkscape:label="anchor"
     transform="rotate(-72)"
     sodipodi:insensitive="true" /><path
     style="display:inline;fill:#121c1b;fill-opacity:1;stroke-width:1.584"
     d="m 143.44771,203.77606 c 7.23107,2.34953 10.48544,8.73659 8.13592,15.96766 v 0 c -2.34952,7.23107 -8.73658,10.48544 -15.96766,8.13592 L 87.408817,212.21619 c -7.231072,-2.34953 -10.485441,-8.73659 -8.135924,-15.96766 v 0 c 2.349518,-7.23107 8.736579,-10.48544 15.967652,-8.13592 z"
     id="path3789"
     inkscape:label="shadow" /><path
     style="display:inline;fill:#ea398a;stroke-width:1.584"
     d="m 143.55713,195.74179 c 7.23108,2.34953 10.48545,8.73659 8.13593,15.96766 v 0 c -2.34952,7.23107 -8.73658,10.48544 -15.96765,8.13593 L 87.518248,204.18192 c -7.231071,-2.34952 -10.485442,-8.73658 -8.135923,-15.96765 v 0 c 2.349517,-7.23108 8.736578,-10.48545 15.967651,-8.13593 z"
     id="path915"
     inkscape:label="pointer" /></g>
</svg>
```
