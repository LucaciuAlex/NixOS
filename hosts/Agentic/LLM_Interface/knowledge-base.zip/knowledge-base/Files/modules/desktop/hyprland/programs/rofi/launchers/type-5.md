# modules/desktop/hyprland/programs/rofi/launchers/type-5  This page represents the repository directory `modules/desktop/hyprland/programs/rofi/launchers/type-5` and links to its indexed files.  ## Files
- [[modules/desktop/hyprland/programs/rofi/launchers/type-5/style-1.rasi.md|modules/desktop/hyprland/programs/rofi/launchers/type-5/style-1.rasi]]
- [[modules/desktop/hyprland/programs/rofi/launchers/type-5/style-2.rasi.md|modules/desktop/hyprland/programs/rofi/launchers/type-5/style-2.rasi]]
- [[modules/desktop/hyprland/programs/rofi/launchers/type-5/style-3.rasi.md|modules/desktop/hyprland/programs/rofi/launchers/type-5/style-3.rasi]]
- [[modules/desktop/hyprland/programs/rofi/launchers/type-5/style-4.rasi.md|modules/desktop/hyprland/programs/rofi/launchers/type-5/style-4.rasi]]
- [[modules/desktop/hyprland/programs/rofi/launchers/type-5/style-5.rasi.md|modules/desktop/hyprland/programs/rofi/launchers/type-5/style-5.rasi]]
