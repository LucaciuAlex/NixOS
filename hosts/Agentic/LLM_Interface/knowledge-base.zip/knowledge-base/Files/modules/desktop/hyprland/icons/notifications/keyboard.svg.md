# modules/desktop/hyprland/icons/notifications/keyboard.svg 
---
type: repository-file
source_path: "modules/desktop/hyprland/icons/notifications/keyboard.svg"
source_kind: text
extension: "svg"
bytes: 4186
sha256: 5486d8f084750d56a5cec1cc3a3c147f3bde4fb00d0131341066c1fbf15cc4f0
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/svg
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/icons/notifications/keyboard.svg`
- **Source kind:** text
- **Size:** 4186 bytes, 106 lines
- **SHA-256:** `5486d8f084750d56a5cec1cc3a3c147f3bde4fb00d0131341066c1fbf15cc4f0`

## Searchable Metadata
- **Keywords:** fill, inkscape, style, path, fill-opacity, http, xmlns, version, sodipodi, svg12, svg, inline, display, window-maximized, window-height
- **Parent:** [[Files/modules/desktop/hyprland/icons/notifications|modules/desktop/hyprland/icons/notifications]]

### Detected Declarations / Headings
- `height=`
- `width=`
- `viewBox=`
- `fill=`
- `version=`
- `id=`
- `xmlns=`
- `id=`
- `id=`
- `pagecolor=`
- `bordercolor=`
- `borderopacity=`

### Detected References
- `sourceforge.net/DTD/sodipodi-0.dtd"`

## Source
```
xml
<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg
   height="800px"
   width="800px"
   viewBox="0 0 24 24"
   fill="none"
   version="1.1"
   id="svg12"
   sodipodi:docname="keyboard.svg"
   inkscape:version="1.3 (0e150ed6c4, 2023-07-21)"
   inkscape:export-filename="keyboard.png"
   inkscape:export-xdpi="96"
   inkscape:export-ydpi="96"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:svg="http://www.w3.org/2000/svg">
  <defs
     id="defs12" />
  <sodipodi:namedview
     id="namedview12"
     pagecolor="#ffffff"
     bordercolor="#000000"
     borderopacity="0.25"
     inkscape:showpageshadow="2"
     inkscape:pageopacity="0.0"
     inkscape:pagecheckerboard="0"
     inkscape:deskcolor="#d1d1d1"
     inkscape:zoom="1.6075631"
     inkscape:cx="190.35023"
     inkscape:cy="99.218502"
     inkscape:window-width="1265"
     inkscape:window-height="1032"
     inkscape:window-x="0"
     inkscape:window-y="0"
     inkscape:window-maximized="1"
     inkscape:current-layer="svg12" />
  <g
     id="SVGRepo_iconCarrier"
     inkscape:label="kbd"
     transform="matrix(0.71618532,0,0,0.71618532,3.4057762,3.4057762)"
     style="display:inline">
    <path
       opacity="0.5"
       d="M 16,5 H 8 C 5.17157,5 3.75736,5 2.87868,5.87868 2,6.75736 2,8.17157 2,11 v 2 c 0,2.8284 0,4.2426 0.87868,5.1213 C 3.75736,19 5.17157,19 8,19 h 8 c 2.8284,0 4.2426,0 5.1213,-0.8787 C 22,17.2426 22,15.8284 22,13 V 11 C 22,8.17157 22,6.75736 21.1213,5.87868 20.2426,5 18.8284,5 16,5 Z"
       fill="#1c274c"
       id="path1"
       style="fill:#a7adba;fill-opacity:1" />
    <path
       d="M 6,10 C 6.55228,10 7,9.55228 7,9 7,8.44772 6.55228,8 6,8 5.44772,8 5,8.44772 5,9 c 0,0.55228 0.44772,1 1,1 z"
       fill="#1c274c"
       id="path2"
       style="fill:#4f5b66;fill-opacity:1" />
    <path
       d="m 6,13 c 0.55228,0 1,-0.4477 1,-1 0,-0.5523 -0.44772,-1 -1,-1 -0.55228,0 -1,0.4477 -1,1 0,0.5523 0.44772,1 1,1 z"
       fill="#1c274c"
       id="path3"
       style="fill:#4f5b66;fill-opacity:1" />
    <path
       d="m 9,13 c 0.55228,0 1,-0.4477 1,-1 0,-0.5523 -0.44772,-1 -1,-1 -0.55228,0 -1,0.4477 -1,1 0,0.5523 0.44772,1 1,1 z"
       fill="#1c274c"
       id="path4"
       style="fill:#4f5b66;fill-opacity:1" />
    <path
       d="M 9,10 C 9.55228,10 10,9.55228 10,9 10,8.44772 9.55228,8 9,8 8.44772,8 8,8.44772 8,9 c 0,0.55228 0.44772,1 1,1 z"
       fill="#1c274c"
       id="path5"
       style="fill:#4f5b66;fill-opacity:1" />
    <path
       d="m 12,10 c 0.5523,0 1,-0.44772 1,-1 0,-0.55228 -0.4477,-1 -1,-1 -0.5523,0 -1,0.44772 -1,1 0,0.55228 0.4477,1 1,1 z"
       fill="#1c274c"
       id="path6"
       style="fill:#4f5b66;fill-opacity:1" />
    <path
       d="m 12,13 c 0.5523,0 1,-0.4477 1,-1 0,-0.5523 -0.4477,-1 -1,-1 -0.5523,0 -1,0.4477 -1,1 0,0.5523 0.4477,1 1,1 z"
       fill="#1c274c"
       id="path7"
       style="fill:#4f5b66;fill-opacity:1" />
    <path
       d="m 15,10 c 0.5523,0 1,-0.44772 1,-1 0,-0.55228 -0.4477,-1 -1,-1 -0.5523,0 -1,0.44772 -1,1 0,0.55228 0.4477,1 1,1 z"
       fill="#1c274c"
       id="path8"
       style="fill:#4f5b66;fill-opacity:1" />
    <path
       d="m 15,13 c 0.5523,0 1,-0.4477 1,-1 0,-0.5523 -0.4477,-1 -1,-1 -0.5523,0 -1,0.4477 -1,1 0,0.5523 0.4477,1 1,1 z"
       fill="#1c274c"
       id="path9"
       style="fill:#4f5b66;fill-opacity:1" />
    <path
       d="m 18,10 c 0.5523,0 1,-0.44772 1,-1 0,-0.55228 -0.4477,-1 -1,-1 -0.5523,0 -1,0.44772 -1,1 0,0.55228 0.4477,1 1,1 z"
       fill="#1c274c"
       id="path10"
       style="fill:#4f5b66;fill-opacity:1" />
    <path
       d="m 18,13 c 0.5523,0 1,-0.4477 1,-1 0,-0.5523 -0.4477,-1 -1,-1 -0.5523,0 -1,0.4477 -1,1 0,0.5523 0.4477,1 1,1 z"
       fill="#1c274c"
       id="path11"
       style="fill:#4f5b66;fill-opacity:1" />
    <path
       d="m 17.75,16 c 0,0.4142 -0.3358,0.75 -0.75,0.75 H 7 C 6.58579,16.75 6.25,16.4142 6.25,16 6.25,15.5858 6.58579,15.25 7,15.25 h 10 c 0.4142,0 0.75,0.3358 0.75,0.75 z"
       fill="#1c274c"
       id="path12"
       style="fill:#4f5b66;fill-opacity:1" />
  </g>
</svg>
```
