# modules/desktop/hyprland/programs/rofi/launchers/type-4/shared/fonts.rasi 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/launchers/type-4/shared/fonts.rasi"
source_kind: text
extension: "rasi"
bytes: 136
sha256: a8e0afb6b213102d1737a2e86a1c0f3ea645b69319dfd895a13352e56c2e01e5
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/rasi
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/launchers/type-4/shared/fonts.rasi`
- **Source kind:** text
- **Size:** 136 bytes, 14 lines
- **SHA-256:** `a8e0afb6b213102d1737a2e86a1c0f3ea645b69319dfd895a13352e56c2e01e5`

## Searchable Metadata
- **Keywords:** adi1090x, font, Nerd, Mono, JetBrains, Fonts, Aditya, Author, Github, Shakya
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/launchers/type-4/shared|modules/desktop/hyprland/programs/rofi/launchers/type-4/shared]]

## Source
```
css
/**
 *
 * Author : Aditya Shakya (adi1090x)
 * Github : @adi1090x
 * 
 * Fonts
 *
 **/

* {
    font: "JetBrains Mono Nerd Font 10";
}
```
