# modules/desktop/hyprland/programs/wlogout/icons/power-hover.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/wlogout/icons/power-hover.png"
source_kind: binary
extension: "png"
bytes: 10841
sha256: e3ba471a842710a6b1ca27a1e2e02a6df57d2130b6c99b6e84325843edc0ac14
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/wlogout/icons/power-hover.png`
- **Source kind:** binary
- **Size:** 10841 bytes
- **SHA-256:** `e3ba471a842710a6b1ca27a1e2e02a6df57d2130b6c99b6e84325843edc0ac14`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/programs/wlogout/icons|modules/desktop/hyprland/programs/wlogout/icons]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
