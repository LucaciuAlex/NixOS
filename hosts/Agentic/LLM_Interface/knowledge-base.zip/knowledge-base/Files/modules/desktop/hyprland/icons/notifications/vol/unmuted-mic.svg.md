# modules/desktop/hyprland/icons/notifications/vol/unmuted-mic.svg 
---
type: repository-file
source_path: "modules/desktop/hyprland/icons/notifications/vol/unmuted-mic.svg"
source_kind: text
extension: "svg"
bytes: 1069
sha256: 7ef7f362781b34a6224f378852dd69a4d23bd6c3c5047631cb3fad7aa6ab36a4
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/svg
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/icons/notifications/vol/unmuted-mic.svg`
- **Source kind:** text
- **Size:** 1069 bytes, 11 lines
- **SHA-256:** `7ef7f362781b34a6224f378852dd69a4d23bd6c3c5047631cb3fad7aa6ab36a4`

## Searchable Metadata
- **Keywords:** svg, round, path, stroke-width, stroke-linejoin, stroke-linecap, fill, http, Repo, style, data-darkreader-inline-stroke, ffffff, SVGRepo_tracerCarrier, M18, data-darkreader-inline-fill
- **Parent:** [[Files/modules/desktop/hyprland/icons/notifications/vol|modules/desktop/hyprland/icons/notifications/vol]]

## Source
```
xml
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
<!-- Uploaded to: SVG Repo, www.svgrepo.com, Transformed by: SVG Repo Mixer Tools -->
<svg width="120px" height="120px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">

<g id="SVGRepo_bgCarrier" stroke-width="0"/>

<g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"/>

<g id="SVGRepo_iconCarrier"> <path opacity="0.15" d="M9 6C9 4.34315 10.3431 3 12 3C13.6569 3 15 4.34315 15 6V12C15 13.6569 13.6569 15 12 15C10.3431 15 9 13.6569 9 12V6Z" fill="#000000" style="--darkreader-inline-fill: #000000;" data-darkreader-inline-fill=""/> <path d="M18 12C18 15.3137 15.3137 18 12 18M12 18C8.68629 18 6 15.3137 6 12M12 18V21M12 21H15M12 21H9M15 6V12C15 13.6569 13.6569 15 12 15C10.3431 15 9 13.6569 9 12V6C9 4.34315 10.3431 3 12 3C13.6569 3 15 4.34315 15 6Z" stroke="#000000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="--darkreader-inline-stroke: #ffffff;" data-darkreader-inline-stroke=""/> </g>

</svg>
```
