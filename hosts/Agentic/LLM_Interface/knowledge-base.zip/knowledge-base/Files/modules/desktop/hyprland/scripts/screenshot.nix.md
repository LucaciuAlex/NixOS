# modules/desktop/hyprland/scripts/screenshot.nix 
---
type: repository-file
source_path: "modules/desktop/hyprland/scripts/screenshot.nix"
source_kind: text
extension: "nix"
bytes: 1531
sha256: 8015ef0cb040c98e431a800e8b3735d588495a234b0f14232c16fcc8780037c4
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/scripts/screenshot.nix`
- **Source kind:** text
- **Size:** 1531 bytes, 54 lines
- **SHA-256:** `8015ef0cb040c98e431a800e8b3735d588495a234b0f14232c16fcc8780037c4`

## Searchable Metadata
- **Keywords:** area, save_dir, save_file, take_screenshot, EOF, pkgs.swappy, pkgs.grimblast, save, screen, output, screenshot, XDG_PICTURES_DIR, Snip, cat, case
- **Parent:** [[Files/modules/desktop/hyprland/scripts|modules/desktop/hyprland/scripts]]

### Detected Declarations / Headings
- `swpy_dir=`
- `XDG_PICTURES_DIR=`
- `save_dir=`
- `save_dir=`
- `save_filename_format=`

## Source
```
nix
{ pkgs, ... }:
pkgs.writeShellScriptBin "screenshot" ''
  swpy_dir="''${XDG_CONFIG_HOME:-$HOME/.config}/swappy"
  XDG_PICTURES_DIR="''${XDG_PICTURES_DIR:-$HOME/Pictures}"
  save_dir="''${XDG_PICTURES_DIR}/Screenshots"

  mkdir -p "$save_dir"
  mkdir -p "$swpy_dir"

  print_error() {
    cat << EOF
  Usage: $(basename "$0") <action>
  Valid actions:
    p  : Print all screens
    s  : Snip area
    sf : Snip area (frozen)
    m  : Print focused monitor
  EOF
    exit 1
  }

  take_screenshot() {
    local save_file="$(date +'%y%m%d_%Hh%Mm%Ss_screenshot.png')"

    cat > "$swpy_dir/config" << EOF
  [Default]
  save_dir=$save_dir
  save_filename_format=$save_file
  EOF

    case "$1" in
      screen) ${pkgs.grimblast}/bin/grimblast save screen - | ${pkgs.swappy}/bin/swappy -f - ;;
      area)   ${pkgs.grimblast}/bin/grimblast save area - | ${pkgs.swappy}/bin/swappy -f - ;;
      freeze) ${pkgs.grimblast}/bin/grimblast --freeze save area - | ${pkgs.swappy}/bin/swappy -f - ;;
      output) ${pkgs.grimblast}/bin/grimblast save output - | ${pkgs.swappy}/bin/swappy -f - ;;
    esac

    if [ -f "''${save_dir}/''${save_file}" ]; then
      ${pkgs.libnotify}/bin/notify-send -a Screenshot \
                  -i "''${save_dir}/''${save_file}" \
                  "Screenshot Saved" \
                  "$(basename "$save_file")"
    fi
  }

  case "$1" in
    p)  take_screenshot screen ;;
    s)  take_screenshot area ;;
    sf) take_screenshot freeze ;;
    m)  take_screenshot output ;;
    *)  print_error ;;
  esac
''
```
