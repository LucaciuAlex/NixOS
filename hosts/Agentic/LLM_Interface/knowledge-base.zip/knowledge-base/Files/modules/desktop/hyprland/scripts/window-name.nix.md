# modules/desktop/hyprland/scripts/window-name.nix 
---
type: repository-file
source_path: "modules/desktop/hyprland/scripts/window-name.nix"
source_kind: text
extension: "nix"
bytes: 294
sha256: 292a0c1d8b2a19c7fbfe1fd23f567034005f355ede768772500ad40b465dc45c
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/scripts/window-name.nix`
- **Source kind:** text
- **Size:** 294 bytes, 10 lines
- **SHA-256:** `292a0c1d8b2a19c7fbfe1fd23f567034005f355ede768772500ad40b465dc45c`

## Searchable Metadata
- **Keywords:** echo, window_class, kitty, firefox, print, pkgs.gawk, esac, case, window-name, pkgs.writeShellScriptBin, pkgs, hyprctl, class, pkgs.gnugrep, activewindow
- **Parent:** [[Files/modules/desktop/hyprland/scripts|modules/desktop/hyprland/scripts]]

### Detected Declarations / Headings
- `window_class=`

## Source
```
nix
{ pkgs, ... }:
pkgs.writeShellScriptBin "window-name" ''
  window_class=$(hyprctl activewindow | ${pkgs.gnugrep}/bin/grep class | ${pkgs.gawk}/bin/awk '{print $2}')
  case $window_class in
    "kitty") echo "kitty " ;;
    "firefox") echo "firefox " ;;
    *) echo "$window_class" ;;
  esac
''
```
