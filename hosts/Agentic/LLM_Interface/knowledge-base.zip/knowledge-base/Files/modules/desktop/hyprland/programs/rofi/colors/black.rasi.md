# modules/desktop/hyprland/programs/rofi/colors/black.rasi 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/colors/black.rasi"
source_kind: text
extension: "rasi"
bytes: 278
sha256: e3a644f0bd19b07ee37dfd3ca310388de3634679e4cc64d5daa2e3206597eb97
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/rasi
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/colors/black.rasi`
- **Source kind:** text
- **Size:** 278 bytes, 17 lines
- **SHA-256:** `e3a644f0bd19b07ee37dfd3ca310388de3634679e4cc64d5daa2e3206597eb97`

## Searchable Metadata
- **Keywords:** adi1090x, selected, FFFFFFFF, foreground, urgent, active, E06B74FF, background-alt, Shakya, Aditya, Author, background, Colors, Github
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/colors|modules/desktop/hyprland/programs/rofi/colors]]

## Source
```
css
/**
 *
 * Author : Aditya Shakya (adi1090x)
 * Github : @adi1090x
 * 
 * Colors
 **/

* {
    background:     #000000FF;
    background-alt: #101010FF;
    foreground:     #FFFFFFFF;
    selected:       #62AEEFFF;
    active:         #98C379FF;
    urgent:         #E06B74FF;
}
```
