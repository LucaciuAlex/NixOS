# modules/desktop/hyprland/lua/animations.lua 
---
type: repository-file
source_path: "modules/desktop/hyprland/lua/animations.lua"
source_kind: text
extension: "lua"
bytes: 1104
sha256: 621357e4328d6c0d8fccdbd18b7df904cdc1358319486710e71568eeb4487ec7
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/lua
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/lua/animations.lua`
- **Source kind:** text
- **Size:** 1104 bytes, 15 lines
- **SHA-256:** `621357e4328d6c0d8fccdbd18b7df904cdc1358319486710e71568eeb4487ec7`

## Searchable Metadata
- **Keywords:** bezier, hl.animation, speed, true, leaf, enabled, md3_decel, style, hl.curve, type, workspaces, points, slide, easeOutExpo, fluent_decel
- **Parent:** [[Files/modules/desktop/hyprland/lua|modules/desktop/hyprland/lua]]

## Source
```
lua
-- Curves
hl.curve("md3_decel", { type = "bezier", points = { {0.05, 0.7}, {0.1, 1} } })
hl.curve("easeOutExpo", { type = "bezier", points = { {0.16, 1}, {0.3, 1} } })
hl.curve("fluent_decel", { type = "bezier", points = { {0.1, 1}, {0, 1} } })

-- Animations
hl.animation({ leaf = "windows", enabled = true, speed = 3, bezier = "md3_decel", style = "popin 60%" })
hl.animation({ leaf = "border", enabled = true, speed = 10, bezier = "default" })
hl.animation({ leaf = "fade", enabled = true, speed = 2.5, bezier = "md3_decel" })
-- hl.animation({ leaf = "workspaces", enabled = true, speed = 3.5, bezier = "md3_decel", style = "slide" })
hl.animation({ leaf = "workspaces", enabled = true, speed = 3.5, bezier = "easeOutExpo", style = "slide" })
-- hl.animation({ leaf = "workspaces", enabled = true, speed = 7, bezier = "fluent_decel", style = "slidefade 15%" })
-- hl.animation({ leaf = "specialWorkspace", enabled = true, speed = 3, bezier = "md3_decel", style = "slidefadevert 15%" })
hl.animation({ leaf = "specialWorkspace", enabled = true, speed = 3, bezier = "md3_decel", style = "slidefade" })
```
