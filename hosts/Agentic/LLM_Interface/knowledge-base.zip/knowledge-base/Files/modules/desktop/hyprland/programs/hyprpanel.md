# modules/desktop/hyprland/programs/hyprpanel  This page represents the repository directory `modules/desktop/hyprland/programs/hyprpanel` and links to its indexed files.  ## Files
- [[modules/desktop/hyprland/programs/hyprpanel/default.nix.md|modules/desktop/hyprland/programs/hyprpanel/default.nix]]
- [[modules/desktop/hyprland/programs/hyprpanel/profile-picture.jpg.md|modules/desktop/hyprland/programs/hyprpanel/profile-picture.jpg]]
