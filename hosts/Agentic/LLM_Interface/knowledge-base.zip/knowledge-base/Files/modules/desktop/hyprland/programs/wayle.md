# modules/desktop/hyprland/programs/wayle  This page represents the repository directory `modules/desktop/hyprland/programs/wayle` and links to its indexed files.  ## Files
- [[modules/desktop/hyprland/programs/wayle/default.nix.md|modules/desktop/hyprland/programs/wayle/default.nix]]
- [[modules/desktop/hyprland/programs/wayle/profile-picture.jpg.md|modules/desktop/hyprland/programs/wayle/profile-picture.jpg]]
