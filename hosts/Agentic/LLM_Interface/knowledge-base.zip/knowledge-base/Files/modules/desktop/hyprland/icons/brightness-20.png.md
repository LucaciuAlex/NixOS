# modules/desktop/hyprland/icons/brightness-20.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/icons/brightness-20.png"
source_kind: binary
extension: "png"
bytes: 20950
sha256: bd0da558b0e4f8354107ce32a7e65ee744cb271c155bd7cb6a9a05f86a5cf6c3
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/icons/brightness-20.png`
- **Source kind:** binary
- **Size:** 20950 bytes
- **SHA-256:** `bd0da558b0e4f8354107ce32a7e65ee744cb271c155bd7cb6a9a05f86a5cf6c3`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/icons|modules/desktop/hyprland/icons]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
