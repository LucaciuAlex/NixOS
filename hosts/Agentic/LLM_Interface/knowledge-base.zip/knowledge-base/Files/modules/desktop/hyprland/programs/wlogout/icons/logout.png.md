# modules/desktop/hyprland/programs/wlogout/icons/logout.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/wlogout/icons/logout.png"
source_kind: binary
extension: "png"
bytes: 3784
sha256: 3fc6b0b753aa6d24e2dabf4ce8f6ec00652c03b263d0083c0374cd5b1f5bb09b
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/wlogout/icons/logout.png`
- **Source kind:** binary
- **Size:** 3784 bytes
- **SHA-256:** `3fc6b0b753aa6d24e2dabf4ce8f6ec00652c03b263d0083c0374cd5b1f5bb09b`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/programs/wlogout/icons|modules/desktop/hyprland/programs/wlogout/icons]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
