# modules/desktop/hyprland/programs/rofi/colors/yousai.rasi 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/colors/yousai.rasi"
source_kind: text
extension: "rasi"
bytes: 278
sha256: 500725801cd6168b3aee01ac5b8debbb475f2c1369cd27bfebafdfe2ec4aee2c
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/rasi
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/colors/yousai.rasi`
- **Source kind:** text
- **Size:** 278 bytes, 17 lines
- **SHA-256:** `500725801cd6168b3aee01ac5b8debbb475f2c1369cd27bfebafdfe2ec4aee2c`

## Searchable Metadata
- **Keywords:** adi1090x, D97742FF, selected, EBDCD2FF, foreground, urgent, B23636FF, active, BF8F60FF, Shakya, Github, Author, Aditya, F5E7DEFF, background-alt
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/colors|modules/desktop/hyprland/programs/rofi/colors]]

## Source
```
css
/**
 *
 * Author : Aditya Shakya (adi1090x)
 * Github : @adi1090x
 * 
 * Colors
 **/

* {
    background:     #F5E7DEFF;
    background-alt: #EBDCD2FF;
    foreground:     #34302DFF;
    selected:       #D97742FF;
    active:         #BF8F60FF;
    urgent:         #B23636FF;
}
```
