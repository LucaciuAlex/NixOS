# modules/desktop/hyprland/scripts/togglepowermode.nix 
---
type: repository-file
source_path: "modules/desktop/hyprland/scripts/togglepowermode.nix"
source_kind: text
extension: "nix"
bytes: 532
sha256: 1512cd5b28cdbdb5ce628665a69dab8b2c33364d2f3b2ce26886b570bf870bfa
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/scripts/togglepowermode.nix`
- **Source kind:** text
- **Size:** 532 bytes, 25 lines
- **SHA-256:** `1512cd5b28cdbdb5ce628665a69dab8b2c33364d2f3b2ce26886b570bf870bfa`

## Searchable Metadata
- **Keywords:** MODE_FILE, then, performance, CMD, NEW_MODE, pkgs.polkit, pkgs.tlp, CURRENT, echo, exit, else, bat, pkgs.writeShellScriptBin, pkgs, togglepowermode
- **Parent:** [[Files/modules/desktop/hyprland/scripts|modules/desktop/hyprland/scripts]]

### Detected Declarations / Headings
- `MODE_FILE=`
- `CURRENT=`
- `NEW_MODE=`
- `CMD=`
- `NEW_MODE=`
- `CMD=`

## Source
```
nix
{ pkgs, ... }:
pkgs.writeShellScriptBin "togglepowermode" ''
  MODE_FILE="$HOME/.config/hypr/power_mode"

  if [[ ! -s "$MODE_FILE" ]]; then
    echo "performance" > "$MODE_FILE"
  fi

  CURRENT=$(cat "$MODE_FILE")

  if [[ "$CURRENT" == "performance" ]]; then
    NEW_MODE="powersave"
    CMD="${pkgs.polkit}/bin/pkexec ${pkgs.tlp}/bin/tlp bat"
  else
    NEW_MODE="performance"
    CMD="${pkgs.polkit}/bin/pkexec ${pkgs.tlp}/bin/tlp ac"
  fi

  if $CMD > /dev/null 2>&1; then
    echo "$NEW_MODE" > "$MODE_FILE"
  fi

  exit 0
''
```
