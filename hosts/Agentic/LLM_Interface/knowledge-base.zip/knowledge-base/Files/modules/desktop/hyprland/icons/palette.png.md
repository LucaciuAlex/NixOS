# modules/desktop/hyprland/icons/palette.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/icons/palette.png"
source_kind: binary
extension: "png"
bytes: 35168
sha256: ab60016a48f6e960d9e097c7e9c64b9954d98abf5faee2abc70af2f4721930ce
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/icons/palette.png`
- **Source kind:** binary
- **Size:** 35168 bytes
- **SHA-256:** `ab60016a48f6e960d9e097c7e9c64b9954d98abf5faee2abc70af2f4721930ce`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/icons|modules/desktop/hyprland/icons]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
