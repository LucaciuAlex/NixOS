# modules/desktop/hyprland/programs/rofi/launchers/type-1/shared  This page represents the repository directory `modules/desktop/hyprland/programs/rofi/launchers/type-1/shared` and links to its indexed files.  ## Files
- [[modules/desktop/hyprland/programs/rofi/launchers/type-1/shared/colors.rasi.md|modules/desktop/hyprland/programs/rofi/launchers/type-1/shared/colors.rasi]]
- [[modules/desktop/hyprland/programs/rofi/launchers/type-1/shared/fonts.rasi.md|modules/desktop/hyprland/programs/rofi/launchers/type-1/shared/fonts.rasi]]
