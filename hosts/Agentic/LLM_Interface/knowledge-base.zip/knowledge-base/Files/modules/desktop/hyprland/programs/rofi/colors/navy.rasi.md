# modules/desktop/hyprland/programs/rofi/colors/navy.rasi 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/colors/navy.rasi"
source_kind: text
extension: "rasi"
bytes: 278
sha256: 0d8fea29b4ecb6b999e1d0bfebbaebedba039c6f4f9d74c7b665eb1ff511894c
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/rasi
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/colors/navy.rasi`
- **Source kind:** text
- **Size:** 278 bytes, 17 lines
- **SHA-256:** `0d8fea29b4ecb6b999e1d0bfebbaebedba039c6f4f9d74c7b665eb1ff511894c`

## Searchable Metadata
- **Keywords:** adi1090x, selected, F2F1B9FF, foreground, urgent, active, C2454EFF, background-alt, Shakya, Aditya, Author, background, Colors, Github
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/colors|modules/desktop/hyprland/programs/rofi/colors]]

## Source
```
css
/**
 *
 * Author : Aditya Shakya (adi1090x)
 * Github : @adi1090x
 * 
 * Colors
 **/

* {
    background:     #021B21FF;
    background-alt: #0C252BFF;
    foreground:     #F2F1B9FF;
    selected:       #44B5B1FF;
    active:         #7CBF9EFF;
    urgent:         #C2454EFF;
}
```
