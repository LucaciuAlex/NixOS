# modules/desktop/hyprland/icons/vpn.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/icons/vpn.png"
source_kind: binary
extension: "png"
bytes: 43432
sha256: 8e22991f9f6d73bcd013e489f0faac562408e0a4df478aceff9a5ea3bb9236cf
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/icons/vpn.png`
- **Source kind:** binary
- **Size:** 43432 bytes
- **SHA-256:** `8e22991f9f6d73bcd013e489f0faac562408e0a4df478aceff9a5ea3bb9236cf`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/icons|modules/desktop/hyprland/icons]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
