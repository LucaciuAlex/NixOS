# modules/desktop/i3/scripts  This page represents the repository directory `modules/desktop/i3/scripts` and links to its indexed files.  ## Files
- [[modules/desktop/i3/scripts/monitors.nix.md|modules/desktop/i3/scripts/monitors.nix]]
- [[modules/desktop/i3/scripts/wallpaper.nix.md|modules/desktop/i3/scripts/wallpaper.nix]]
