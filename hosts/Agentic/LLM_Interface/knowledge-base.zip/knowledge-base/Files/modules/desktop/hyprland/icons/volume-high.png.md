# modules/desktop/hyprland/icons/volume-high.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/icons/volume-high.png"
source_kind: binary
extension: "png"
bytes: 27993
sha256: b9f98a40dae05dc224351bbbc1299da067633b344b9d1e2a5f015a93e9d1717f
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/icons/volume-high.png`
- **Source kind:** binary
- **Size:** 27993 bytes
- **SHA-256:** `b9f98a40dae05dc224351bbbc1299da067633b344b9d1e2a5f015a93e9d1717f`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/icons|modules/desktop/hyprland/icons]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
