# modules/desktop/hyprland/programs/rofi/assets/style_6.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/assets/style_6.png"
source_kind: binary
extension: "png"
bytes: 21727
sha256: 6c640cef5953d3c22b5e8f870dfd6acfc00d37a7b5f6943fb986d7536770954b
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/assets/style_6.png`
- **Source kind:** binary
- **Size:** 21727 bytes
- **SHA-256:** `6c640cef5953d3c22b5e8f870dfd6acfc00d37a7b5f6943fb986d7536770954b`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/assets|modules/desktop/hyprland/programs/rofi/assets]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
