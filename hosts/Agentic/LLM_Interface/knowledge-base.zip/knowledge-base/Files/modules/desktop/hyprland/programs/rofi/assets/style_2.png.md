# modules/desktop/hyprland/programs/rofi/assets/style_2.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/assets/style_2.png"
source_kind: binary
extension: "png"
bytes: 22243
sha256: 3054d4cf45c99485d4e39448e4ae8c6a3c596c02e1a96e2b8d3138c0e5876750
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/assets/style_2.png`
- **Source kind:** binary
- **Size:** 22243 bytes
- **SHA-256:** `3054d4cf45c99485d4e39448e4ae8c6a3c596c02e1a96e2b8d3138c0e5876750`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/assets|modules/desktop/hyprland/programs/rofi/assets]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
