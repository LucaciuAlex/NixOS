# modules/desktop/hyprland/programs/wlogout/icons/logout-hover.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/wlogout/icons/logout-hover.png"
source_kind: binary
extension: "png"
bytes: 3784
sha256: f9f086e86fc70fd2192a4e640f40a609eb9daec4a08329106e492776fb59bcce
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/wlogout/icons/logout-hover.png`
- **Source kind:** binary
- **Size:** 3784 bytes
- **SHA-256:** `f9f086e86fc70fd2192a4e640f40a609eb9daec4a08329106e492776fb59bcce`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/programs/wlogout/icons|modules/desktop/hyprland/programs/wlogout/icons]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
