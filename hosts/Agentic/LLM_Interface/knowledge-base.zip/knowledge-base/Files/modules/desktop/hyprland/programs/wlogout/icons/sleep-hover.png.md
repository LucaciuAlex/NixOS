# modules/desktop/hyprland/programs/wlogout/icons/sleep-hover.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/wlogout/icons/sleep-hover.png"
source_kind: binary
extension: "png"
bytes: 5721
sha256: 0cdbfa10881a2b49d118befde900975a761e3283a80f9bf452bd9d308926b988
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/wlogout/icons/sleep-hover.png`
- **Source kind:** binary
- **Size:** 5721 bytes
- **SHA-256:** `0cdbfa10881a2b49d118befde900975a761e3283a80f9bf452bd9d308926b988`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/programs/wlogout/icons|modules/desktop/hyprland/programs/wlogout/icons]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
