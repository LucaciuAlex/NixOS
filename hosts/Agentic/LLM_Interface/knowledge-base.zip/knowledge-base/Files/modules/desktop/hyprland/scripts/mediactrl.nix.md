# modules/desktop/hyprland/scripts/mediactrl.nix 
---
type: repository-file
source_path: "modules/desktop/hyprland/scripts/mediactrl.nix"
source_kind: text
extension: "nix"
bytes: 1366
sha256: cab378afb349e5a8a195a9a6de79de93b439888773509ba0157221ef778b951f
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/scripts/mediactrl.nix`
- **Source kind:** text
- **Size:** 1366 bytes, 55 lines
- **SHA-256:** `cab378afb349e5a8a195a9a6de79de93b439888773509ba0157221ef778b951f`

## Searchable Metadata
- **Keywords:** pkgs.playerctl, show_music_notification, status, music_icon, stop, previous, play-pause, low, next, pkgs.libnotify, Paused, song_artist, metadata, Playing, then
- **Parent:** [[Files/modules/desktop/hyprland/scripts|modules/desktop/hyprland/scripts]]

### Detected Declarations / Headings
- `music_icon=`
- `status=`
- `song_title=`
- `song_artist=`

## Source
```
nix
{ pkgs, ... }:
pkgs.writeShellScriptBin "mediactrl" ''
  music_icon="''${XDG_CONFIG_HOME:-$HOME/.config}/hypr/icons/music.png"

  play_next() {
    ${pkgs.playerctl}/bin/playerctl next
    show_music_notification
  }

  play_previous() {
    ${pkgs.playerctl}/bin/playerctl previous
    show_music_notification
  }

  toggle_play_pause() {
    ${pkgs.playerctl}/bin/playerctl play-pause
    show_music_notification
  }

  stop_playback() {
    ${pkgs.playerctl}/bin/playerctl stop
    ${pkgs.libnotify}/bin/notify-send -e -u low -i "$music_icon" "Playback Stopped"
  }

  show_music_notification() {
    status=$(${pkgs.playerctl}/bin/playerctl status)
    if [[ "$status" == "Playing" ]]; then
      song_title=$(${pkgs.playerctl}/bin/playerctl metadata title)
      song_artist=$(${pkgs.playerctl}/bin/playerctl metadata artist)
      ${pkgs.libnotify}/bin/notify-send -e -u low -i "$music_icon" "Now Playing:" "$song_title by $song_artist"
    elif [[ "$status" == "Paused" ]]; then
      ${pkgs.libnotify}/bin/notify-send -e -u low -i "$music_icon" "Playback Paused"
    fi
  }

  case "$1" in
    "next")
      play_next
      ;;
    "previous")
      play_previous
      ;;
    "play-pause")
      toggle_play_pause
      ;;
    "stop")
      stop_playback
      ;;
    *)
      echo "Usage: $0 [next|previous|play-pause|stop]"
      exit 1
      ;;
  esac
''
```
