# modules/desktop/hyprland/programs/swaylock  This page represents the repository directory `modules/desktop/hyprland/programs/swaylock` and links to its indexed files.  ## Files
- [[modules/desktop/hyprland/programs/swaylock/default.nix.md|modules/desktop/hyprland/programs/swaylock/default.nix]]
