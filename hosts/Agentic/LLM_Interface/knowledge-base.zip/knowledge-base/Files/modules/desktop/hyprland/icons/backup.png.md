# modules/desktop/hyprland/icons/backup.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/icons/backup.png"
source_kind: binary
extension: "png"
bytes: 19157
sha256: c160fc7b995805dca5f5b612b7652d9f28c3178564b8d82dd21d9d0b118b14b4
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/icons/backup.png`
- **Source kind:** binary
- **Size:** 19157 bytes
- **SHA-256:** `c160fc7b995805dca5f5b612b7652d9f28c3178564b8d82dd21d9d0b118b14b4`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/icons|modules/desktop/hyprland/icons]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
