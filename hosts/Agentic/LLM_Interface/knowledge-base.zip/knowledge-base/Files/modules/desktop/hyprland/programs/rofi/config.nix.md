# modules/desktop/hyprland/programs/rofi/config.nix 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/config.nix"
source_kind: text
extension: "nix"
bytes: 4649
sha256: 10945d6a6815986022d147f5e76e4ce61e4f986a58467156d253960fcfae09de
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/config.nix`
- **Source kind:** text
- **Size:** 4649 bytes, 149 lines
- **SHA-256:** `10945d6a6815986022d147f5e76e4ce61e4f986a58467156d253960fcfae09de`

## Searchable Metadata
- **Keywords:** Control, Alt, Super, false, true, Shift, settings, window, Return, setting, run, terminal, Left, SSH, Right
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi|modules/desktop/hyprland/programs/rofi]]

### Detected Declarations / Headings
- `#`
- `modi =`
- `case-sensitive =`
- `cycle =`
- `filter =`
- `scroll-method =`
- `normalize-match =`
- `show-icons =`
- `steal-focus =`
- `#`
- `#`
- `#`

### Detected References
- `url-launcher = "xdg-open";`

## Source
```
nix
{
  # ---------- General setting ----------
  modi = "drun,run,filebrowser,window";
  case-sensitive = false;
  cycle = true;
  filter = "";
  scroll-method = 0;
  normalize-match = true;
  show-icons = true;
  steal-focus = false;
  # icon-theme = "Papirus-Dark";
  # dpi = -1;

  # ---------- Matching setting ----------
  matching = "normal";
  tokenize = true;

  # ---------- SSH settings ----------
  ssh-client = "ssh";
  ssh-command = "{terminal} -e {ssh-client} {host} [-p {port}]";
  parse-hosts = true;
  parse-known-hosts = true;

  # ---------- Drun settings ----------
  drun-categories = "";
  drun-match-fields = "name,generic,exec,categories,keywords";
  drun-display-format = "{name} [<span weight='light' size='small'><i>({generic})</i></span>]";
  drun-show-actions = false;
  drun-url-launcher = "xdg-open";
  drun-use-desktop-cache = false;
  drun-reload-desktop-cache = false;

  # ---------- Run settings ----------
  run-command = "{cmd}";
  run-list-command = "";
  run-shell-command = "{terminal} -e {cmd}";

  # ---------- Window switcher settings ----------
  window-match-fields = "title,class,role,name,desktop";
  window-command = "wmctrl -i -R {window}";
  window-format = "{w} - {c} - {t:0}";
  window-thumbnail = false;

  # ---------- Combi settings ----------
  # combi-modi = "window,run";
  # combi-hide-mode-prefix = false;
  # combi-display-format = "{mode} {text}";

  # ---------- History and Sorting ----------
  disable-history = false;
  sorting-method = "normal";
  max-history-size = 25;

  # ---------- Display setting ----------
  display-window = "Windows";
  display-windowcd = "Window CD";
  display-run = "Run";
  display-ssh = "SSH";
  display-drun = "Apps";
  display-combi = "Combi";
  display-keys = "Keys";
  display-filebrowser = "Files";

  # ---------- Misc setting ----------
  terminal = "rofi-sensible-terminal";
  sort = false;
  threads = 0;
  click-to-exit = true;
  # ignored-prefixes = "";
  # pid = "/run/user/1000/rofi.pid";

  # ---------- File browser settings ----------

  # ---------- Keybindings ----------
  kb-primary-paste = "Control+V,Shift+Insert";
  kb-secondary-paste = "Control+v,Insert";
  kb-clear-line = "Control+w";
  kb-move-front = "Control+a";
  kb-move-end = "Control+e";
  kb-move-word-back = "Alt+b,Control+Left";
  kb-move-word-forward = "Alt+f,Control+Right";
  kb-move-char-back = "Left,Control+b";
  kb-move-char-forward = "Right,Control+f";
  kb-remove-word-back = "Control+Alt+h,Control+BackSpace";
  kb-remove-word-forward = "Control+Alt+d";
  kb-remove-char-forward = "Delete,Control+d";
  kb-remove-char-back = "BackSpace,Shift+BackSpace";
  kb-remove-to-eol = "Control+Alt+k";
  kb-remove-to-sol = "Control+u";
  kb-accept-entry = "Control+Alt+j,Control+m,Return,KP_Enter";
  kb-accept-custom = "Control+Return";
  kb-accept-custom-alt = "Control+Shift+Return";
  kb-accept-alt = "Shift+Return";
  kb-delete-entry = "Shift+Delete";
  kb-mode-next = "Shift+Right,Control+Tab";
  kb-mode-previous = "Shift+Left,Control+ISO_Left_Tab";
  kb-mode-complete = "";
  kb-row-left = "Control+Page_Up,Control+h";
  kb-row-right = "Control+Page_Down,Control+l";
  kb-row-up = "Up,Control+p,Control+k";
  kb-row-down = "Down,Control+n,Control+j";
  kb-page-prev = "Page_Up";
  kb-page-next = "Page_Down";
  kb-row-first = "Home,KP_Home";
  kb-row-last = "End,KP_End";
  kb-row-select = "Control+space";
  kb-screenshot = "Alt+S";
  kb-ellipsize = "Alt+period";
  kb-toggle-case-sensitivity = "grave,dead_grave";
  kb-toggle-sort = "Alt+grave";
  kb-cancel = "Escape,Control+g,Control+bracketleft";
  kb-custom-1 = "Alt+1";
  kb-custom-2 = "Alt+2";
  kb-custom-3 = "Alt+3";
  kb-custom-4 = "Alt+4";
  kb-custom-5 = "Alt+5";
  kb-custom-6 = "Alt+6";
  kb-custom-7 = "Alt+7";
  kb-custom-8 = "Alt+8";
  kb-custom-9 = "Alt+9";
  kb-custom-10 = "Alt+0";
  kb-custom-11 = "Alt+exclam";
  kb-custom-12 = "Alt+at";
  kb-custom-13 = "Alt+numbersign";
  kb-custom-14 = "Alt+dollar";
  kb-custom-15 = "Alt+percent";
  kb-custom-16 = "Alt+dead_circumflex";
  kb-custom-17 = "Alt+ampersand";
  kb-custom-18 = "Alt+asterisk";
  kb-custom-19 = "Alt+parenleft";
  kb-select-1 = "Super+1";
  kb-select-2 = "Super+2";
  kb-select-3 = "Super+3";
  kb-select-4 = "Super+4";
  kb-select-5 = "Super+5";
  kb-select-6 = "Super+6";
  kb-select-7 = "Super+7";
  kb-select-8 = "Super+8";
  kb-select-9 = "Super+9";
  kb-select-10 = "Super+0";
  ml-row-left = "ScrollLeft";
  ml-row-right = "ScrollRight";
  ml-row-up = "ScrollUp";
  ml-row-down = "ScrollDown";
  me-select-entry = "MousePrimary";
  me-accept-entry = "MouseDPrimary";
  me-accept-custom = "Control+MouseDPrimary";
}
```
