# modules/desktop/hyprland/icons/brightness-100.png 
---
type: repository-file
source_path: "modules/desktop/hyprland/icons/brightness-100.png"
source_kind: binary
extension: "png"
bytes: 32959
sha256: 6925f6255f0ea8397074aab4c23ba7ac82ca7a29dfabc0da3a5fab69000f812a
generated: 2026-10-15
tags:
  - repo-file
  - type/binary
  - ext/png
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/icons/brightness-100.png`
- **Source kind:** binary
- **Size:** 32959 bytes
- **SHA-256:** `6925f6255f0ea8397074aab4c23ba7ac82ca7a29dfabc0da3a5fab69000f812a`

## Searchable Metadata
- **Keywords:** png
- **Parent:** [[Files/modules/desktop/hyprland/icons|modules/desktop/hyprland/icons]]

## Asset Details
- Binary or media content; metadata is recorded without embedding the bytes.
- File extension: `.png`
