# modules/desktop/hyprland/programs/rofi/colors/lovelace.rasi 
---
type: repository-file
source_path: "modules/desktop/hyprland/programs/rofi/colors/lovelace.rasi"
source_kind: text
extension: "rasi"
bytes: 278
sha256: 9c47127d238ac7b1e01681f52af1793819950c1aaeb726e9d7bd92f6dc2f979a
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/rasi
  - area/modules
---

## Summary
- **Role:** Desktop environment, window manager, session, or utility configuration.
- **Repository path:** `modules/desktop/hyprland/programs/rofi/colors/lovelace.rasi`
- **Source kind:** text
- **Size:** 278 bytes, 17 lines
- **SHA-256:** `9c47127d238ac7b1e01681f52af1793819950c1aaeb726e9d7bd92f6dc2f979a`

## Searchable Metadata
- **Keywords:** adi1090x, selected, FDFDFDFF, foreground, urgent, active, F37F97FF, background-alt, Shakya, Aditya, Author, background, Colors, Github
- **Parent:** [[Files/modules/desktop/hyprland/programs/rofi/colors|modules/desktop/hyprland/programs/rofi/colors]]

## Source
```
css
/**
 *
 * Author : Aditya Shakya (adi1090x)
 * Github : @adi1090x
 * 
 * Colors
 **/

* {
    background:     #1D1F28FF;
    background-alt: #282A36FF;
    foreground:     #FDFDFDFF;
    selected:       #79E6F3FF;
    active:         #5ADECDFF;
    urgent:         #F37F97FF;
}
```
