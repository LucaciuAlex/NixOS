# dev-shells/c-cpp/flake.nix 
---
type: repository-file
source_path: "dev-shells/c-cpp/flake.nix"
source_kind: text
extension: "nix"
bytes: 1356
sha256: 3e941f3c3d6b0fe67ad09bcc69305e0cfbfa37f137d09f402447bb8eaed8624e
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/c-cpp/flake.nix`
- **Source kind:** text
- **Size:** 1356 bytes, 56 lines
- **SHA-256:** `3e941f3c3d6b0fe67ad09bcc69305e0cfbfa37f137d09f402447bb8eaed8624e`

## Searchable Metadata
- **Keywords:** pkgs, aarch64-darwin, forEachSupportedSystem, system, stdenv, supportedSystems, with, clang-tools, packages, change, order, compiler, Override, pkgs.clangStdenv, stdenv.hostPlatform.system
- **Parent:** [[Files/dev-shells/c-cpp|dev-shells/c-cpp]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `devShells =`
- `default =`
- `#`
- `#`
- `packages =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0"; # stable Nixpkgs`
- `import inputs.nixpkgs { inherit system; };`

## Source
```
nix
{
  description = "A Nix-flake-based C/C++ development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0"; # stable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs { inherit system; };
          }
        );
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default =
            pkgs.mkShell.override
              {
                # Override stdenv in order to change compiler:
                # stdenv = pkgs.clangStdenv;
              }
              {
                packages =
                  with pkgs;
                  [
                    clang-tools
                    cmake
                    codespell
                    conan
                    cppcheck
                    doxygen
                    gtest
                    lcov
                    vcpkg
                    vcpkg-tool
                  ]
                  ++ (if stdenv.hostPlatform.system == "aarch64-darwin" then [ ] else [ gdb ]);
              };
        }
      );
    };
}
```
