# dev-shells/protobuf  This page represents the repository directory `dev-shells/protobuf` and links to its indexed files.  ## Files
- [[dev-shells/protobuf/.envrc.md|dev-shells/protobuf/.envrc]]
- [[dev-shells/protobuf/flake.nix.md|dev-shells/protobuf/flake.nix]]
