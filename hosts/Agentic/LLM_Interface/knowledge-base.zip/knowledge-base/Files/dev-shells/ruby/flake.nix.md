# dev-shells/ruby/flake.nix 
---
type: repository-file
source_path: "dev-shells/ruby/flake.nix"
source_kind: text
extension: "nix"
bytes: 761
sha256: d8a22e28b25c1912002edfd6d288c0716a9cd06f541722a9e014ea56ebe5de82
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/ruby/flake.nix`
- **Source kind:** text
- **Size:** 761 bytes, 36 lines
- **SHA-256:** `d8a22e28b25c1912002edfd6d288c0716a9cd06f541722a9e014ea56ebe5de82`

## Searchable Metadata
- **Keywords:** pkgs, system, supportedSystems, forEachSupportedSystem, import, aarch64-darwin, x86_64-darwin, inputs.nixpkgs.lib.genAttrs, packages, pkgs.mkShellNoCC, ruby_3_4, with, inherit, inputs.nixpkgs, default
- **Parent:** [[Files/dev-shells/ruby|dev-shells/ruby]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `devShells =`
- `default =`
- `packages =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs { inherit system; };`

## Source
```
nix
{
  description = "A Nix-flake-based Ruby development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs { inherit system; };
          }
        );
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages = with pkgs; [ ruby_3_4 ];
          };
        }
      );
    };
}
```
