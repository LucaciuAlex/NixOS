# dev-shells/platformio/flake.nix 
---
type: repository-file
source_path: "dev-shells/platformio/flake.nix"
source_kind: text
extension: "nix"
bytes: 1261
sha256: 2b505481cc96e9487b6cd384e7f0618a43b92c9aa56a14fa3a01f72e4419a6a7
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/platformio/flake.nix`
- **Source kind:** text
- **Size:** 1261 bytes, 55 lines
- **SHA-256:** `2b505481cc96e9487b6cd384e7f0618a43b92c9aa56a14fa3a01f72e4419a6a7`

## Searchable Metadata
- **Keywords:** pkgs, aarch64-darwin, supportedSystems, forEachSupportedSystem, system, PlatformIO, cmake, default, conan, codespell, packages, with, pkgs.mkShellNoCC, clang-tools, gdb
- **Parent:** [[Files/dev-shells/platformio|dev-shells/platformio]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `devShells =`
- `default =`
- `packages =`
- `shellHook =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs { inherit system; };`

## Source
```
nix
{
  description = "A Nix-flake-based PlatformIO development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs { inherit system; };
          }
        );
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages =
              with pkgs;
              [
                clang-tools
                cmake
                codespell
                conan
                cppcheck
                doxygen
                gtest
                lcov
                platformio
                vcpkg
                vcpkg-tool
              ]
              ++ pkgs.lib.optionals (stdenv.hostPlatform.system != "aarch64-darwin") [ gdb ];

            shellHook = ''
              export PLATFORMIO_CORE_DIR=$PWD/.platformio
            '';
          };
        }
      );
    };
}
```
