# dev-shells/odin  This page represents the repository directory `dev-shells/odin` and links to its indexed files.  ## Files
- [[dev-shells/odin/.envrc.md|dev-shells/odin/.envrc]]
- [[dev-shells/odin/flake.nix.md|dev-shells/odin/flake.nix]]
