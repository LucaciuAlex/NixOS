# dev-shells/gleam/flake.nix 
---
type: repository-file
source_path: "dev-shells/gleam/flake.nix"
source_kind: text
extension: "nix"
bytes: 759
sha256: 05c71e789f331c2835e1b3175acbb6223314b809f0ccd178e65c67fba20fb005
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/gleam/flake.nix`
- **Source kind:** text
- **Size:** 759 bytes, 36 lines
- **SHA-256:** `05c71e789f331c2835e1b3175acbb6223314b809f0ccd178e65c67fba20fb005`

## Searchable Metadata
- **Keywords:** pkgs, forEachSupportedSystem, system, supportedSystems, Gleam, x86_64-darwin, aarch64-darwin, inputs.nixpkgs.lib.genAttrs, import, pkgs.mkShellNoCC, packages, with, default, inputs.nixpkgs, inherit
- **Parent:** [[Files/dev-shells/gleam|dev-shells/gleam]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `devShells =`
- `default =`
- `packages =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs { inherit system; };`

## Source
```
nix
{
  description = "A Nix-flake-based Gleam development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs { inherit system; };
          }
        );
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages = with pkgs; [ gleam ];
          };
        }
      );
    };
}
```
