# dev-shells/node/flake.nix 
---
type: repository-file
source_path: "dev-shells/node/flake.nix"
source_kind: text
extension: "nix"
bytes: 1088
sha256: 9412996c3e67893827e6958c1a001002bf14c4dc42eefd61de5822cea1c698b2
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/node/flake.nix`
- **Source kind:** text
- **Size:** 1088 bytes, 49 lines
- **SHA-256:** `9412996c3e67893827e6958c1a001002bf14c4dc42eefd61de5822cea1c698b2`

## Searchable Metadata
- **Keywords:** pkgs, nodejs, system, yarn, supportedSystems, inherit, forEachSupportedSystem, inputs.self.overlays.default, with, final, overlays.default, nodePackages.pnpm, inputs.nixpkgs, overlays, node2nix
- **Parent:** [[Files/dev-shells/node|dev-shells/node]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `overlays =`
- `nodejs =`
- `yarn =`
- `devShells =`
- `default =`
- `packages =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs {`

## Source
```
nix
{
  description = "A Nix-flake-based Node.js development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs {
              inherit system;
              overlays = [ inputs.self.overlays.default ];
            };
          }
        );
    in
    {
      overlays.default = final: prev: rec {
        nodejs = prev.nodejs;
        yarn = (prev.yarn.override { inherit nodejs; });
      };

      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages = with pkgs; [
              node2nix
              nodejs
              nodePackages.pnpm
              yarn
            ];
          };
        }
      );
    };
}
```
