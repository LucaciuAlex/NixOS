# dev-shells/rust/flake.nix 
---
type: repository-file
source_path: "dev-shells/rust/flake.nix"
source_kind: text
extension: "nix"
bytes: 1693
sha256: e2390c7896841f7019e7e96b65be10aa70504fe380c0696920b5d4561ecec9d8
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/rust/flake.nix`
- **Source kind:** text
- **Size:** 1693 bytes, 75 lines
- **SHA-256:** `e2390c7896841f7019e7e96b65be10aa70504fe380c0696920b5d4561ecec9d8`

## Searchable Metadata
- **Keywords:** with, pkgs, https, Nixpkgs, supportedSystems, forEachSupportedSystem, system, inputs, rustToolchain, rust-analyzer, rustc, pkgs.rustToolchain, rustfmt, cargo, stable
- **Parent:** [[Files/dev-shells/rust|dev-shells/rust]]

### Detected Declarations / Headings
- `description =`
- `inputs =`
- `fenix =`
- `url =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `overlays =`
- `rustToolchain =`
- `devShells =`
- `default =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `url = "https://flakehub.com/f/nix-community/fenix/0.1";`
- `import inputs.nixpkgs {`

## Source
```
nix
{
  description = "A Nix-flake-based Rust development environment";

  inputs = {
    nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs
    fenix = {
      url = "https://flakehub.com/f/nix-community/fenix/0.1";
      inputs.nixpkgs.follows = "nixpkgs";
    };
  };

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs {
              inherit system;
              overlays = [
                inputs.self.overlays.default
              ];
            };
          }
        );
    in
    {
      overlays.default = final: prev: {
        rustToolchain =
          with inputs.fenix.packages.${prev.stdenv.hostPlatform.system};
          combine (
            with stable;
            [
              clippy
              rustc
              cargo
              rustfmt
              rust-src
            ]
          );
      };

      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShell {
            packages = with pkgs; [
              rustToolchain
              openssl
              pkg-config
              cargo-deny
              cargo-edit
              cargo-watch
              rust-analyzer
            ];

            env = {
              # Required by rust-analyzer
              RUST_SRC_PATH = "${pkgs.rustToolchain}/lib/rustlib/src/rust/library";
            };
          };
        }
      );
    };
}
```
