# dev-shells/pulumi  This page represents the repository directory `dev-shells/pulumi` and links to its indexed files.  ## Files
- [[dev-shells/pulumi/.envrc.md|dev-shells/pulumi/.envrc]]
- [[dev-shells/pulumi/flake.nix.md|dev-shells/pulumi/flake.nix]]
