# dev-shells/vlang  This page represents the repository directory `dev-shells/vlang` and links to its indexed files.  ## Files
- [[dev-shells/vlang/.envrc.md|dev-shells/vlang/.envrc]]
- [[dev-shells/vlang/flake.nix.md|dev-shells/vlang/flake.nix]]
