# dev-shells/haskell/flake.nix 
---
type: repository-file
source_path: "dev-shells/haskell/flake.nix"
source_kind: text
extension: "nix"
bytes: 851
sha256: 1684d6ab04208f4bdee9edc478e0507dfa7bab7bfe2494b026ee1ba7c4ca2010
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/haskell/flake.nix`
- **Source kind:** text
- **Size:** 851 bytes, 40 lines
- **SHA-256:** `1684d6ab04208f4bdee9edc478e0507dfa7bab7bfe2494b026ee1ba7c4ca2010`

## Searchable Metadata
- **Keywords:** pkgs, system, supportedSystems, forEachSupportedSystem, inputs.nixpkgs, import, inputs.nixpkgs.lib.genAttrs, aarch64-darwin, inherit, cabal-install, with, haskell-language-server, ghc, default, devShells
- **Parent:** [[Files/dev-shells/haskell|dev-shells/haskell]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `devShells =`
- `default =`
- `packages =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs { inherit system; };`

## Source
```
nix
{
  description = "A Nix-flake-based Haskell development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs { inherit system; };
          }
        );
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages = with pkgs; [
              cabal-install
              ghc
              haskell-language-server
            ];
          };
        }
      );
    };
}
```
