# dev-shells/latex  This page represents the repository directory `dev-shells/latex` and links to its indexed files.  ## Files
- [[dev-shells/latex/.envrc.md|dev-shells/latex/.envrc]]
- [[dev-shells/latex/flake.nix.md|dev-shells/latex/flake.nix]]
