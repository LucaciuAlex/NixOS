# dev-shells/shell  This page represents the repository directory `dev-shells/shell` and links to its indexed files.  ## Files
- [[dev-shells/shell/.envrc.md|dev-shells/shell/.envrc]]
- [[dev-shells/shell/flake.nix.md|dev-shells/shell/flake.nix]]
