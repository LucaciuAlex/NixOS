# dev-shells/typst/flake.nix 
---
type: repository-file
source_path: "dev-shells/typst/flake.nix"
source_kind: text
extension: "nix"
bytes: 983
sha256: 30c087fcaa2719515fbb9e5236297b928b521f7f076089e720d631b1556b00cb
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/typst/flake.nix`
- **Source kind:** text
- **Size:** 983 bytes, 47 lines
- **SHA-256:** `30c087fcaa2719515fbb9e5236297b928b521f7f076089e720d631b1556b00cb`

## Searchable Metadata
- **Keywords:** Typst, pkgs, packages, system, supportedSystems, forEachSupportedSystem, with, import, inputs.nixpkgs.lib.genAttrs, typstPackages, inputs.nixpkgs, pkgs.mkShellNoCC, typstyle, tinymist, inherit
- **Parent:** [[Files/dev-shells/typst|dev-shells/typst]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `devShells =`
- `default =`
- `packages =`
- `#`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs {`

## Source
```
nix
{
  description = "A Nix-flake-based Typst development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs {
              inherit system;
            };
          }
        );
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages =
              with pkgs;
              [
                typst
                typstyle
                tinymist
              ]
              ++ (with typstPackages; [
                # Typst packages
              ]);
          };
        }
      );
    };
}
```
