# dev-shells/go/flake.nix 
---
type: repository-file
source_path: "dev-shells/go/flake.nix"
source_kind: text
extension: "nix"
bytes: 1228
sha256: a22b4dec0dc1e43576657a77add5bb2a13fb122138bd0637837e41a1c53b113a
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/go/flake.nix`
- **Source kind:** text
- **Size:** 1228 bytes, 54 lines
- **SHA-256:** `a22b4dec0dc1e43576657a77add5bb2a13fb122138bd0637837e41a1c53b113a`

## Searchable Metadata
- **Keywords:** pkgs, supportedSystems, https, goVersion, system, forEachSupportedSystem, go_1_, prev, final., final, inherit, inputs.nixpkgs, overlays, overlays.default, inputs.self.overlays.default
- **Parent:** [[Files/dev-shells/go|dev-shells/go]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `goVersion =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `overlays =`
- `go =`
- `devShells =`
- `default =`
- `packages =`
- `#`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs {`
- `imports, godoc, etc.`

## Source
```
nix
{
  description = "A Nix-flake-based Go development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      goVersion = 24; # Change this to update the whole stack

      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs {
              inherit system;
              overlays = [ inputs.self.overlays.default ];
            };
          }
        );
    in
    {
      overlays.default = final: prev: {
        go = final."go_1_${toString goVersion}";
      };

      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages = with pkgs; [
              # go (version is specified by overlay)
              go

              # goimports, godoc, etc.
              gotools

              # https://github.com/golangci/golangci-lint
              golangci-lint
            ];
          };
        }
      );
    };
}
```
