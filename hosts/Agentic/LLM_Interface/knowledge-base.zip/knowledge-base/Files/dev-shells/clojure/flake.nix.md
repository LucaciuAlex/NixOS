# dev-shells/clojure/flake.nix 
---
type: repository-file
source_path: "dev-shells/clojure/flake.nix"
source_kind: text
extension: "nix"
bytes: 1308
sha256: 3f0ff08999005874ae48279774f219c7a9491e29047196db3cb869a97abaa1d5
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/clojure/flake.nix`
- **Source kind:** text
- **Size:** 1308 bytes, 56 lines
- **SHA-256:** `3f0ff08999005874ae48279774f219c7a9491e29047196db3cb869a97abaa1d5`

## Searchable Metadata
- **Keywords:** jdk, inherit, Clojure, pkgs, boot, let, system, forEachSupportedSystem, supportedSystems, leiningen, javaVersion, pkgs.mkShellNoCC, default, inputs.self.overlays.default, overlays
- **Parent:** [[Files/dev-shells/clojure|dev-shells/clojure]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `javaVersion =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `overlays =`
- `jdk =`
- `boot =`
- `clojure =`
- `leiningen =`
- `devShells =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs {`

## Source
```
nix
{
  description = "A Nix-flake-based Clojure development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      javaVersion = 25; # Change this value to update the whole stack

      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs {
              inherit system;
              overlays = [ inputs.self.overlays.default ];
            };
          }
        );
    in
    {
      overlays.default =
        final: prev:
        let
          jdk = prev."jdk${toString javaVersion}";
        in
        {
          boot = prev.boot.override { inherit jdk; };
          clojure = prev.clojure.override { inherit jdk; };
          leiningen = prev.leiningen.override { inherit jdk; };
        };

      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages = with pkgs; [
              boot
              clojure
              leiningen
            ];
          };
        }
      );
    };
}
```
