# dev-shells/shell/flake.nix 
---
type: repository-file
source_path: "dev-shells/shell/flake.nix"
source_kind: text
extension: "nix"
bytes: 764
sha256: d1876b85f9b5f1bc20a83ab88ffbf39a4e491fdf5d9c5edf923046068d0c75b9
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/shell/flake.nix`
- **Source kind:** text
- **Size:** 764 bytes, 36 lines
- **SHA-256:** `d1876b85f9b5f1bc20a83ab88ffbf39a4e491fdf5d9c5edf923046068d0c75b9`

## Searchable Metadata
- **Keywords:** pkgs, system, supportedSystems, forEachSupportedSystem, import, aarch64-darwin, x86_64-darwin, inputs.nixpkgs.lib.genAttrs, packages, pkgs.mkShellNoCC, shellcheck, with, inherit, inputs.nixpkgs, default
- **Parent:** [[Files/dev-shells/shell|dev-shells/shell]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `devShells =`
- `default =`
- `packages =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs { inherit system; };`

## Source
```
nix
{
  description = "A Nix-flake-based Shell development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs { inherit system; };
          }
        );
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages = with pkgs; [ shellcheck ];
          };
        }
      );
    };
}
```
