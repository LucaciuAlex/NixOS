# dev-shells/nickel  This page represents the repository directory `dev-shells/nickel` and links to its indexed files.  ## Files
- [[dev-shells/nickel/.envrc.md|dev-shells/nickel/.envrc]]
- [[dev-shells/nickel/flake.nix.md|dev-shells/nickel/flake.nix]]
