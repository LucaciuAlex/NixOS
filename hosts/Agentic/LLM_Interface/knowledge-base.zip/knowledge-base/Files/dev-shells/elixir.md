# dev-shells/elixir  This page represents the repository directory `dev-shells/elixir` and links to its indexed files.  ## Files
- [[dev-shells/elixir/.envrc.md|dev-shells/elixir/.envrc]]
- [[dev-shells/elixir/flake.nix.md|dev-shells/elixir/flake.nix]]
