# dev-shells/updateAll.sh 
---
type: repository-file
source_path: "dev-shells/updateAll.sh"
source_kind: text
extension: "sh"
bytes: 165
sha256: 89f45e963d454fb877892376a4252c2a3e4c9ded57e38882d6a5286f12b68ea9
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/sh
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/updateAll.sh`
- **Source kind:** text
- **Size:** 165 bytes, 10 lines
- **SHA-256:** `89f45e963d454fb877892376a4252c2a3e4c9ded57e38882d6a5286f12b68ea9`

## Searchable Metadata
- **Keywords:** template, scriptdir, nix, done, update, flake, realpath, bash, for, dirname
- **Parent:** [[Files/dev-shells|dev-shells]]

### Detected Declarations / Headings
- `scriptdir=`
- `template=`

## Source
```
bash
#!/usr/bin/env bash

scriptdir=$(realpath "$(dirname "$0")")

for template in "$scriptdir"/*/; do
  template=${template%*/}
  cd "$template"
  nix flake update
done
```
