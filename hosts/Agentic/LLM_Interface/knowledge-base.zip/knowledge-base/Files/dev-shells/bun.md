# dev-shells/bun  This page represents the repository directory `dev-shells/bun` and links to its indexed files.  ## Files
- [[dev-shells/bun/.envrc.md|dev-shells/bun/.envrc]]
- [[dev-shells/bun/flake.nix.md|dev-shells/bun/flake.nix]]
