# dev-shells/kotlin  This page represents the repository directory `dev-shells/kotlin` and links to its indexed files.  ## Files
- [[dev-shells/kotlin/.envrc.md|dev-shells/kotlin/.envrc]]
- [[dev-shells/kotlin/flake.nix.md|dev-shells/kotlin/flake.nix]]
