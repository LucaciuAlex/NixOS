# dev-shells/dhall/flake.nix 
---
type: repository-file
source_path: "dev-shells/dhall/flake.nix"
source_kind: text
extension: "nix"
bytes: 1254
sha256: 61b719142ccc2b23926a9741576a0169c618edf0e828fda92bdeef17a19ccf7c
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/dhall/flake.nix`
- **Source kind:** text
- **Size:** 1254 bytes, 53 lines
- **SHA-256:** `61b719142ccc2b23926a9741576a0169c618edf0e828fda92bdeef17a19ccf7c`

## Searchable Metadata
- **Keywords:** pkgs, system, Nixpkgs, let, dhallTools, tool, forEachSupportedSystem, mkDhallTools, Dhall, dhall-, supportedSystems, tools, function, building, builtins.map
- **Parent:** [[Files/dev-shells/dhall|dev-shells/dhall]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `devShells =`
- `default =`
- `#`
- `mkDhallTools =`
- `dhallTools =`
- `packages =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs { inherit system; };`

## Source
```
nix
{
  description = "A Nix-flake-based Dhall development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs { inherit system; };
          }
        );
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default =
            let
              # Helper function for building dhall-* tools
              mkDhallTools = ls: builtins.map (tool: pkgs.haskellPackages."dhall-${tool}") ls;

              dhallTools = mkDhallTools [
                "bash"
                "docs"
                "json"
                "lsp-server"
                "nix"
                "nixpkgs"
                "openapi"
                "toml"
                "yaml"
              ];
            in
            pkgs.mkShellNoCC {
              packages = (with pkgs; [ dhall ]) ++ dhallTools;
            };
        }
      );
    };
}
```
