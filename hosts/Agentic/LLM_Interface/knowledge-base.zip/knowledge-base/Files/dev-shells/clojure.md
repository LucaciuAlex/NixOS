# dev-shells/clojure  This page represents the repository directory `dev-shells/clojure` and links to its indexed files.  ## Files
- [[dev-shells/clojure/.envrc.md|dev-shells/clojure/.envrc]]
- [[dev-shells/clojure/flake.nix.md|dev-shells/clojure/flake.nix]]
