# dev-shells/haxe  This page represents the repository directory `dev-shells/haxe` and links to its indexed files.  ## Files
- [[dev-shells/haxe/.envrc.md|dev-shells/haxe/.envrc]]
- [[dev-shells/haxe/flake.nix.md|dev-shells/haxe/flake.nix]]
