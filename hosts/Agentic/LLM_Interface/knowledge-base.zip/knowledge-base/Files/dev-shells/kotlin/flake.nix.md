# dev-shells/kotlin/flake.nix 
---
type: repository-file
source_path: "dev-shells/kotlin/flake.nix"
source_kind: text
extension: "nix"
bytes: 1301
sha256: 1f35f05b9a2ab0b3485e2588192d05bc35d0ea3355a89ac9e039e02b1cc05497
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/kotlin/flake.nix`
- **Source kind:** text
- **Size:** 1301 bytes, 58 lines
- **SHA-256:** `1f35f05b9a2ab0b3485e2588192d05bc35d0ea3355a89ac9e039e02b1cc05497`

## Searchable Metadata
- **Keywords:** jdk, Kotlin, pkgs, supportedSystems, javaVersion, let, system, forEachSupportedSystem, gradle, prev., inputs.nixpkgs, prev, overlays, inherit, inputs.self.overlays.default
- **Parent:** [[Files/dev-shells/kotlin|dev-shells/kotlin]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `javaVersion =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `overlays =`
- `jdk =`
- `gradle =`
- `kotlin =`
- `devShells =`
- `default =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs {`

## Source
```
nix
{
  description = "A Nix-flake-based Kotlin development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      javaVersion = 25; # Change this value to update the whole stack

      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs {
              inherit system;
              overlays = [ inputs.self.overlays.default ];
            };
          }
        );
    in
    {
      overlays.default =
        final: prev:
        let
          jdk = prev."jdk${toString javaVersion}";
        in
        {
          gradle = prev.gradle.override { java = jdk; };
          kotlin = prev.kotlin.override { jre = jdk; };
        };

      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages = with pkgs; [
              gcc
              gradle
              kotlin
              ncurses
              patchelf
              zlib
            ];
          };
        }
      );
    };
}
```
