# dev-shells/swi-prolog  This page represents the repository directory `dev-shells/swi-prolog` and links to its indexed files.  ## Files
- [[dev-shells/swi-prolog/.envrc.md|dev-shells/swi-prolog/.envrc]]
- [[dev-shells/swi-prolog/flake.nix.md|dev-shells/swi-prolog/flake.nix]]
