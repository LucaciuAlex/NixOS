# dev-shells/php/flake.nix 
---
type: repository-file
source_path: "dev-shells/php/flake.nix"
source_kind: text
extension: "nix"
bytes: 816
sha256: f069dd499c8963210320a9b63a77137daa2fb0c71041e000a2951bdefb830778
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/php/flake.nix`
- **Source kind:** text
- **Size:** 816 bytes, 39 lines
- **SHA-256:** `f069dd499c8963210320a9b63a77137daa2fb0c71041e000a2951bdefb830778`

## Searchable Metadata
- **Keywords:** pkgs, system, PHP, supportedSystems, forEachSupportedSystem, import, aarch64-darwin, inputs.nixpkgs.lib.genAttrs, inputs.nixpkgs, packages, with, phpPackages.composer, pkgs.mkShellNoCC, inherit, devShells
- **Parent:** [[Files/dev-shells/php|dev-shells/php]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `devShells =`
- `default =`
- `packages =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs { inherit system; };`

## Source
```
nix
{
  description = "A Nix-flake-based PHP development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs { inherit system; };
          }
        );
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages = with pkgs; [
              php
              phpPackages.composer
            ];
          };
        }
      );
    };
}
```
