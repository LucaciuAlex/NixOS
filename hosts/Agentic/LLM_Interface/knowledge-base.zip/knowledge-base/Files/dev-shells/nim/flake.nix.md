# dev-shells/nim/flake.nix 
---
type: repository-file
source_path: "dev-shells/nim/flake.nix"
source_kind: text
extension: "nix"
bytes: 783
sha256: e40751c53404385ff3d974973483c58232448e958efbf85d93b942cf40caf016
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/nim/flake.nix`
- **Source kind:** text
- **Size:** 783 bytes, 39 lines
- **SHA-256:** `e40751c53404385ff3d974973483c58232448e958efbf85d93b942cf40caf016`

## Searchable Metadata
- **Keywords:** pkgs, supportedSystems, system, forEachSupportedSystem, Nim, import, nimble, inputs.nixpkgs.lib.genAttrs, inputs.nixpkgs, pkgs.mkShellNoCC, packages, with, inherit, devShells, default
- **Parent:** [[Files/dev-shells/nim|dev-shells/nim]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `devShells =`
- `default =`
- `packages =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1";`
- `import inputs.nixpkgs { inherit system; };`

## Source
```
nix
{
  description = "A Nix-flake-based Nim development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1";

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs { inherit system; };
          }
        );
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages = with pkgs; [
              nim
              nimble
            ];
          };
        }
      );
    };
}
```
