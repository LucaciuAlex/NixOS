# dev-shells/python/flake.nix 
---
type: repository-file
source_path: "dev-shells/python/flake.nix"
source_kind: text
extension: "nix"
bytes: 2533
sha256: 7579f309f96c2cdc9e04ff1a5fa978b71b2f146db86a92178502166fff00e05e
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/python/flake.nix`
- **Source kind:** text
- **Size:** 2533 bytes, 95 lines
- **SHA-256:** `7579f309f96c2cdc9e04ff1a5fa978b71b2f146db86a92178502166fff00e05e`

## Searchable Metadata
- **Keywords:** version, the, Python, you, this, venvVersion, for, rebuild, python.version, system, pkgs, forEachSupportedSystem, delete, import, EOF
- **Parent:** [[Files/dev-shells/python|dev-shells/python]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `version =`
- `devShells =`
- `concatMajorMinor =`
- `python =`
- `default =`
- `venvDir =`
- `postShellHook =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs { inherit system; };`
- `import platform; print(platform.python_version())')"`

## Source
```
nix
{
  description = "A Nix-flake-based Python development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs { inherit system; };
          }
        );

      /*
        Change this value ({major}.{min}) to
        update the Python virtual-environment
        version. When you do this, make sure
        to delete the `.venv` directory to
        have the hook rebuild it for the new
        version, since it won't overwrite an
        existing one. After this, reload the
        development shell to rebuild it.
        You'll see a warning asking you to
        do this when version mismatches are
        present. For safety, removal should
        be a manual step, even if trivial.
      */
      version = "3.13";
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        let
          concatMajorMinor =
            v:
            pkgs.lib.pipe v [
              pkgs.lib.versions.splitVersion
              (pkgs.lib.sublist 0 2)
              pkgs.lib.concatStrings
            ];

          python = pkgs."python${concatMajorMinor version}";
        in
        {
          default = pkgs.mkShellNoCC {
            venvDir = ".venv";

            postShellHook = ''
              venvVersionWarn() {
              	local venvVersion
              	venvVersion="$("$venvDir/bin/python" -c 'import platform; print(platform.python_version())')"

              	[[ "$venvVersion" == "${python.version}" ]] && return

              	cat <<EOF
              Warning: Python version mismatch: [$venvVersion (venv)] != [${python.version}]
                       Delete '$venvDir' and reload to rebuild for version ${python.version}
              EOF
              }

              venvVersionWarn
            '';

            packages = with python.pkgs; [
              venvShellHook
              pip

              # Add whatever else you'd like here.
              # pkgs.basedpyright

              # pkgs.black
              # or
              # python.pkgs.black

              # pkgs.ruff
              # or
              # python.pkgs.ruff
            ];
          };
        }
      );
    };
}
```
