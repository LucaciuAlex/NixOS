# dev-shells/lean4  This page represents the repository directory `dev-shells/lean4` and links to its indexed files.  ## Files
- [[dev-shells/lean4/.envrc.md|dev-shells/lean4/.envrc]]
- [[dev-shells/lean4/flake.nix.md|dev-shells/lean4/flake.nix]]
