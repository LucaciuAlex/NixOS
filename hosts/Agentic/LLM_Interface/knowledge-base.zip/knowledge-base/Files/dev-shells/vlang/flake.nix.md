# dev-shells/vlang/flake.nix 
---
type: repository-file
source_path: "dev-shells/vlang/flake.nix"
source_kind: text
extension: "nix"
bytes: 785
sha256: 1361874790e3f45a62e40a216d6c0d282c7a968373b6e5fb29da80389ec5abb4
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/vlang/flake.nix`
- **Source kind:** text
- **Size:** 785 bytes, 38 lines
- **SHA-256:** `1361874790e3f45a62e40a216d6c0d282c7a968373b6e5fb29da80389ec5abb4`

## Searchable Metadata
- **Keywords:** pkgs, forEachSupportedSystem, system, supportedSystems, Vlang, x86_64-darwin, aarch64-darwin, inputs.nixpkgs.lib.genAttrs, import, pkgs.mkShellNoCC, packages, with, default, inputs.nixpkgs, inherit
- **Parent:** [[Files/dev-shells/vlang|dev-shells/vlang]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `devShells =`
- `default =`
- `packages =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs { inherit system; };`

## Source
```
nix
{
  description = "A Nix-flake-based Vlang development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs { inherit system; };
          }
        );
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages = with pkgs; [
              vlang
            ];
          };
        }
      );
    };
}
```
