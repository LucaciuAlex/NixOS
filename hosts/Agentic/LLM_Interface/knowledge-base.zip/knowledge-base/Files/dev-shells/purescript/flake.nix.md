# dev-shells/purescript/flake.nix 
---
type: repository-file
source_path: "dev-shells/purescript/flake.nix"
source_kind: text
extension: "nix"
bytes: 942
sha256: 5ab7e7069c3d813e87c3bd953f1cd30599036f83ba04cc7e00a314d3d57f94c2
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/purescript/flake.nix`
- **Source kind:** text
- **Size:** 942 bytes, 44 lines
- **SHA-256:** `5ab7e7069c3d813e87c3bd953f1cd30599036f83ba04cc7e00a314d3d57f94c2`

## Searchable Metadata
- **Keywords:** pkgs, with, system, supportedSystems, forEachSupportedSystem, Purescript, inputs.nixpkgs, import, inputs.nixpkgs.lib.genAttrs, nodePackages_latest, packages, nodejs_latest, spago, pkgs.mkShellNoCC, inherit
- **Parent:** [[Files/dev-shells/purescript|dev-shells/purescript]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `devShells =`
- `default =`
- `packages =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs { inherit system; };`

## Source
```
nix
{
  description = "A Nix-flake-based Purescript development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs { inherit system; };
          }
        );
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages =
              with pkgs;
              [
                nodejs_latest
                purescript
                spago
              ]
              ++ (with nodePackages_latest; [
              ]);
          };
        }
      );
    };
}
```
