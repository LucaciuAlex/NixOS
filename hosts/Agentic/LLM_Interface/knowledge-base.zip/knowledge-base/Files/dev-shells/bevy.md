# dev-shells/bevy  This page represents the repository directory `dev-shells/bevy` and links to its indexed files.  ## Files
- [[dev-shells/bevy/.envrc.md|dev-shells/bevy/.envrc]]
- [[dev-shells/bevy/flake.nix.md|dev-shells/bevy/flake.nix]]
