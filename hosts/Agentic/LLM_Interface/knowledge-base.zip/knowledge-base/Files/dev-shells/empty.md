# dev-shells/empty  This page represents the repository directory `dev-shells/empty` and links to its indexed files.  ## Files
- [[dev-shells/empty/.envrc.md|dev-shells/empty/.envrc]]
- [[dev-shells/empty/flake.nix.md|dev-shells/empty/flake.nix]]
