# dev-shells/empty/flake.nix 
---
type: repository-file
source_path: "dev-shells/empty/flake.nix"
source_kind: text
extension: "nix"
bytes: 1293
sha256: 8f22153e7592ee42f149f6322ee4328765f9d8922a42b6619d9f85015fea7802
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/empty/flake.nix`
- **Source kind:** text
- **Size:** 1293 bytes, 49 lines
- **SHA-256:** `8f22153e7592ee42f149f6322ee4328765f9d8922a42b6619d9f85015fea7802`

## Searchable Metadata
- **Keywords:** environment, any, flake, The, you, pkgs, Add, system, outputs, for, ARM, macOS, forEachSupportedSystem, supportedSystems, Linux
- **Parent:** [[Files/dev-shells/empty|dev-shells/empty]]

### Detected Declarations / Headings
- `description =`
- `#`
- `#`
- `outputs =`
- `#`
- `supportedSystems =`
- `#`
- `forEachSupportedSystem =`
- `pkgs =`
- `devShells =`
- `default =`
- `#`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs { inherit system; };`

## Source
```
nix
{
  description = "An empty flake template that you can adapt to your own environment";

  # Flake inputs
  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  # Flake outputs
  outputs =
    { self, ... }@inputs:

    let
      # The systems supported for this flake
      supportedSystems = [
        "x86_64-linux" # 64-bit Intel/AMD Linux
        "aarch64-linux" # 64-bit ARM Linux
        "x86_64-darwin" # 64-bit Intel macOS
        "aarch64-darwin" # 64-bit ARM macOS
      ];

      # Helper to provide system-specific attributes
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs { inherit system; };
          }
        );
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            # The Nix packages provided in the environment
            # Add any you need here
            packages = with pkgs; [ ];

            # Set any environment variables for your dev shell
            env = { };

            # Add any shell logic you want executed any time the environment is activated
            shellHook = '''';
          };
        }
      );
    };
}
```
