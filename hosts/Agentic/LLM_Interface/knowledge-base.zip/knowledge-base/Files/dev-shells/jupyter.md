# dev-shells/jupyter  This page represents the repository directory `dev-shells/jupyter` and links to its indexed files.  ## Files
- [[dev-shells/jupyter/.envrc.md|dev-shells/jupyter/.envrc]]
- [[dev-shells/jupyter/.gitignore.md|dev-shells/jupyter/.gitignore]]
- [[dev-shells/jupyter/flake.nix.md|dev-shells/jupyter/flake.nix]]
- [[dev-shells/jupyter/pyproject.toml.md|dev-shells/jupyter/pyproject.toml]]
