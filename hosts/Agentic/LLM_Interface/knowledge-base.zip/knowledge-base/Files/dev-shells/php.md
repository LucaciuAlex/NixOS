# dev-shells/php  This page represents the repository directory `dev-shells/php` and links to its indexed files.  ## Files
- [[dev-shells/php/.envrc.md|dev-shells/php/.envrc]]
- [[dev-shells/php/flake.nix.md|dev-shells/php/flake.nix]]
