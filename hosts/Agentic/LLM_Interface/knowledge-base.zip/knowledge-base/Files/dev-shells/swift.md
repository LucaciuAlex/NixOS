# dev-shells/swift  This page represents the repository directory `dev-shells/swift` and links to its indexed files.  ## Files
- [[dev-shells/swift/.envrc.md|dev-shells/swift/.envrc]]
- [[dev-shells/swift/flake.nix.md|dev-shells/swift/flake.nix]]
