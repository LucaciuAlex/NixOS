# dev-shells/changeAll.sh 
---
type: repository-file
source_path: "dev-shells/changeAll.sh"
source_kind: text
extension: "sh"
bytes: 445
sha256: 869b19debf19b874350855a5a8805b27af414b2292612dc0f5b4232c454c691b
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/sh
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/changeAll.sh`
- **Source kind:** text
- **Size:** 445 bytes, 11 lines
- **SHA-256:** `869b19debf19b874350855a5a8805b27af414b2292612dc0f5b4232c454c691b`

## Searchable Metadata
- **Keywords:** template, nixos, sed, scriptdir, use, flake, done, dirname, realpath, for, echo, bash
- **Parent:** [[Files/dev-shells|dev-shells]]

### Detected Declarations / Headings
- `scriptdir=`
- `template=`
- `#`
- `#`

## Source
```
bash
#!/usr/bin/env bash

scriptdir=$(realpath "$(dirname "$0")")

for template in "$scriptdir"/*/; do
  template=${template%*/}
  # echo "use flake" > "$template/.envrc"
  # sed -i -e 's/github:nixos\/nixpkgs\/nixos-unstable/https:\/\/flakehub.com\/f\/NixOS\/nixpkgs\/0\.1\.*\.tar.gz/' "$template/flake.nix"
  sed -i -e 's/https:\/\/flakehub.com\/f\/NixOS\/nixpkgs\/0\.1\.*\.tar.gz/github:nixos\/nixpkgs\/nixos-unstable/' "$template/flake.nix"
done
```
