# dev-shells/purescript  This page represents the repository directory `dev-shells/purescript` and links to its indexed files.  ## Files
- [[dev-shells/purescript/.envrc.md|dev-shells/purescript/.envrc]]
- [[dev-shells/purescript/flake.nix.md|dev-shells/purescript/flake.nix]]
