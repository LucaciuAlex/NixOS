# dev-shells/r/flake.nix 
---
type: repository-file
source_path: "dev-shells/r/flake.nix"
source_kind: text
extension: "nix"
bytes: 1089
sha256: 44087d0e12f5ae801f54f7ae51039cf71aacf3ed5b7f807d9d0f57bcf7d242d1
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/r/flake.nix`
- **Source kind:** text
- **Size:** 1089 bytes, 49 lines
- **SHA-256:** `44087d0e12f5ae801f54f7ae51039cf71aacf3ed5b7f807d9d0f57bcf7d242d1`

## Searchable Metadata
- **Keywords:** pkgs, with, supportedSystems, rEnv, packages, forEachSupportedSystem, system, prev, overlays.default, inherit, inputs.self.overlays.default, final, overlays, rec, pkgs.mkShellNoCC
- **Parent:** [[Files/dev-shells/r|dev-shells/r]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `overlays =`
- `rEnv =`
- `packages =`
- `devShells =`
- `default =`
- `packages =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs {`

## Source
```
nix
{
  description = "A Nix-flake-based R development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs {
              inherit system;
              overlays = [ inputs.self.overlays.default ];
            };
          }
        );
    in
    {
      overlays.default = final: prev: rec {
        rEnv = final.rWrapper.override {
          packages = with final.rPackages; [ knitr ];
        };
      };

      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages = with pkgs; [
              rEnv
              pandoc
              texlive.combined.scheme-full
            ];
          };
        }
      );
    };
}
```
