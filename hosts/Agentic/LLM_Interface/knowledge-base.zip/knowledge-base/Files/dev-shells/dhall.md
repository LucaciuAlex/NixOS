# dev-shells/dhall  This page represents the repository directory `dev-shells/dhall` and links to its indexed files.  ## Files
- [[dev-shells/dhall/.envrc.md|dev-shells/dhall/.envrc]]
- [[dev-shells/dhall/flake.nix.md|dev-shells/dhall/flake.nix]]
