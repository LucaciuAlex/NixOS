# dev-shells/nim  This page represents the repository directory `dev-shells/nim` and links to its indexed files.  ## Files
- [[dev-shells/nim/.envrc.md|dev-shells/nim/.envrc]]
- [[dev-shells/nim/flake.nix.md|dev-shells/nim/flake.nix]]
