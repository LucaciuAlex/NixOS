# dev-shells/bun/flake.nix 
---
type: repository-file
source_path: "dev-shells/bun/flake.nix"
source_kind: text
extension: "nix"
bytes: 755
sha256: 80394a23b02c703fdab12c49eb76e3a5cca4edcd90ab3274516864d261e6c7c4
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/bun/flake.nix`
- **Source kind:** text
- **Size:** 755 bytes, 36 lines
- **SHA-256:** `80394a23b02c703fdab12c49eb76e3a5cca4edcd90ab3274516864d261e6c7c4`

## Searchable Metadata
- **Keywords:** pkgs, forEachSupportedSystem, system, supportedSystems, Bun, x86_64-darwin, aarch64-darwin, inputs.nixpkgs.lib.genAttrs, import, pkgs.mkShellNoCC, packages, with, default, inputs.nixpkgs, inherit
- **Parent:** [[Files/dev-shells/bun|dev-shells/bun]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `devShells =`
- `default =`
- `packages =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs { inherit system; };`

## Source
```
nix
{
  description = "A Nix-flake-based Bun development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs { inherit system; };
          }
        );
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages = with pkgs; [ bun ];
          };
        }
      );
    };
}
```
