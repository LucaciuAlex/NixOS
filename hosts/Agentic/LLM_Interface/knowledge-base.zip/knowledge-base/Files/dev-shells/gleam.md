# dev-shells/gleam  This page represents the repository directory `dev-shells/gleam` and links to its indexed files.  ## Files
- [[dev-shells/gleam/.envrc.md|dev-shells/gleam/.envrc]]
- [[dev-shells/gleam/flake.nix.md|dev-shells/gleam/flake.nix]]
