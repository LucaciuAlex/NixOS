# dev-shells/pulumi/flake.nix 
---
type: repository-file
source_path: "dev-shells/pulumi/flake.nix"
source_kind: text
extension: "nix"
bytes: 1296
sha256: 78199add2b3e922b3a555d10d4181e2114cc5e0deb8c6fa36226c585b59a9621
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/pulumi/flake.nix`
- **Source kind:** text
- **Size:** 1296 bytes, 62 lines
- **SHA-256:** `78199add2b3e922b3a555d10d4181e2114cc5e0deb8c6fa36226c585b59a9621`

## Searchable Metadata
- **Keywords:** SDK, utilities, pkgs, forEachSupportedSystem, supportedSystems, Pulumi, system, packages, pulumi-language-, pkgs.mkShellNoCC, with, plus, pulumi-analyzer-, pulumi-watch, pulumi-resource-
- **Parent:** [[Files/dev-shells/pulumi|dev-shells/pulumi]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `devShells =`
- `default =`
- `packages =`
- `#`
- `#`
- `#`
- `#`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs { inherit system; };`
- `source-* utilities`

## Source
```
nix
{
  description = "A Nix-flake-based Pulumi development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs { inherit system; };
          }
        );
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages = with pkgs; [
              # Pulumi plus:
              # pulumi-watch
              # pulumi-analyzer-* utilities
              # pulumi-language-* utilities
              # pulumi-resource-* utilities
              pulumi-bin

              # Python SDK
              python311

              # Go SDK
              go

              # Node.js SDK
              nodejs

              # Java SDK
              jdk
              maven

              # Kubernetes
              kubectl

              # Miscellaneous utilities
              jq
            ];
          };
        }
      );
    };
}
```
