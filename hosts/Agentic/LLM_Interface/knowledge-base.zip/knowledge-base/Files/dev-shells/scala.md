# dev-shells/scala  This page represents the repository directory `dev-shells/scala` and links to its indexed files.  ## Files
- [[dev-shells/scala/.envrc.md|dev-shells/scala/.envrc]]
- [[dev-shells/scala/flake.nix.md|dev-shells/scala/flake.nix]]
