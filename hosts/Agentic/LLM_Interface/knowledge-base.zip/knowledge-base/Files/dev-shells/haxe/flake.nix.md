# dev-shells/haxe/flake.nix 
---
type: repository-file
source_path: "dev-shells/haxe/flake.nix"
source_kind: text
extension: "nix"
bytes: 1287
sha256: f713317f8b974941def3bbd5966cbaf9a250b32f325dce7822b3dc391afe778d
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/haxe/flake.nix`
- **Source kind:** text
- **Size:** 1287 bytes, 46 lines
- **SHA-256:** `f713317f8b974941def3bbd5966cbaf9a250b32f325dce7822b3dc391afe778d`

## Searchable Metadata
- **Keywords:** Haxe, The, pkgs, supportedSystems, been, system, forEachSupportedSystem, this, has, which, haxe_4_0, for, with, haxe_4_3, mbedtls_2
- **Parent:** [[Files/dev-shells/haxe|dev-shells/haxe]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `devShells =`
- `default =`
- `#`
- `#`
- `#`
- `#`
- `#`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs { inherit system; };`

## Source
```
nix
{
  description = "A Nix-flake-based Haxe development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs { inherit system; };
          }
        );
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            # WARN: As of 2025-12-28:
            #       `haxe_4_0` is explicitly used because
            #       `haxe` is an alias for `haxe_4_3`,
            #       which requires `mbedtls_2`, which has
            #       been marked as insecure. The build
            #       expression for Haxe has not been
            #       updated to handle this yet, so it fails
            #       to build. This can be changed in the
            #       future or by the user, such as through
            #       an override.
            packages = with pkgs; [ haxe_4_0 ];
          };
        }
      );
    };
}
```
