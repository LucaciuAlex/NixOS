# dev-shells/platformio  This page represents the repository directory `dev-shells/platformio` and links to its indexed files.  ## Files
- [[dev-shells/platformio/.envrc.md|dev-shells/platformio/.envrc]]
- [[dev-shells/platformio/flake.nix.md|dev-shells/platformio/flake.nix]]
