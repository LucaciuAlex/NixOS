# dev-shells/jupyter/flake.nix 
---
type: repository-file
source_path: "dev-shells/jupyter/flake.nix"
source_kind: text
extension: "nix"
bytes: 1014
sha256: c1e0015ed101f30d0af639460d226c957f3dc7843f62db35a8355f057ca670bf
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/jupyter/flake.nix`
- **Source kind:** text
- **Size:** 1014 bytes, 47 lines
- **SHA-256:** `c1e0015ed101f30d0af639460d226c957f3dc7843f62db35a8355f057ca670bf`

## Searchable Metadata
- **Keywords:** pkgs, with, system, supportedSystems, forEachSupportedSystem, inherit, venvShellHook, devShells, venvDir, import, inputs.nixpkgs, default, poetry, python311, python311Packages
- **Parent:** [[Files/dev-shells/jupyter|dev-shells/jupyter]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `devShells =`
- `default =`
- `venvDir =`
- `packages =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs { inherit system; };`

## Source
```
nix
{
  description = "A Nix-flake-based Jupyter development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs { inherit system; };
          }
        );
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            venvDir = ".venv";
            packages =
              with pkgs;
              [
                poetry
                python311
              ]
              ++ (with python311Packages; [
                ipykernel
                pip
                venvShellHook
              ]);
          };
        }
      );
    };
}
```
