# dev-shells/jupyter/pyproject.toml 
---
type: repository-file
source_path: "dev-shells/jupyter/pyproject.toml"
source_kind: text
extension: "toml"
bytes: 260
sha256: ac33a9ed9c699b79515f793d477a973b150ae2fcd7b0a826e68dbdec3db72f88
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/toml
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/jupyter/pyproject.toml`
- **Source kind:** text
- **Size:** 260 bytes, 15 lines
- **SHA-256:** `ac33a9ed9c699b79515f793d477a973b150ae2fcd7b0a826e68dbdec3db72f88`

## Searchable Metadata
- **Keywords:** user, python, README.md, tool.poetry.dependencies, build-system, build-backend, poetry.core.masonry.api, requires, poetry-core, sample-project, version, tool.poetry, name, mail.com, readme
- **Parent:** [[Files/dev-shells/jupyter|dev-shells/jupyter]]

### Detected Declarations / Headings
- `name =`
- `version =`
- `description =`
- `authors =`
- `readme =`
- `python =`
- `requires =`
- `build-backend =`

## Source
```
toml
[tool.poetry]
name = "sample-project"
version = "0.1.0"
description = ""
authors = ["user <user@mail.com>"]
readme = "README.md"

[tool.poetry.dependencies]
python = "^3.11"


[build-system]
requires = ["poetry-core"]
build-backend = "poetry.core.masonry.api"
```
