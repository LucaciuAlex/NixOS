# dev-shells/c-cpp  This page represents the repository directory `dev-shells/c-cpp` and links to its indexed files.  ## Files
- [[dev-shells/c-cpp/.envrc.md|dev-shells/c-cpp/.envrc]]
- [[dev-shells/c-cpp/flake.nix.md|dev-shells/c-cpp/flake.nix]]
