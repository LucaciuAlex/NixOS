# dev-shells/java/flake.nix 
---
type: repository-file
source_path: "dev-shells/java/flake.nix"
source_kind: text
extension: "nix"
bytes: 1712
sha256: 840528bae8c069be0efbdd9cfe3369afedb5344b79a1c5111452393ce02a2631
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/java/flake.nix`
- **Source kind:** text
- **Size:** 1712 bytes, 70 lines
- **SHA-256:** `840528bae8c069be0efbdd9cfe3369afedb5344b79a1c5111452393ce02a2631`

## Searchable Metadata
- **Keywords:** jdk, prev, inherit, pkgs, let, JAVA_TOOL_OPTIONS, forEachSupportedSystem, maven, javaVersion, supportedSystems, Java, system, loadLombok, gradle, overlays.default
- **Parent:** [[Files/dev-shells/java|dev-shells/java]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `javaVersion =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `overlays =`
- `jdk =`
- `maven =`
- `gradle =`
- `lombok =`
- `devShells =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs {`

## Source
```
nix
{
  description = "A Nix-flake-based Java development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      javaVersion = 25; # Change this value to update the whole stack

      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs {
              inherit system;
              overlays = [ inputs.self.overlays.default ];
            };
          }
        );
    in
    {
      overlays.default =
        final: prev:
        let
          jdk = prev."jdk${toString javaVersion}";
        in
        {
          inherit jdk;
          maven = prev.maven.override { jdk_headless = jdk; };
          gradle = prev.gradle.override { java = jdk; };
          lombok = prev.lombok.override { inherit jdk; };
        };

      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages = with pkgs; [
              gcc
              gradle
              jdk
              maven
              ncurses
              patchelf
              zlib
            ];

            shellHook =
              let
                loadLombok = "-javaagent:${pkgs.lombok}/share/java/lombok.jar";
                prev = "\${JAVA_TOOL_OPTIONS:+ $JAVA_TOOL_OPTIONS}";
              in
              ''
                export JAVA_TOOL_OPTIONS="${loadLombok}${prev}"
              '';
          };
        }
      );
    };
}
```
