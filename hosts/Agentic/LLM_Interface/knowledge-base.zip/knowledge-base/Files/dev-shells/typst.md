# dev-shells/typst  This page represents the repository directory `dev-shells/typst` and links to its indexed files.  ## Files
- [[dev-shells/typst/.envrc.md|dev-shells/typst/.envrc]]
- [[dev-shells/typst/flake.nix.md|dev-shells/typst/flake.nix]]
