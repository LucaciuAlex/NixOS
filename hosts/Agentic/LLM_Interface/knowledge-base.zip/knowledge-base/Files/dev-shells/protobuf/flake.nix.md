# dev-shells/protobuf/flake.nix 
---
type: repository-file
source_path: "dev-shells/protobuf/flake.nix"
source_kind: text
extension: "nix"
bytes: 809
sha256: 6975e0ab30049bfadb94122ffc183d4c22af2e1596a18219fef717358f34926b
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/protobuf/flake.nix`
- **Source kind:** text
- **Size:** 809 bytes, 39 lines
- **SHA-256:** `6975e0ab30049bfadb94122ffc183d4c22af2e1596a18219fef717358f34926b`

## Searchable Metadata
- **Keywords:** pkgs, system, Protobuf, supportedSystems, forEachSupportedSystem, import, aarch64-darwin, inputs.nixpkgs.lib.genAttrs, inputs.nixpkgs, packages, with, buf, pkgs.mkShellNoCC, inherit, devShells
- **Parent:** [[Files/dev-shells/protobuf|dev-shells/protobuf]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `devShells =`
- `default =`
- `packages =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs { inherit system; };`

## Source
```
nix
{
  description = "A Nix-flake-based Protobuf development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs { inherit system; };
          }
        );
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages = with pkgs; [
              protobuf
              buf
            ];
          };
        }
      );
    };
}
```
