# dev-shells/node  This page represents the repository directory `dev-shells/node` and links to its indexed files.  ## Files
- [[dev-shells/node/.envrc.md|dev-shells/node/.envrc]]
- [[dev-shells/node/flake.nix.md|dev-shells/node/flake.nix]]
