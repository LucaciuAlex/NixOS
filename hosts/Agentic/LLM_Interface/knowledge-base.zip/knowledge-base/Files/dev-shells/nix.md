# dev-shells/nix  This page represents the repository directory `dev-shells/nix` and links to its indexed files.  ## Files
- [[dev-shells/nix/.envrc.md|dev-shells/nix/.envrc]]
- [[dev-shells/nix/flake.nix.md|dev-shells/nix/flake.nix]]
