# dev-shells/haskell  This page represents the repository directory `dev-shells/haskell` and links to its indexed files.  ## Files
- [[dev-shells/haskell/.envrc.md|dev-shells/haskell/.envrc]]
- [[dev-shells/haskell/flake.nix.md|dev-shells/haskell/flake.nix]]
