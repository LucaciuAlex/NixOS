# dev-shells/ocaml  This page represents the repository directory `dev-shells/ocaml` and links to its indexed files.  ## Files
- [[dev-shells/ocaml/.envrc.md|dev-shells/ocaml/.envrc]]
- [[dev-shells/ocaml/flake.nix.md|dev-shells/ocaml/flake.nix]]
