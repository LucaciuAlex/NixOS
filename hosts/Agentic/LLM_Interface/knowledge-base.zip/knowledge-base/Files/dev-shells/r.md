# dev-shells/r  This page represents the repository directory `dev-shells/r` and links to its indexed files.  ## Files
- [[dev-shells/r/.envrc.md|dev-shells/r/.envrc]]
- [[dev-shells/r/flake.nix.md|dev-shells/r/flake.nix]]
