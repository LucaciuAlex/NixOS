# dev-shells/swift/flake.nix 
---
type: repository-file
source_path: "dev-shells/swift/flake.nix"
source_kind: text
extension: "nix"
bytes: 813
sha256: ed73d610c56392c67a8062bd73d8178e0f77bdcc91bbc3b9601fd79eb53d0baa
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/swift/flake.nix`
- **Source kind:** text
- **Size:** 813 bytes, 39 lines
- **SHA-256:** `ed73d610c56392c67a8062bd73d8178e0f77bdcc91bbc3b9601fd79eb53d0baa`

## Searchable Metadata
- **Keywords:** pkgs, system, Swift, supportedSystems, forEachSupportedSystem, import, aarch64-darwin, inputs.nixpkgs.lib.genAttrs, inputs.nixpkgs, packages, with, sourcekit-lsp, pkgs.mkShellNoCC, inherit, devShells
- **Parent:** [[Files/dev-shells/swift|dev-shells/swift]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `devShells =`
- `default =`
- `packages =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs { inherit system; };`
- `sourcekit-lsp`

## Source
```
nix
{
  description = "A Nix-flake-based Swift development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs { inherit system; };
          }
        );
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages = with pkgs; [
              swift
              sourcekit-lsp
            ];
          };
        }
      );
    };
}
```
