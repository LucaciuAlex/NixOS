# dev-shells/scala/flake.nix 
---
type: repository-file
source_path: "dev-shells/scala/flake.nix"
source_kind: text
extension: "nix"
bytes: 1230
sha256: 235655133281bb24b4c60cdf65f0168b2ab2bffa898ef6ea0a1d768658d8768e
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/scala/flake.nix`
- **Source kind:** text
- **Size:** 1230 bytes, 55 lines
- **SHA-256:** `235655133281bb24b4c60cdf65f0168b2ab2bffa898ef6ea0a1d768658d8768e`

## Searchable Metadata
- **Keywords:** jdk, Scala, pkgs, sbt, let, system, forEachSupportedSystem, supportedSystems, jre, javaVersion, packages, inherit, inputs.self.overlays.default, overlays, with
- **Parent:** [[Files/dev-shells/scala|dev-shells/scala]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `javaVersion =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `overlays =`
- `jdk =`
- `sbt =`
- `scala =`
- `devShells =`
- `default =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs {`

## Source
```
nix
{
  description = "A Nix-flake-based Scala development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      javaVersion = 25; # Change this value to update the whole stack

      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs {
              inherit system;
              overlays = [ inputs.self.overlays.default ];
            };
          }
        );
    in
    {
      overlays.default =
        final: prev:
        let
          jdk = prev."jdk${toString javaVersion}";
        in
        {
          sbt = prev.sbt.override { jre = jdk; };
          scala = prev.scala_3.override { jre = jdk; };
        };

      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages = with pkgs; [
              scala
              sbt
              coursier
            ];
          };
        }
      );
    };
}
```
