# dev-shells/zig/flake.nix 
---
type: repository-file
source_path: "dev-shells/zig/flake.nix"
source_kind: text
extension: "nix"
bytes: 840
sha256: a440b9b425ecb9d2f8b40385ecf2e58e36a6f752fd1b8897e0bd0fc84a0af079
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/zig/flake.nix`
- **Source kind:** text
- **Size:** 840 bytes, 42 lines
- **SHA-256:** `a440b9b425ecb9d2f8b40385ecf2e58e36a6f752fd1b8897e0bd0fc84a0af079`

## Searchable Metadata
- **Keywords:** pkgs, supportedSystems, system, forEachSupportedSystem, Zig, inputs.nixpkgs, import, inputs.nixpkgs.lib.genAttrs, aarch64-darwin, with, packages, lldb, zls, devShells, inherit
- **Parent:** [[Files/dev-shells/zig|dev-shells/zig]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `devShells =`
- `default =`
- `packages =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0"; # stable Nixpkgs`
- `import inputs.nixpkgs {`

## Source
```
nix
{
  description = "A Nix-flake-based Zig development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0"; # stable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs {
              inherit system;
            };
          }
        );
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages = with pkgs; [
              zig
              zls
              lldb
            ];
          };
        }
      );
    };
}
```
