# dev-shells/bevy/flake.nix 
---
type: repository-file
source_path: "dev-shells/bevy/flake.nix"
source_kind: text
extension: "nix"
bytes: 2230
sha256: c5677290b80e5b645bc9d94912c1fa0941905dc4cb4a400d249dec14be65bd11
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/bevy/flake.nix`
- **Source kind:** text
- **Size:** 2230 bytes, 96 lines
- **SHA-256:** `c5677290b80e5b645bc9d94912c1fa0941905dc4cb4a400d249dec14be65bd11`

## Searchable Metadata
- **Keywords:** bevy, https, pkgs, with, forEachSupportedSystem, rustToolchain, wayland, feature, system, supportedSystems, rust-analyzer, Nixpkgs, packages, inputs, common
- **Parent:** [[Files/dev-shells/bevy|dev-shells/bevy]]

### Detected Declarations / Headings
- `description =`
- `inputs =`
- `fenix =`
- `url =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `overlays =`
- `rustToolchain =`
- `devShells =`
- `default =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `url = "https://flakehub.com/f/nix-community/fenix/0.1";`
- `import inputs.nixpkgs {`

## Source
```
nix
{
  description = "A Nix-flake-based Rust development environment";

  inputs = {
    nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs
    fenix = {
      url = "https://flakehub.com/f/nix-community/fenix/0.1";
      inputs.nixpkgs.follows = "nixpkgs";
    };
  };

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs {
              inherit system;
              overlays = [
                inputs.self.overlays.default
              ];
            };
          }
        );
    in
    {
      overlays.default = final: prev: {
        rustToolchain =
          with inputs.fenix.packages.${prev.stdenv.hostPlatform.system};
          combine (
            with stable;
            [
              clippy
              rustc
              cargo
              rustfmt
              rust-src
            ]
          );
      };

      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShell rec {
            packages = with pkgs; [
              rustToolchain
              openssl
              pkg-config
              cargo-deny
              cargo-edit
              cargo-watch
              rust-analyzer

              # common bevy dependencies
              udev
              alsa-lib
              vulkan-loader

              # bevy x11 feature
              libx11
              libxcursor
              libxi
              libxrandr

              # bevy wayland feature
              libxkbcommon
              wayland

              # https://bevy.org/learn/quick-start/getting-started/setup/#enable-fast-compiles-optional
              mold
              clang
            ];

            LD_LIBRARY_PATH = pkgs.lib.makeLibraryPath packages;

            env = {
              # Required by rust-analyzer
              RUST_SRC_PATH = "${pkgs.rustToolchain}/lib/rustlib/src/rust/library";
            };
          };
        }
      );
    };
}
```
