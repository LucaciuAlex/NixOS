# dev-shells/hashi  This page represents the repository directory `dev-shells/hashi` and links to its indexed files.  ## Files
- [[dev-shells/hashi/.envrc.md|dev-shells/hashi/.envrc]]
- [[dev-shells/hashi/flake.nix.md|dev-shells/hashi/flake.nix]]
