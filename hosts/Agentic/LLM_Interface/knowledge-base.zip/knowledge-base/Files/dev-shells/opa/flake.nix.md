# dev-shells/opa/flake.nix 
---
type: repository-file
source_path: "dev-shells/opa/flake.nix"
source_kind: text
extension: "nix"
bytes: 832
sha256: 536acceaf7814161a0749135f44c25f3fdd335596f7f676c045dba8c829ca72f
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/opa/flake.nix`
- **Source kind:** text
- **Size:** 832 bytes, 39 lines
- **SHA-256:** `536acceaf7814161a0749135f44c25f3fdd335596f7f676c045dba8c829ca72f`

## Searchable Metadata
- **Keywords:** pkgs, system, forEachSupportedSystem, supportedSystems, import, aarch64-darwin, x86_64-darwin, inputs.nixpkgs.lib.genAttrs, inputs.nixpkgs, with, packages, conftest, open-policy-agent, devShells, inherit
- **Parent:** [[Files/dev-shells/opa|dev-shells/opa]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `devShells =`
- `default =`
- `packages =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs { inherit system; };`

## Source
```
nix
{
  description = "A Nix-flake-based Open Policy Agent development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs { inherit system; };
          }
        );
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages = with pkgs; [
              open-policy-agent
              conftest
            ];
          };
        }
      );
    };
}
```
