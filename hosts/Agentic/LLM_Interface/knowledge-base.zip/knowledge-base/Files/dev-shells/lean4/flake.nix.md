# dev-shells/lean4/flake.nix 
---
type: repository-file
source_path: "dev-shells/lean4/flake.nix"
source_kind: text
extension: "nix"
bytes: 760
sha256: 5f7e0688b13ff7c0b9a3ee41867e62c260839e596f3892cd6b9dc471f5b05ac4
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/lean4/flake.nix`
- **Source kind:** text
- **Size:** 760 bytes, 36 lines
- **SHA-256:** `5f7e0688b13ff7c0b9a3ee41867e62c260839e596f3892cd6b9dc471f5b05ac4`

## Searchable Metadata
- **Keywords:** pkgs, system, supportedSystems, forEachSupportedSystem, import, aarch64-darwin, x86_64-darwin, inputs.nixpkgs.lib.genAttrs, packages, pkgs.mkShellNoCC, lean4, with, inherit, inputs.nixpkgs, default
- **Parent:** [[Files/dev-shells/lean4|dev-shells/lean4]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `devShells =`
- `default =`
- `packages =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs { inherit system; };`

## Source
```
nix
{
  description = "A Nix-flake-based Lean 4 development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs { inherit system; };
          }
        );
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages = with pkgs; [ lean4 ];
          };
        }
      );
    };
}
```
