# dev-shells/deno  This page represents the repository directory `dev-shells/deno` and links to its indexed files.  ## Files
- [[dev-shells/deno/.envrc.md|dev-shells/deno/.envrc]]
- [[dev-shells/deno/flake.nix.md|dev-shells/deno/flake.nix]]
