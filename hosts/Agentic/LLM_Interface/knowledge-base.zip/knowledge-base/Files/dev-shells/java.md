# dev-shells/java  This page represents the repository directory `dev-shells/java` and links to its indexed files.  ## Files
- [[dev-shells/java/.envrc.md|dev-shells/java/.envrc]]
- [[dev-shells/java/flake.nix.md|dev-shells/java/flake.nix]]
