# dev-shells/rust  This page represents the repository directory `dev-shells/rust` and links to its indexed files.  ## Files
- [[dev-shells/rust/.envrc.md|dev-shells/rust/.envrc]]
- [[dev-shells/rust/flake.nix.md|dev-shells/rust/flake.nix]]
