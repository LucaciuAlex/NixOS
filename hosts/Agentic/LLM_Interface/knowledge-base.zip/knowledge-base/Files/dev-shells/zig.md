# dev-shells/zig  This page represents the repository directory `dev-shells/zig` and links to its indexed files.  ## Files
- [[dev-shells/zig/.envrc.md|dev-shells/zig/.envrc]]
- [[dev-shells/zig/flake.nix.md|dev-shells/zig/flake.nix]]
