# dev-shells/hashi/flake.nix 
---
type: repository-file
source_path: "dev-shells/hashi/flake.nix"
source_kind: text
extension: "nix"
bytes: 1087
sha256: 451ae725f5e4b3cf259c030f5e5dba2f3c3e4167f913396cc4012972df0e9230
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/hashi/flake.nix`
- **Source kind:** text
- **Size:** 1087 bytes, 50 lines
- **SHA-256:** `451ae725f5e4b3cf259c030f5e5dba2f3c3e4167f913396cc4012972df0e9230`

## Searchable Metadata
- **Keywords:** pkgs, Terraform, Packer, supportedSystems, Nomad, forEachSupportedSystem, system, devShells, config.allowUnfree, true, inputs.nixpkgs, import, inherit, terragrunt, nomad-autoscaler
- **Parent:** [[Files/dev-shells/hashi|dev-shells/hashi]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `devShells =`
- `default =`
- `packages =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs {`

## Source
```
nix
{
  description = "A Nix-flake-based development environment for Terraform, Packer, and Nomad";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs {
              inherit system;
              config.allowUnfree = true;
            };
          }
        );
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages = with pkgs; [
              packer
              terraform
              tflint
              nomad
              vault
              nomad-autoscaler
              nomad-pack
              levant
              damon
              terragrunt
            ];
          };
        }
      );
    };
}
```
