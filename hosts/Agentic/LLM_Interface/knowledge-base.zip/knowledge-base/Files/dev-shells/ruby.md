# dev-shells/ruby  This page represents the repository directory `dev-shells/ruby` and links to its indexed files.  ## Files
- [[dev-shells/ruby/.envrc.md|dev-shells/ruby/.envrc]]
- [[dev-shells/ruby/flake.nix.md|dev-shells/ruby/flake.nix]]
