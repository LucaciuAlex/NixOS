# dev-shells/latex/flake.nix 
---
type: repository-file
source_path: "dev-shells/latex/flake.nix"
source_kind: text
extension: "nix"
bytes: 852
sha256: 2090c1ca5fe5a0098e1bd4781188e463d663aee288fb3ce8953a6dce009e5f50
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/latex/flake.nix`
- **Source kind:** text
- **Size:** 852 bytes, 40 lines
- **SHA-256:** `2090c1ca5fe5a0098e1bd4781188e463d663aee288fb3ce8953a6dce009e5f50`

## Searchable Metadata
- **Keywords:** pkgs, system, supportedSystems, forEachSupportedSystem, inputs.nixpkgs, import, inputs.nixpkgs.lib.genAttrs, aarch64-darwin, inherit, texlive.combined.scheme-full, with, tectonic, texlab, default, devShells
- **Parent:** [[Files/dev-shells/latex|dev-shells/latex]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `devShells =`
- `default =`
- `packages =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs { inherit system; };`

## Source
```
nix
{
  description = "A Nix-flake-based LaTeX development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs { inherit system; };
          }
        );
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages = with pkgs; [
              texlive.combined.scheme-full
              texlab
              tectonic
            ];
          };
        }
      );
    };
}
```
