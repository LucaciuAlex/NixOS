# dev-shells/python  This page represents the repository directory `dev-shells/python` and links to its indexed files.  ## Files
- [[dev-shells/python/.envrc.md|dev-shells/python/.envrc]]
- [[dev-shells/python/.gitignore.md|dev-shells/python/.gitignore]]
- [[dev-shells/python/flake.nix.md|dev-shells/python/flake.nix]]
