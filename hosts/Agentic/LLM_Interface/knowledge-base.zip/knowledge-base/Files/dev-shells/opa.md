# dev-shells/opa  This page represents the repository directory `dev-shells/opa` and links to its indexed files.  ## Files
- [[dev-shells/opa/.envrc.md|dev-shells/opa/.envrc]]
- [[dev-shells/opa/flake.nix.md|dev-shells/opa/flake.nix]]
