# dev-shells/go  This page represents the repository directory `dev-shells/go` and links to its indexed files.  ## Files
- [[dev-shells/go/.envrc.md|dev-shells/go/.envrc]]
- [[dev-shells/go/flake.nix.md|dev-shells/go/flake.nix]]
