# dev-shells/nix/flake.nix 
---
type: repository-file
source_path: "dev-shells/nix/flake.nix"
source_kind: text
extension: "nix"
bytes: 952
sha256: e1dd7d8b8d38c752a82874d709cb75446186c1c7b8417c66186f9373c868ca76
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/nix/flake.nix`
- **Source kind:** text
- **Size:** 952 bytes, 45 lines
- **SHA-256:** `e1dd7d8b8d38c752a82874d709cb75446186c1c7b8417c66186f9373c868ca76`

## Searchable Metadata
- **Keywords:** pkgs, system, supportedSystems, forEachSupportedSystem, devShells, haskellPackages.dhall-nix, default, inherit, with, import, inputs.nixpkgs, pkgs.mkShellNoCC, niv, lorri, statix
- **Parent:** [[Files/dev-shells/nix|dev-shells/nix]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `devShells =`
- `default =`
- `packages =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs { inherit system; };`

## Source
```
nix
{
  description = "A Nix-flake-based Nix development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs { inherit system; };
          }
        );
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages = with pkgs; [
              nixd
              cachix
              lorri
              niv
              nixfmt-classic
              statix
              vulnix
              haskellPackages.dhall-nix
            ];
          };
        }
      );
    };
}
```
