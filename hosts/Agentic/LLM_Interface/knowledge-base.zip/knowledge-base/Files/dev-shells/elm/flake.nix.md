# dev-shells/elm/flake.nix 
---
type: repository-file
source_path: "dev-shells/elm/flake.nix"
source_kind: text
extension: "nix"
bytes: 862
sha256: b6046980e1ef88219da0a41a60f141424e53718bc58521b1a0234beb88154e85
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/elm/flake.nix`
- **Source kind:** text
- **Size:** 862 bytes, 41 lines
- **SHA-256:** `b6046980e1ef88219da0a41a60f141424e53718bc58521b1a0234beb88154e85`

## Searchable Metadata
- **Keywords:** pkgs, system, supportedSystems, with, forEachSupportedSystem, Elm, import, aarch64-darwin, inputs.nixpkgs.lib.genAttrs, inputs.nixpkgs, packages, elm2nix, elmPackages, pkgs.mkShellNoCC, inherit
- **Parent:** [[Files/dev-shells/elm|dev-shells/elm]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `devShells =`
- `default =`
- `packages =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs { inherit system; };`

## Source
```
nix
{
  description = "A Nix-flake-based Elm development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs { inherit system; };
          }
        );
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages =
              with pkgs;
              [
                elm2nix
              ]
              ++ (with elmPackages; [ elm ]);
          };
        }
      );
    };
}
```
