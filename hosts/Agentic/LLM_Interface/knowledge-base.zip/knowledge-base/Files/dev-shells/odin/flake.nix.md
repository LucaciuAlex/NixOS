# dev-shells/odin/flake.nix 
---
type: repository-file
source_path: "dev-shells/odin/flake.nix"
source_kind: text
extension: "nix"
bytes: 757
sha256: aac4b61d840b0a4874a393a48bfa1bc4c87e6c0c12000ae47c92c4846239f76d
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/odin/flake.nix`
- **Source kind:** text
- **Size:** 757 bytes, 36 lines
- **SHA-256:** `aac4b61d840b0a4874a393a48bfa1bc4c87e6c0c12000ae47c92c4846239f76d`

## Searchable Metadata
- **Keywords:** pkgs, forEachSupportedSystem, system, supportedSystems, Odin, x86_64-darwin, aarch64-darwin, inputs.nixpkgs.lib.genAttrs, import, pkgs.mkShellNoCC, packages, with, default, inputs.nixpkgs, inherit
- **Parent:** [[Files/dev-shells/odin|dev-shells/odin]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `devShells =`
- `default =`
- `packages =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs { inherit system; };`

## Source
```
nix
{
  description = "A Nix-flake-based Odin development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs { inherit system; };
          }
        );
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages = with pkgs; [ odin ];
          };
        }
      );
    };
}
```
