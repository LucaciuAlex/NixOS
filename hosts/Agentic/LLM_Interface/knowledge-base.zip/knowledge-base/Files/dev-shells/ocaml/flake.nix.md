# dev-shells/ocaml/flake.nix 
---
type: repository-file
source_path: "dev-shells/ocaml/flake.nix"
source_kind: text
extension: "nix"
bytes: 951
sha256: c5dcdfaf1146d9b28ac0ed94e9aa910d9a90b7e2b906a84156dc537aca07b88b
generated: 2026-10-15
tags:
  - repo-file
  - type/text
  - ext/nix
  - area/dev-shells
---

## Summary
- **Role:** Reusable development shell template or direnv environment configuration.
- **Repository path:** `dev-shells/ocaml/flake.nix`
- **Source kind:** text
- **Size:** 951 bytes, 45 lines
- **SHA-256:** `c5dcdfaf1146d9b28ac0ed94e9aa910d9a90b7e2b906a84156dc537aca07b88b`

## Searchable Metadata
- **Keywords:** pkgs, system, with, supportedSystems, forEachSupportedSystem, OCaml, inputs.nixpkgs, import, inputs.nixpkgs.lib.genAttrs, odoc, inherit, ocamlformat, pkgs.ocamlPackages, dune_3, packages
- **Parent:** [[Files/dev-shells/ocaml|dev-shells/ocaml]]

### Detected Declarations / Headings
- `description =`
- `outputs =`
- `supportedSystems =`
- `forEachSupportedSystem =`
- `pkgs =`
- `devShells =`
- `default =`
- `packages =`

### Detected References
- `url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs`
- `import inputs.nixpkgs { inherit system; };`

## Source
```
nix
{
  description = "A Nix-flake-based OCaml development environment";

  inputs.nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1"; # unstable Nixpkgs

  outputs =
    { self, ... }@inputs:

    let
      supportedSystems = [
        "x86_64-linux"
        "aarch64-linux"
        "x86_64-darwin"
        "aarch64-darwin"
      ];
      forEachSupportedSystem =
        f:
        inputs.nixpkgs.lib.genAttrs supportedSystems (
          system:
          f {
            pkgs = import inputs.nixpkgs { inherit system; };
          }
        );
    in
    {
      devShells = forEachSupportedSystem (
        { pkgs }:
        {
          default = pkgs.mkShellNoCC {
            packages =
              with pkgs;
              [
                ocaml
                ocamlformat
              ]
              ++ (with pkgs.ocamlPackages; [
                dune_3
                odoc
              ]);
          };
        }
      );
    };
}
```
